package com.FACTS.TransApp.Log.util;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.TimeZone;


/**
*
* @author mathomas
*/
public class DBUtil {

   public Connection con;

   public DBUtil(String systemType) throws SQLException, ClassNotFoundException {
       if (systemType == null) {
           systemType = "Test";
       }

       Class.forName("com.microsoft.jdbc.sqlserver.SQLServerDriver");
      
    	   
           String url = "jdbc:microsoft:sqlserver://SQL06-Dev.fscj.org";
                  
           con = DriverManager.getConnection(url);
      

   }

   /**
    * @purpose to create Student App in DB 'memapp' and return new ID
    **/
   public String createStudApp(String sUserID, String sPWD, String sFName, String sLName, String sMName, String sAppendage, String sSSN, String sDOB, String sDTime, String secQst, String secAns) throws Exception {
       String appId = "";

       TimeZone est = TimeZone.getTimeZone("America/New_York");
       GregorianCalendar gcalendar = new GregorianCalendar(est);
       int Mon = gcalendar.get(Calendar.MONTH) + 1;
       int min = gcalendar.get(Calendar.HOUR);
       if (gcalendar.get(Calendar.AM_PM) == 1) {
           min = min + 12;
       }
       String offTime = Mon + "/" + gcalendar.get(Calendar.DATE) + "/" + gcalendar.get(Calendar.YEAR) + " "
               + gcalendar.get(Calendar.HOUR) + ":" + gcalendar.get(Calendar.MINUTE);
       if (gcalendar.get(Calendar.AM_PM) == 1) {
           offTime = offTime + " PM";
       } else {
           offTime = offTime + " AM";
       }
       try {

           String command = "{?=call dbo.spMemApp2NewApplic(?,?,?,?,?,?,?,?,?,?,?,?)}";
           CallableStatement cstmt = con.prepareCall(command);

           cstmt.registerOutParameter(1, Types.VARCHAR);
           cstmt.setString(2, sUserID);
           cstmt.setString(3, sPWD);
           cstmt.setString(4, sFName);
           cstmt.setString(5, sLName);
           cstmt.setString(6, sMName);
           cstmt.setString(7, sAppendage);
           cstmt.setString(8, sSSN);
           cstmt.setString(9, sDOB);
           cstmt.setString(10, offTime);
           cstmt.setString(11, secQst);
           cstmt.setString(12, secAns);
           cstmt.registerOutParameter(13, Types.VARCHAR);
           cstmt.setString(13, null);
           cstmt.execute();
//			appId = (long)cstmt.executeUpdate();
           appId = cstmt.getString(13);



       } catch (Exception e) {
          throw new Exception(e);

       } finally {
           closeConn();
       }

       return appId;
   }

   public void updateShoppingCart(String appID) {
	   int newID = Integer.parseInt(appID);
	   try{
		   String command = "{call dbo.spMemApp2_updShopCart(?,?,?,?,?,?,?,?,?,?,?,?,?)}";
		   CallableStatement cstmt = con.prepareCall(command);
		   cstmt.setInt(1, newID);
		   cstmt.setString(2, "");
		   cstmt.setString(3,"" );
		   cstmt.setString(4,"");
		   cstmt.setString(5,"");
		   cstmt.setString(6,"");
		   cstmt.setString(7,"");
		   cstmt.setString(8,"");
		   cstmt.setString(9,"");
		   cstmt.setString(10,"");
		   cstmt.setInt(11,0);
		   cstmt.setInt(12,0);
		   cstmt.setBoolean(13, false);
		   cstmt.execute();
	   }catch (Exception e) {
		   System.out.println("here");
	   }finally{
		   closeConn();
	   }
   }
   
   
   public boolean setTblStatus(String appId, String retCode, String retMsg, String complete, String dtSubm, String strRefnums, String retOthr) throws Exception {
       boolean res = false;
       try {
//			FacesContext fCntx = FacesContext.getCurrentInstance();
//			StudentInfo studInfo = (StudentInfo)fCntx.getApplication().getVariableResolver().resolveVariable(fCntx, "StudentInfo");
//			StudentPersonInfo spi = (StudentPersonInfo)fCntx.getApplication().getVariableResolver().resolveVariable(fCntx, "StudentPersonInfo");


           PreparedStatement ps = con.prepareStatement("Select * FROM Status WHERE AppId = ? ");
           ps.setString(1, appId);
           ResultSet rs = ps.executeQuery();

           if (rs.next()) {
//				Filling all view beans
               ps = con.prepareStatement("UPDATE Status SET RetCode=?, RetMsg=?, Complete=?, SubmitDate=?, Courses=?, RegErr=? WHERE AppId = ? ");
               ps.setInt(7, Integer.parseInt(appId));

               ps.setString(1, retCode);
               ps.setString(2, retMsg);
               ps.setString(3, complete);
               ps.setString(4, dtSubm);
               ps.setString(5, strRefnums);
               ps.setString(6, retOthr);
               ps.executeUpdate();

           } else {
               ps = con.prepareStatement("INSERT INTO Status(AppId, RetCode,RetMsg,Complete,SubmitDate,Courses, RegErr) VALUES(?,?,?,?,?,?,?)");
               ps.setInt(1, Integer.parseInt(appId));

               ps.setString(2, retCode);
               ps.setString(3, retMsg);
               ps.setString(4, complete);
               ps.setString(5, dtSubm);
               ps.setString(6, strRefnums);
               ps.setString(7, retOthr);
               ps.execute();
           }
           res = true;
           ps.close();
           rs.close();

       } catch (Exception e) {
           res = false;
           throw new Exception(e);
           
       } finally {
           closeConn();
       }
       return res;
   }

   public void closeConn() {
       try {
           if (con != null) {
               con.close();
           }
       } catch (SQLException e) {
       }
   }
   
   public static void main(String[] args) {
	   try{
	   DBUtil service2 = new DBUtil("Test");
	   service2.updateShoppingCart("185300");
	   System.out.println("done");
	   }catch (Exception ex) {
		   System.out.println("Error = " + ex.getMessage());
	   }
	   
   }
}
