package fccsc.manager.util;

import java.io.*;
import java.util.*;

import org.apache.log4j.*;


public final class TemplateManager
{
	private static Logger    logger        = Logger.getLogger( TemplateManager.class );
	private static Hashtable hTemplates    = new Hashtable();
	private static String    directoryPath = "";


//	public static void
//	main( String [] args )
//	{
//		try
//		{
//			File f = new File( "." );
//			TemplateManager.init(   f.getCanonicalPath() +
//								    f.separator + "jars" + f.separator + "templates" );
//			TemplateManager.loadAll();
//
//		    System.out.println( "listing   [" + TemplateManager.display() + "]" );
//
//			String template = TemplateManager.populate( "TRANSCRIPT.template", "BLAH BLAH BLAH" );
//
//			System.out.println( "populated [" + template + "]" );
//		}
//		catch (IOException ex)
//		{
//			ex.printStackTrace();
//		}
//	}

	/**
	 * Initializes this manager with the location (directory path)
	 * of template files to load.
	 *
	 * @param p_directoryPath the absolute directory path, i.e... D:\\manager\\templates
	 */
    public static void
	init( String p_directoryPath )
    {
		directoryPath = p_directoryPath;
    }


	/**
	 * Display a listing of all loaded template files.
	 * @return a string representation of internal data.
	 */
	public static String
	display()
	{
		StringWriter buffer = new StringWriter();
		Enumeration  enums  = hTemplates.keys();
		String       name   = "";
		String       data   = "";

		while ( enums.hasMoreElements() )
		{
			name = (String) enums.nextElement();
		    data = (String) hTemplates.get( name );

			buffer.write( "\n" + name + " [" + data + "]" );
		}

		return (String) buffer.toString();
	}


	/**
	 * Loads all the (*.template) files from our root directory path
	 * provided in the constructor of this object. This method filters
	 * out all *.template files and loads each file into an internal
	 * hashtable data structure and maps the loaded Template file
	 * with its file * name (<filename>.template).
	 */
	public static void
	loadAll()
	{
		hTemplates.clear();

		try
		{
			File f = new File( directoryPath );

		    if ( f.isDirectory() )
			{
			    String [] arrFiles = (String []) f.list();

				for (int i = 0; i < arrFiles.length; i++)
				{
					if ( arrFiles[i].endsWith( "template" ) )
					{
						load( arrFiles[i] );
					}
				}
			}
		}
		catch (Exception ex)
		{
			logger.error( "Error trying to load all templates [" + ex.getMessage() + " ]" );
		}
	}


	/**
	 * Loads a (*.template) file from our root directory path
	 * provided in the constructor of this object. This method loads
	 * the file into an internal hashtable data structure and maps
	 * the loaded Template file with its file name (<p_filename>.template).
	 *
	 * @param p_fileName the template file to load.
	 */
	public static void
	load( String p_fileName )
	{
		try
		{
			String path = directoryPath + File.separator + p_fileName;
			File   f    = new File( path );

			if ( f.exists() )
			{
				FileInputStream fin    = new FileInputStream( f );
	    		BufferedReader  result = new BufferedReader( new InputStreamReader( fin ) );

				String       line   = "";
	    		StringBuffer buffer = new StringBuffer();

				while ( (line = result.readLine() ) != null )
	    		{
		    		buffer.append( line );
			    }

				//System.out.println( "template file name [" + f.getName() + "]" );
				hTemplates.put( (String) f.getName(), (String) buffer.toString() );
			}
			else
			{
				logger.error( "Error trying to load template (" + path + "). File does not exist !" );
			}
		}
		catch (Exception ex)
		{
			logger.error( "Error trying to load templates (" + p_fileName + ")" );
		}
	}


	/**
	 * Parses and loads the specified template with the given data.
	 *
	 * @param p_templateName the template to parse and load.
	 * @param p_data         the data to insert into the template.
	 * @return a string of the template after data insertion.
	 */
	public static String
	populate( String p_templateName, String p_data )
	{
		StringBuffer buffer = new StringBuffer();

		if ( hTemplates.containsKey( (String) p_templateName ) )
		{
			String INSERT_TAG     = "<!REPORT>";
			String templateData   = (String) hTemplates.get( (String) p_templateName );

			int    begin          = (int)    templateData.indexOf( INSERT_TAG );
			String templateTop    = (String) templateData.substring( 0, begin );
			String templateBottom = (String) templateData.substring(    begin + INSERT_TAG.length() );

			buffer.append( (String) templateTop );
			buffer.append( (String) p_data );
			buffer.append( (String) templateBottom );

			//System.out.println( "Template:           " + templateData );
			//System.out.println( "Template-Top:       " + templateTop    );
			//System.out.println( "Template-Bottom:    " + templateBottom );
			//System.out.println( "Template-Populated: " + buffer.toString() );
		}

		return (String) buffer.toString();
	}
}