package fccsc.manager.data.edi;

public class FACTSShopBlock
	extends RemoteShopBlock
{

    public
	FACTSShopBlock( String p_data )
    {
		super( p_data );
    }


	public String
	toString()
	{
		StringBuffer buffer = new StringBuffer();

		buffer.append( "\nFacts Shop Block" );
		buffer.append( "\n   Parent [" + super.toString() + "]" );
		buffer.append( "\n" );

		return (String) buffer.toString();
	}
}
