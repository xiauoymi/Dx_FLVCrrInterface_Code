package fccsc.manager.data.edi;


public class LocalShopBlock
	extends AbstractBlock
{
	public static final int SIZE = 62;


    public
	LocalShopBlock( String p_data )
    {
		// from ... CB + SDB ... till the end of the data
		super( (String) p_data.substring( ControlBlock.SIZE + StandardDataBlock.SIZE ) );
    }


	public String getMajor()       { return this.data.substring( 22, 22 + 10 ).trim(); }
	public String getCatalogYear() { return this.data.substring( 55, 55 +  6 ).trim(); }


	public String
	toString()
	{
		StringBuffer buffer = new StringBuffer();

		buffer.append( "\nLocal Shop Block" );
		buffer.append( "\n   Major        [" + getMajor()       + "]" );
		buffer.append( "\n   Catalog Year [" + getCatalogYear() + "]" );
		buffer.append( "\n" );

		return (String) buffer.toString();
	}
}