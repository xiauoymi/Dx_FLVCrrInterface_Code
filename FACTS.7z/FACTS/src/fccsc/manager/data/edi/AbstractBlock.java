package fccsc.manager.data.edi;


public abstract class AbstractBlock
{
	protected StringBuffer data = new StringBuffer();

    public
	AbstractBlock( String p_data )
    {
		this.data.append( (String) p_data );
    }

	public String getData() { return (String) this.data.toString(); }
}