package fccsc.manager.data;


public final class ReturnCodes
{
	/** Code for: OK. No errors. */
	public static final String CODE_00000         = "00000";
	/** Code message: (This is a blank / empty message) */
	public static final String CODE_00000_MESSAGE = "";

	/** Code for: No program code selected for degree shopping code. */
	public static final String CODE_00012         = "00012";
	/** Code message: No program code selected for degree shopping message. */
	public static final String CODE_00012_MESSAGE = "No program code selected for degree shopping.";

	/** Code for: Site Host Error. */
	public static final String CODE_00032         = "00032";
	/** Code message: Site Host Error. */
	public static final String CODE_00032_MESSAGE = "Site Host Error.";

	/** Code for: Response data is empty. */
	public static final String CODE_00048         = "00048";
	/** Code message: Response data is empty. */
	public static final String CODE_00048_MESSAGE = "Response data is empty.";

	/** Code for: Response was an xml ERROR message. */
	public static final String CODE_00200         = "00200";
	/** Code message: Response was an xml ERROR message. */
	public static final String CODE_00200_MESSAGE = "Response was an xml ERROR message.";

	/** Code for: Unknown process. */
	public static final String CODE_00300         = "00300";
	/** Code message: Unknown process. */
	public static final String CODE_00300_MESSAGE = "Uknown process.";
	
	//**Any other errors
	public static final String CODE_99999		  = "99999";
	public static final String CODE_99999_MESSAGE = "Error on Form";

}