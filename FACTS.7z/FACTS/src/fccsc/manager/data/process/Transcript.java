package fccsc.manager.data.process;

import intarsys.util.*;

import edu.fscj.student.StudentPasswordClient;
import fccsc.manager.broker.*;
import fccsc.manager.data.*;
import fccsc.manager.data.edi.*;
import fccsc.manager.util.*;

public final class Transcript extends ProcessFEDI {
	private StringBuffer data = new StringBuffer();

	/**
	 * Creates an object to process TRANSCRIPT messages.
	 */
	public Transcript() {
		super("message.TRANSCRIPT.properties");
	}

	/**
	 * Interface Method - Processing method.
	 * 
	 * @throws Exception
	 */
	public void process() throws Exception {
		super.process();

		// setup our return codes
		String resRC = ReturnCodes.CODE_00000;
		String resMessage = ReturnCodes.CODE_00000_MESSAGE;

		String studId = this.getEDIStandardDataBlock().getStudentID();
		String studPwd = this.getEDIStandardDataBlock().getPinPassword();

//		System.out.println("In Transcript ");
//		System.out.println("studId = " + studId.trim());
//		System.out.println("studPwd = " + studPwd.trim());
		
		// change to ldap password

		StudentPasswordClient client = new StudentPasswordClient();

		if (studPwd.trim().length() > 0) {
			String rtndata = client.getStudentSSNDOBAfterAuthentication(studId
					.trim(), studPwd.trim());

			int begint = rtndata.indexOf('|');
			if (begint > -1) {
				studId = rtndata.substring(0, begint);
				studPwd = rtndata.substring(begint + 1, rtndata.length());
			}
		} else {
			String rtndata = client.getStudentSSNFromMIS(studId.trim());
			studId = rtndata;
//			System.out.println("studId after = " + studId.trim());

		}

		// end of change to ldap password

		studId = (String) StringTools.padRight(studId, 9, ' ');
		studPwd = (String) StringTools.padRight(studPwd, 6, ' ');

		String data = studId + studPwd;
		
		EntireXBroker broker = new EntireXBroker(this.getProperties());
		broker.sendMessage(data);

		// get response message
		String response = (String) broker.getResponse();
	
		// String resParams = (String) response.substring( 0, 0 + 15 );
		// String resExpand = (String) response.substring( 15, 15 + 85 );
		String resTranscript = (String) response.substring(100, 100 + 25900);

		if (logger.isDebugEnabled()) {
			logger.debug("Broker Response [" + response + "]");
		}

		if (resTranscript.trim().length() == 0) {
			resRC = ReturnCodes.CODE_00048;
			resMessage = ReturnCodes.CODE_00048_MESSAGE;

			logger.error("Error [" + resRC + " - " + resMessage + "]");
		} else {
			processData(resTranscript);
		}

		this.getEDIStandardDataBlock().setReturnCode(resRC);
		this.getEDIStandardDataBlock().setReturnMessage(resMessage);

		// ////////////////////////////////////////////////////////////
		// build response and store
		//
		StringBuffer buffer = new StringBuffer();

		int lenTRS = Integer.parseInt((String) this.getEDIControlBlock()
				.getTotalRecordSize());
		int lenPDB = this.data.length();
		int lenTotal = lenTRS + lenPDB;

		this.getEDIControlBlock().setTotalRecordSize(
				String.valueOf((int) lenTotal));

		buffer.append((String) this.getEDIControlBlock().getData());
		buffer.append((String) this.getEDIStandardDataBlock().getData());
		buffer.append((String) this.data.toString());

		
		this.setResponse((String) buffer.toString());
		System.out.println("_______________________________________________________________________");
		System.out.println("Response back starts for Transcript");
		System.out.println(this.getResponse());
		System.out.println("End of Response");
		System.out.println("_______________________________________________________________________");
		
	}

	private void processData(String p_data) {
		// //////////////////////////////////////////////////////////////
		// data parsing
		//
		StringBuffer buffer = new StringBuffer();
		String html = "";
		String line = ""; // 78 bytes
		int MAX = 78; // max # bytes a line can have
		int len = (int) p_data.length();

		for (int i = 0; i < len; /**/) {
			if ((i + MAX) <= len) {
				line = (String) p_data.substring(i, i + MAX);
				i = i + MAX;
			} else {
				line = (String) p_data.substring(i);
				i = len;
			}

			if (line.trim().length() > 0) {
				buffer.append(line + "\n"); // line + linefeed character
			}
		}

		// //////////////////////////////////////////////////////////////
		// populate a template
		html = (String) TemplateManager.populate("TRANSCRIPT.template", buffer
				.toString());

		// //////////////////////////////////////////////////////////////
		// build "Process Data Block" section
		//
		String lenHtml = (String) String.valueOf((int) html.length());

		this.data.append(StringTools.padRight("", 8, ' ')); // 8 filler
		this.data.append(StringTools.padLeft(lenHtml, 6, '0')); // 6 html data
																// length
		this.data.append("TRANDATA");
		this.data.append(html); // ? html data
		this.data.append("\n"); // 1 linefeed character
	}
}