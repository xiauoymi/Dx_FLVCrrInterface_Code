package fccsc.manager.data.process;

import fccsc.manager.data.ReturnCodes;
import fccsc.manager.data.edi.*;


public final class ProcessUnknownFEDI
	extends ProcessFEDI
{
	private StringBuffer buffer = new StringBuffer();


    public
	ProcessUnknownFEDI()
    {
		super( "" );
    }


	/**
	 * Interface Method - Processing method.
	 * @throws Exception
	 */
	public void
	process() throws Exception
	{
		super.process();

		//////////////////////////////////////////////////////////////
		// build response and store
		//
		this.getEDIStandardDataBlock().setReturnCode(    ReturnCodes.CODE_00300         );
		this.getEDIStandardDataBlock().setReturnMessage( ReturnCodes.CODE_00300_MESSAGE );

	    // fetch the remaining data
		String data = this.getRequest().substring( ControlBlock.SIZE + StandardDataBlock.SIZE );

		this.setResponse(   (String) this.getEDIControlBlock().getData() +
						    (String) this.getEDIStandardDataBlock().getData() +
							(String) data );
	}
}
