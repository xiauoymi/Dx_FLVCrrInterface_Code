package fccsc.manager.data.process;

import java.util.*;

import intarsys.util.*;

import edu.fscj.student.StudentPasswordClient;
import fccsc.manager.broker.*;
import fccsc.manager.data.*;
import fccsc.manager.data.edi.*;
import fccsc.manager.util.*;


public final class LocalShop
	extends ProcessFEDI
{
	private static String  guestStudentId = "";
	private static boolean bLoadedGuestId = false;

	private StringBuffer data = new StringBuffer();


	/**
	 * Creates an object to process a LOCALSHOP message.
	 */
    public
	LocalShop()
    {
		super( "message.LOCALSHOP.properties" );
    }


	/**
	 * Interface Method - Processing method.
	 * @throws Exception
	 */
	public void
	process() throws Exception
	{
		super.process();

		LocalShopBlock ediLSB = new LocalShopBlock( this.getRequest() );

		String studId  = this.getEDIStandardDataBlock().getStudentID();
		String studPwd = this.getEDIStandardDataBlock().getPinPassword();
		
		System.out.println("In LocalShop beginning ");
		System.out.println("studId = " + studId.trim());
		System.out.println("studPwd = " + studPwd.trim());
        // change to ldap password

		StudentPasswordClient client = new StudentPasswordClient();

		if (studPwd.trim().length() > 0) {
			String rtndata = client.getStudentSSNDOBAfterAuthentication(studId
					.trim(), studPwd.trim());

			int begint = rtndata.indexOf('|');
			if (begint > -1) {
				studId = rtndata.substring(0, begint);
				studPwd = rtndata.substring(begint + 1, rtndata.length());
			}
		} else {
			String rtndata = client.getStudentSSNFromMIS(studId.trim());
			studId = rtndata;

		}

		// end of change to ldap password
		
		
		String program = ediLSB.getMajor();  // 5 bytes
		String award   = "   ";              // 3 bytes
		String term    = "      ";           // 6 bytes

		// check for "GST" in student id
		if ( studId.trim().equalsIgnoreCase( "GST" ) )
		{
			studId = (String) checkForGuest( studId );
//			System.out.println("In LocalShop in GST if statement ");
//			System.out.println("studId = " + studId.trim());
//			System.out.println("studPwd = " + studPwd.trim());
			logger.info( "Guest Student ID [" + studId + "] (message.LOCALSHOP.properties)" );
		}

/*		Changed 12/15/09 mdt
 		studId  = (String) StringTools.padRight( studId,  9, ' ' );
		studPwd = (String) StringTools.padRight( studPwd, 6, ' ' );
		program = (String) StringTools.padRight( program, 5, ' ' );
*/
		
		studId  = (String) StringTools.padRight( studId,  12, ' ' );
		studPwd = (String) StringTools.padRight( studPwd, 15, ' ' );
		program = (String) StringTools.padRight( program, 5, ' ' );
		String data = studId + studPwd + program + award + term;

		EntireXBroker broker = new EntireXBroker( this.getProperties() );
		broker.sendMessage( data );

		// get response message
		String response    = (String) broker.getResponse();
		int value = response.length();
		//String resParams   = (String) response.substring(     0,     0 +    29 );
		//String resExpand   = (String) response.substring(    29,    29 +    68 );
		//change 12/11/09 mdt
		//String resRC       = (String) response.substring(    97,    97 +     4 );
		//String resDA       = (String) response.substring(   101,   101 + 23700 );
		
		
		
		String resRC       = (String) response.substring(    109,    109 +     4 );
		
		
		
		String resDA       = (String) response.substring(   113,   response.length());
		
		if(response.length() < 26000){
			resRC = (String) response.substring(    115,    115 +     4 );
			resDA = (String) response.substring(    119,    119 + response.length());
		}
		
		//String resExpand2  = (String) response.substring( 23801, 23801 +  2199 );
		String resMessage  = "";

		if ( logger.isDebugEnabled() )
		{
			logger.debug( "Broker Response [" + response + "]" );
			
		}

		if ( resDA.trim().length() == 0 )
		{
		    resRC      = ReturnCodes.CODE_00048;
			resMessage = ReturnCodes.CODE_00048_MESSAGE;

			logger.error( "Error [" + resRC + " - " + resMessage + "]" );
		}
		else if ( resRC.equalsIgnoreCase( "0000" ) )
		{
		    resRC      = ReturnCodes.CODE_00000;
			resMessage = ReturnCodes.CODE_00000_MESSAGE;

		    processData( resDA );
		}
		else
		{
			resMessage = resDA.trim();

			logger.error( "Error [" + resRC + " - " + resMessage + "]" );
		}

		this.getEDIStandardDataBlock().setReturnCode(    resRC );
		this.getEDIStandardDataBlock().setReturnMessage( resMessage );


		//////////////////////////////////////////////////////////////
		// build response and store
		//
		StringBuffer buffer = new StringBuffer();

		int lenCB    = ControlBlock.SIZE;
		int lenSDB   = this.getEDIStandardDataBlock().getData().length();
		int lenPDB   = this.data.length();
		int lenTotal = lenCB + lenSDB + lenPDB;

		this.getEDIControlBlock().setTotalRecordSize( String.valueOf( (int) lenTotal ) );

		buffer.append( (String) this.getEDIControlBlock().getData() );
		buffer.append( (String) this.getEDIStandardDataBlock().getData() );
		buffer.append( (String) this.data.toString() );

		this.setResponse( (String) buffer.toString() );
		System.out.println("_______________________________________________________________________");
		System.out.println("Response back starts for LocalShop");
		System.out.println(this.getResponse());
		System.out.println("End of Response");
		System.out.println("_______________________________________________________________________");
	}


	private void
	processData( String p_data )
	{
		////////////////////////////////////////////////////////////////
		// data parsing
		//
		StringBuffer buffer = new StringBuffer();
		String       html   = "";
		String       line   = "";   // 79 bytes
		int          MAX    = 79;   // max # bytes a line can have
		int          len    = (int) p_data.length();

		for ( int i = 0; i < len; /**/ )
		{
			if ( (i + MAX) <= len )
			{
			    line = (String) p_data.substring( i, i + MAX );
				i = i + MAX;
			}
			else
			{
			    line = (String) p_data.substring( i );
				i = len;
			}

		    if ( line.trim().length() > 0 )
			{
				// adds this ... <HR> before this ...
				//                   *** Program of Study Course Requirements ***
				//
				if ( line.indexOf( "   *** " ) > -1 )
				{
					buffer.append( "<hr>\n" );
				}
				// adds this ... <HR Align=Center Width=65%> before this ...
				//     Area 01:(07A) GENERAL EDUCATION              Min.Hours:18.00 Min.Crses: 6
				//
				else if ( (line.indexOf( "   Area " ) > -1) && (line.indexOf( "Min.Crses" ) > -1) )
				{
					buffer.append( "<hr align='center' width='65%'>\n" );
				}

				// trim off trailing spaces
				line = StringTools.trimTrailingWhitespace( line );

			    buffer.append( line + "\n" );  // line + carriage return + linefeed character
				
			}
		}

		////////////////////////////////////////////////////////////////
		// populate a template
		html = (String) TemplateManager.populate( "LOCALSHOP.template", buffer.toString() );

		////////////////////////////////////////////////////////////////
		// build "Process Data Block" section
		//
		String lenHtml = (String) String.valueOf( (int) html.length() );

		this.data.append( StringTools.padRight(      "", 8, ' ' ) );  //  8 filler
		this.data.append( StringTools.padLeft(  lenHtml, 6, '0' ) );  //  6 html data length
		this.data.append( "AUDITDAT" );
		this.data.append( html );                                     //  ? html data
		this.data.append( "\n" );                                     //  1 linefeed character
	}


	private String
	checkForGuest( String p_studentId )
	{
		String studId = "";

		if ( bLoadedGuestId ) { studId = guestStudentId; }
		else
		{
			guestStudentId = (String) this.getProperties().getProperty( "guest.student.id" );
		    bLoadedGuestId = true;
			studId         = guestStudentId;
		}

		return (String) studId;
	}
}
