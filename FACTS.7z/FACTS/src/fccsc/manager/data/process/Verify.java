package fccsc.manager.data.process;

import intarsys.util.*;

import edu.fscj.student.StudentPasswordClient;
import fccsc.manager.broker.*;
import fccsc.manager.data.*;
import fccsc.manager.data.edi.*;


public final class Verify
	extends ProcessFEDI
{
	/**
	 * Creates an object to process VERIFY messages.
	 */
    public
	Verify()
    {
		super( "message.VERIFY.properties" );
    }


	/**
	 * Interface Method - Processing method.
	 * @throws Exception
	 */
	public void
	process() throws Exception
	{
		super.process();

		String studId  = this.getEDIStandardDataBlock().getStudentID();
		String studPwd = this.getEDIStandardDataBlock().getPinPassword();
//		System.out.println("Doing Pin Verify");
		//change to ldap password
		
		StudentPasswordClient client = new StudentPasswordClient();
		
		String rtndata = client.getStudentSSNDOBAfterAuthentication(studId.trim(), studPwd.trim());
	
//		System.out.println("rtndata = " + rtndata);
		int begint = rtndata.indexOf('|');
		if( begint > -1) {
			studId = rtndata.substring(0,begint);
			studPwd = rtndata.substring(begint + 1, rtndata.length());
		}
		
		//end of change to ldap password
		
		
		String term    = "";

		studId  = (String) StringTools.padRight( studId,  12, ' ' );
		studPwd = (String) StringTools.padRight( studPwd, 15, ' ' );
		term    = (String) StringTools.padRight(      "", 6, ' ' );

//		System.out.println("In Verify ");
//		System.out.println("studId = " + studId.trim());
//		System.out.println("studPwd = " + studPwd.trim());
		
		String data = studId + studPwd + term;

		EntireXBroker broker = new EntireXBroker( this.getProperties() );
		broker.sendMessage( data );

		// get response message
		String response     = (String) broker.getResponse();
/*		String resRC        = (String) response.substring( 96,   96 + 4   );
		String resDemoGrafx = (String) response.substring( 100, 100 + 240 );
*/
		
		String resRC       = (String) response.substring(    108,    108 +     4 );
		String resDemoGrafx  = (String) response.substring(   113,   113 + 240 );
		if ( logger.isDebugEnabled() )
		{
			logger.debug( "Broker Response [" + response + "]" );
		}

		if ( resRC.equalsIgnoreCase( "0000" ) )
		{
		    resRC = ReturnCodes.CODE_00000;
		}

		if ( resDemoGrafx.trim().length() == 0 )
		{
		    resRC        = ReturnCodes.CODE_00048;
			resDemoGrafx = ReturnCodes.CODE_00048_MESSAGE;

			logger.error( "Error [" + resRC + " - " + resDemoGrafx + "]" );
		}

		this.getEDIStandardDataBlock().setReturnCode(    resRC );
		this.getEDIStandardDataBlock().setReturnMessage( "" );


		this.setResponse(   (String) this.getEDIControlBlock().getData() +
									 this.getEDIStandardDataBlock().getData() );
		System.out.println("_______________________________________________________________________");
		System.out.println("Response back starts for Verify");
		System.out.println(this.getResponse());
		System.out.println("End of Response");
		System.out.println("_______________________________________________________________________");
		
	}
}