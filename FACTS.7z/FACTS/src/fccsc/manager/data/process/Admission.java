package fccsc.manager.data.process;

import intarsys.mail.MailSender;
import intarsys.util.PropertyManager;
import intarsys.util.StringTools;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;
import java.util.Vector;

import javax.mail.MessagingException;

import com.FACTS.TransApp.Log.util.DBUtil;

import edu.fccj.student.stawfac1.bean.StawFac1Bean;
import edu.fccj.student.stawfac1.client.StawFac1Client;
import edu.fccj.student.stawfac4.client.StawFac4Client;
import fccsc.manager.data.Email;
import fccsc.manager.data.ReturnCodes;


public final class Admission
	extends ProcessFXML
{
    public
	Admission()
    {
		super( "message.ADMISSION.properties" );
    }


   

   
	/**
	 * Interface Method - Processing method.
	 */
	public void
	process() throws Exception
	{
		super.process();
		String data = this.getXMLFactsMessage().getXML();
		Date date = new Date();
//		System.out.println("data in from FACTS");
//	    System.out.println("------------------------------------------------------------------------------------------------------------");
//		System.out.println(data);
		//new 
		
		StawFac1Bean studRec = new StawFac1Bean();
		StawFac1Client client = new StawFac1Client();
//		 System.out.println("start the data parsing.");
	    studRec = client.parseFACTSXML(data);
//	    System.out.println("end the data parsing.");
//	    System.out.println("Student = " + studRec.getFRST_NM() + " " + studRec.getLST_NM());
	    edu.fccj.student.utils.DBWrite dbw = new edu.fccj.student.utils.DBWrite();
	        try{
	        	dbw.AddTransactionToDb(studRec.getFRST_NM(), studRec.getLST_NM(), data);
	        }catch (Exception ex) {
//	        	System.out.println("Error in call to database " + ex.toString() );	        	
	        }finally {
	        	dbw.closeConn();
	        }
	       
	        try{
//	        	System.out.println("Doing Call to stawfac1");
	        	
	        	studRec = client.ExecuteStawFac1(studRec);
//	        	System.out.println("Return code = " + studRec.getRC());
//	        	System.out.println("Return message = " + studRec.getRC_MSG());
	        	studRec.setADDMISSION_RESP_TYPE(date.getTime() + "");
	        }catch (Exception ex) {
//	        	System.out.println("Error in call to stawfac1 " + ex.toString() );
	        	studRec.setRC("9999");
	        	studRec.setRC_MSG("Orion Issue Connection failed");
	        }
		
		if(studRec.getRC().equals("0000")) {
			
			
			String tmpValue = studRec.getADDMISSION_RESP_TYPE();
			if(tmpValue.length() < 25) {
				
				tmpValue = (String) StringTools.padLeft( tmpValue, 25, ' ' );
			}
			
			studRec.setConfNum(tmpValue);
			try{
//				System.out.println("Doing Call to stawfac4");
				StawFac4Client client2 = new StawFac4Client();
				client2.ExecuteStawfac4(studRec);
			}catch (Exception ex){
				System.out.println("Failed to complete stawfac4");
				System.out.println(ex.getMessage());
			}
			
			
			String response   = "<ADMISSION_RESP Type='C'>" + tmpValue + "</ADMISSION_RESP>";
			
			String resRC      = ReturnCodes.CODE_00000;
			String resMessage = ReturnCodes.CODE_00000_MESSAGE;
			
			
			this.getXMLFactsMessage().setRequestData(   response   );
			this.getXMLFactsMessage().setReturnCode(    resRC      );
			this.getXMLFactsMessage().setReturnMessage( resMessage );
			
			
		}else{
			//Failed so write to logs
			
			DBUtil service2 = new DBUtil("Test");
			String sUserID = "";
			String sPWD = "";
			String sFName = studRec.getFRST_NM();
			String sLName = studRec.getLST_NM();
			String sMName = studRec.getMDL_NM();
			String sAppendage = "";
			String sSSN = studRec.getSTDNT_ID();
			String sDOB = studRec.getDOB();
			String sDTime = "";
			String secQst = "";
			String secAns = "";
			
			DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
			
			sDTime = dateFormat.format(date);
			
			//First call to log
//			System.out.println("Logging to Mem App Log First call");
			String appId = service2.createStudApp(sUserID, sPWD, sFName, sLName, sMName, sAppendage, sSSN, sDOB, sDTime, secQst, secAns);
			
			
			
			//Second call to log
//			System.out.println("Logging to Mem App Log Second call");
			String retCode = studRec.getRC();
			String retMsg = "FACTS Transient Application Error: " + studRec.getRC_MSG();
			String complete = "Y";
			String dtSubm = sDTime;
			//System.out.println(retMsg);
			service2 = new DBUtil("Test");
			service2.setTblStatus(appId, retCode, retMsg, complete, dtSubm, "", "");
			
			service2 = new DBUtil("Test");
			service2.updateShoppingCart(appId);
//			if(studRec.getRC().length() < 5) {
//				String tmpValue = studRec.getRC();
//				
//				tmpValue = (String) StringTools.padLeft( tmpValue, 5, '0' );
//				studRec.setRC(tmpValue);
//			}
//			String response   = "<ADMISSION_RESP Type='C'>" + "</ADMISSION_RESP>";
//			
//			String resRC      = studRec.getRC();
//			String resMessage = studRec.getRC_MSG();
			
			
			
			
			
			String tmpValue = studRec.getADDMISSION_RESP_TYPE();
						
			
			if(tmpValue.length() < 25) {
				
				tmpValue = (String) StringTools.padLeft( tmpValue, 25, ' ' );
			}
			
			
			String response   = "<ADMISSION_RESP Type='C'>" + tmpValue + "</ADMISSION_RESP>";
			
			String resRC      = "99999";
			String resMessage = "Invalid " + studRec.getRC_MSG();
						
			this.getXMLFactsMessage().setRequestData(   response   );
			this.getXMLFactsMessage().setReturnCode(    resRC      );
			this.getXMLFactsMessage().setReturnMessage( resMessage );
		}
		
		
/*		// send the entire XML message
		
	
		
		EntireXBroker broker = new EntireXBroker( this.getProperties() );
		broker.sendMessage( data );

		// get response message
		String response   = broker.getResponse();
		String resRC      = ReturnCodes.CODE_00000;
		String resMessage = ReturnCodes.CODE_00000_MESSAGE;

		if ( logger.isDebugEnabled() )
		{
			logger.debug( "Broker Response [" + response + "]" );
		}

		if ( response.trim().length() == 0 )
		{
			resRC      = ReturnCodes.CODE_00048;
			resMessage = ReturnCodes.CODE_00048_MESSAGE;

			logger.error( "Error [" + resRC + " - " + resMessage + "]" );
		}
		else
		{
			/////////////////////////////////////////////////////////////////
			// test to check if data is an xml ERROR structure
			// if so, get STATUS information
			//
			ErrorHandler handlerError = new ErrorHandler();
			new SAXManager().parseSAXString( handlerError, response.trim() );

			if ( handlerError.isErrorMessage() )
			{
				response   = "";
				resRC      = ReturnCodes.CODE_00200;
				resMessage = handlerError.getStatus();

				logger.error( "Error [" + resRC + " - " + resMessage + "]" );
			}
			else // not an error message
			{
				/////////////////////////////////////////////////////////////////
				// parse ADMISSION_RESP message and get CONFIRM number
				// then build response message
				//
				
				AdmissionResponseHandler handler = new AdmissionResponseHandler();
				new SAXManager().parseSAXString( handler, response.trim() );

				if ( handler.isAdmissionResponse() )
				{
					response   = "<ADMISSION_RESP Type='C'>" + handler.getConfirm() + "</ADMISSION_RESP>";
					resRC      = handler.getReturnCode();
					resMessage = handler.getReturnMessage();

					this.processEmails( (Vector) handler.getEmails() );
				}
			}
		}

		this.getXMLFactsMessage().setRequestData(   response   );
		this.getXMLFactsMessage().setReturnCode(    resRC      );
		this.getXMLFactsMessage().setReturnMessage( resMessage );


		//////////////////////////////////////////////////////////////
		// build response and store
		//
		int lenCB    = this.getEDIControlBlock().SIZE;
		int lenFM    = this.getXMLFactsMessage().getXML().length();
		int lenTotal = lenCB + lenFM;

	    this.getEDIControlBlock().setTotalRecordSize( String.valueOf( (int) lenTotal ) );
*/
		int lenCB    = this.getEDIControlBlock().SIZE;
		int lenFM    = this.getXMLFactsMessage().getXML().length();
		int lenTotal = lenCB + lenFM;

	    this.getEDIControlBlock().setTotalRecordSize( String.valueOf( (int) lenTotal ) );
	    
	    String rtnStr = this.getEDIControlBlock().getData() +    this.getXMLFactsMessage().getXML() ;
//	    System.out.println("What we are sending back to FACTS.");
//	    System.out.println(rtnStr);
//	    System.out.println("Done");
//	    System.out.println("------------------------------------------------------------------------------------------------------------");
//	    System.out.println("");
		this.setResponse( rtnStr  );
	}


//	public static String getRandomNum() {
//		int aStart = 1;
//		long aEnd = 999999999999999999L;
//		Random aRandom = new Random();
//		
//		long range = aEnd - (long)aStart +1;
//		long fraction = (long)(range * aRandom.nextDouble());
//		int randomNumber = (int)(fraction + aStart);
//		return ("" + randomNumber);
//	}
//	
	
	private void
	processEmails( Vector p_vEmails )
	{
		String mailActive = (String) this.getProperties().getProperty( "mail.notification" );

		if ( ! mailActive.equalsIgnoreCase( "ON" ) )
		{
		    
			logger.warn( "Email notification is [" + mailActive + "]. (message.ADMISSION.properties)" );
		}
		// notification is ON !
		else
		{
		    if ( logger.isDebugEnabled() )
			{
				logger.debug( "Sending [" + p_vEmails.size() + "] email notifications ... " );
			}

			Properties prop     = (Properties) PropertyManager.getProperty( "mail.properties" );
			MailSender mail     = new MailSender( prop );
			Email      email    = null;
			Vector     vAddress = null;

			for ( int i = 0; i < p_vEmails.size(); i++ )
			{
				email = (Email) p_vEmails.elementAt( i );

				if ( logger.isDebugEnabled() )
				{
					logger.debug( "Sending [" + i + "] " + email.toString() );
				}

				// add FROM addresses
				vAddress = (Vector) email.getAddressFROM();
				if ( vAddress != null )
				{
					for ( int j = 0; j < vAddress.size(); j++ )
					{
						// set the intial from address
						if ( j == 0 ) { mail.setAddressFROM( (String) vAddress.elementAt( j ) ); }

						mail.addAddressFROM( (String) vAddress.elementAt( j ) );
					}
				}

				// add TO addresses
				vAddress = (Vector) email.getAddressTO();
				if ( vAddress != null )
				{
					for ( int j = 0; j < vAddress.size(); j++ )
					{
						mail.addAddressTO( (String) vAddress.elementAt( j ) );
					}
				}

				// add CC addresses
				vAddress = (Vector) email.getAddressCC();
				if ( vAddress != null )
				{
					for ( int j = 0; j < vAddress.size(); j++ )
					{
						mail.addAddressCC( (String) vAddress.elementAt( j ) );
					}
				}

				// add BCC addresses
				vAddress = (Vector) email.getAddressBCC();
				if ( vAddress != null )
				{
					for ( int j = 0; j < vAddress.size(); j++ )
					{
						mail.addAddressBCC( (String) vAddress.elementAt( j ) );
					}
				}

				try
				{
					mail.setContentType( ( String ) email.getContentType() );
					mail.setSubject( ( String ) email.getSubject() );
					mail.setMessage( ( String ) email.getBody() );
					mail.send();
					mail.clear();
				}
				catch ( MessagingException ex )
				{
					logger.error( "Sending mail notification [" + ex.getMessage() + "]" );
				}
			}
		}
	}
}

