package fccsc.manager.data.process;

import intarsys.util.*;

import edu.fscj.student.StudentPasswordClient;
import fccsc.manager.broker.*;
import fccsc.manager.data.*;
import fccsc.manager.data.edi.*;
import fccsc.manager.util.*;


public final class GradAudit
	extends ProcessFEDI
{
	private StringBuffer data = new StringBuffer();


	/**
	 * Creates an object to process a GRADAUDIT message.
	 */
    public
	GradAudit()
    {
		super( "message.GRADAUDIT.properties" );
    }


	/**
	 * Interface Method - Processing method.
	 * @throws Exception
	 */
	public void
	process() throws Exception
	{
		super.process();

		String studId  = this.getEDIStandardDataBlock().getStudentID();
		String studPwd = this.getEDIStandardDataBlock().getPinPassword();
		String program = "     ";  // 5 bytes
		String award   = "   ";    // 3 bytes
		String term    = "      "; // 6 bytes
//		System.out.println("In GradAudit ");
//		System.out.println("studId = " + studId.trim());
//		System.out.println("studPwd = " + studPwd.trim());
		
		// change to ldap password

		StudentPasswordClient client = new StudentPasswordClient();

		if (studPwd.trim().length() > 0) {
			String rtndata = client.getStudentSSNDOBAfterAuthentication(studId
					.trim(), studPwd.trim());
			
			int begint = rtndata.indexOf('|');
			if (begint > -1) {
				studId = rtndata.substring(0, begint);
				studPwd = rtndata.substring(begint + 1, rtndata.length());
			}
		} else {
			String rtndata = client.getStudentSSNFromMIS(studId.trim());
			studId = rtndata;

		}

		// end of change to ldap password
		
		
		
		studId  = (String) StringTools.padRight( studId,  9, ' ' );
		studPwd = (String) StringTools.padRight( studPwd, 6, ' ' );

		String data = studId + studPwd + program + award + term;

		EntireXBroker broker = new EntireXBroker( this.getProperties() );
		broker.sendMessage( data );

		// get response message
		String response    = (String) broker.getResponse();
		//String resParams   = (String) response.substring(     0,     0 +    29 );
		//String resExpand   = (String) response.substring(    29,    29 +    68 );
		
		//old 12/11/09 change mdt
		//String resRC       = (String) response.substring(    97,    97 +     4 );
		//String resDA       = (String) response.substring(   101,   101 + 23700 );
		String resRC       = (String) response.substring(    109,    109 +     4 );
		String resDA       = (String) response.substring(   113,   response.length() );
		//String resExpand2  = (String) response.substring( 23801, 23801 +  2199 );
		String resMessage  = "";
		
		
	
		if ( logger.isDebugEnabled() )
		{
			logger.debug( "Broker Response [" + response + "]" );
		}

		if ( resRC.equalsIgnoreCase( "0000" ) )
		{
		    resRC      = ReturnCodes.CODE_00000;
			resMessage = ReturnCodes.CODE_00000_MESSAGE;
		}
		else
		{
			resMessage = resDA.trim();
		}

		if ( resDA.trim().length() == 0 )
		{
		    resRC      = ReturnCodes.CODE_00048;
			resMessage = ReturnCodes.CODE_00048_MESSAGE;

			logger.error( "Error [" + resRC + " - " + resMessage + "]" );
		}

		if ( resRC.equalsIgnoreCase( ReturnCodes.CODE_00000 ) )
		{
		    processData( resDA );
		}

		this.getEDIStandardDataBlock().setReturnCode(    resRC      );
    	this.getEDIStandardDataBlock().setReturnMessage( resMessage );

		//////////////////////////////////////////////////////////////
		// build response and store
		//
		StringBuffer buffer = new StringBuffer();

		int lenTRS   = Integer.parseInt( (String) this.getEDIControlBlock().getTotalRecordSize() );
		int lenPDB   = this.data.length();
		int lenTotal = lenTRS + lenPDB;

		this.getEDIControlBlock().setTotalRecordSize( String.valueOf( (int) lenTotal ) );

		buffer.append( (String) this.getEDIControlBlock().getData() );
		buffer.append( (String) this.getEDIStandardDataBlock().getData() );
		buffer.append( (String) this.data.toString() );

		this.setResponse( (String) buffer.toString() );
		
		System.out.println("_______________________________________________________________________");
		System.out.println("Response back starts for GradAudit");
		System.out.println(this.getResponse());
		System.out.println("End of Response");
		System.out.println("_______________________________________________________________________");
	}


	private void
	processData( String p_data )
	{
		////////////////////////////////////////////////////////////////
		// data parsing
		//
		StringBuffer buffer = new StringBuffer();
		String       html   = "";
		String       line   = "";   // 79 bytes
		int          MAX    = 79;   // max # bytes a line can have
		int          len    = (int) p_data.length();

		for ( int i = 0; i < len; /**/ )
		{
			if ( (i + MAX) <= len )
			{
			    line = (String) p_data.substring( i, i + MAX );
				i = i + MAX;
			}
			else
			{
			    line = (String) p_data.substring( i );
				i = len;
			}

		    if ( line.trim().length() > 0 )
			{
				// adds this ... <HR> before this ...
				//                   *** Program of Study Course Requirements ***
				//
				if ( line.indexOf( "   *** " ) > -1 )
				{
					buffer.append( "<hr>\n" );
				}
				// adds this ... <HR Align=Center Width=65%> before this ...
				//     Area 01:(07A) GENERAL EDUCATION              Min.Hours:18.00 Min.Crses: 6
				//
				else if ( (line.indexOf( "   Area " ) > -1) && (line.indexOf( "Min.Crses" ) > -1) )
				{
					buffer.append( "<hr align='center' width='65%'>\n" );
				}

				// trim off trailing spaces
				line = StringTools.trimTrailingWhitespace( line );

			    buffer.append( line + "\n" );  // line + carriage return + linefeed character
				
			}
		}

		////////////////////////////////////////////////////////////////
		// populate a template
		html = (String) TemplateManager.populate( "GRADAUDIT.template", buffer.toString() );

		////////////////////////////////////////////////////////////////
		// build "Process Data Block" section
		//
		String lenHtml = (String) String.valueOf( (int) html.length() );

		this.data.append( StringTools.padRight(      "", 8, ' ' ) );  //  8 filler
		this.data.append( StringTools.padLeft(  lenHtml, 6, '0' ) );  //  6 html data length
		this.data.append( "AUDITDAT" );
		this.data.append( html );                                     //  ? html data
		this.data.append( "\n" );                                     //  1 linefeed character
	}
}