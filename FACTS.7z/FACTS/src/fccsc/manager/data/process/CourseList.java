package fccsc.manager.data.process;

import intarsys.util.*;

import edu.fscj.student.StudentPasswordClient;
import fccsc.manager.broker.*;
import fccsc.manager.data.*;
import fccsc.manager.data.edi.*;


public final class CourseList
	extends ProcessFEDI
{
    public
	CourseList()
    {
		super( "message.COURSELIST.properties" );
    }

	/**
	 * Interface Method - Processing method.
	 * @throws Exception
	 */
	public void
	process() throws Exception
	{
		super.process();

		// setup our return codes
		String resRC      = ReturnCodes.CODE_00000;
		String resMessage = ReturnCodes.CODE_00000_MESSAGE;
		String clData     = "";

		
		String studId  = this.getEDIStandardDataBlock().getStudentID();
		String studPwd = this.getEDIStandardDataBlock().getPinPassword();
		
		// change to ldap password

		StudentPasswordClient client = new StudentPasswordClient();

		String rtndata = client.getStudentSSNDOBFromMIS(studId);
		studPwd = "  ";
		
		int begint = rtndata.indexOf('|');
		if( begint > -1) {
			studId = rtndata.substring(0,begint);
			studPwd = rtndata.substring(begint + 1, rtndata.length());
		}

		// end of change to ldap password
	
		studId  = (String) StringTools.padRight( studId,  9, ' ' );
		studPwd = (String) StringTools.padRight( studPwd, 6, ' ' );

		String data = studId + studPwd;
	
		
		EntireXBroker broker = new EntireXBroker( this.getProperties() );
		
		
		broker.sendMessage( data );

		// get response message
		String response      = (String) broker.getResponse();
		response.replaceAll(studId, this.getEDIStandardDataBlock().getStudentID());
		
		
		//String resParams     = (String) response.substring(   0,   0 + 15    );
		//String resExpand     = (String) response.substring(  15,  15 + 85    );
		String resCourseList = (String) response.substring( 100, 100 + 25900 );
		//mdt 1/26/11 start
		//resRC       = (String) response.substring(    108,    108 +     4 );	
		//String resDemoGrafx  = (String) response.substring(   113,   113 + 240 );
		resRC       = (String) response.substring(    96,    96 +     4 );	
		String resDemoGrafx  = (String) response.substring(   101,   101 + 240 );
		
		//mdt 1/26/11 end
		if ( logger.isDebugEnabled() )
		{
			logger.debug( "Broker Response [" + response + "]" );
		}

		if ( resCourseList.trim().length() == 0 )
		{
			resRC      = ReturnCodes.CODE_00048;
	    	resMessage = ReturnCodes.CODE_00048_MESSAGE;
			clData     = "";

			logger.error( "Error [" + resRC + " - " + resMessage + "]" );
		}
		else
		{
			CourseListBlock ediCLB = new CourseListBlock( this.getEDIStandardDataBlock().getStudentID(), resCourseList );
	    	ediCLB.buildResponse();
			clData = ediCLB.getData();
		}

		this.getEDIStandardDataBlock().setReturnCode(    resRC );
		this.getEDIStandardDataBlock().setReturnMessage( resMessage );


		//////////////////////////////////////////////////////////////
		// build response and store
		//
		StringBuffer buffer = new StringBuffer();
		int mysize = this.getRequest().length();
		
		String dataPDB = "";
		if(mysize == 822) {
			mysize = mysize - ControlBlock.SIZE;
			dataPDB = this.getRequest().substring( ControlBlock.SIZE + mysize );//mdt this is where it blows up.
		}else{
			dataPDB = this.getRequest().substring( ControlBlock.SIZE + StandardDataBlock.SIZE );
		}
		String value = this.getEDIStandardDataBlock().getReturnCode();

		//int lenTRS   = Integer.parseInt( (String) this.getEDIControlBlock().getTotalRecordSize() );
		int lenPDB   = dataPDB.length();
		int lenCL    = clData.length();
		int lenTotal = ControlBlock.SIZE + 822 + lenPDB + lenCL;

		this.getEDIControlBlock().setTotalRecordSize( String.valueOf( (int) lenTotal ) );

		buffer.append( (String) this.getEDIControlBlock().getData() );
		buffer.append( (String) this.getEDIStandardDataBlock().getData() );
		buffer.append( (String) dataPDB );
		buffer.append( (String) clData );
		
		
		
//		System.out.println("EDIControlBlock = " + this.getEDIControlBlock().getData() );
//		System.out.println("EDIStandardDataBlock = " + this.getEDIStandardDataBlock().getData() );
//		System.out.println("dataPDB = " + dataPDB);
//		System.out.println("clData = " + clData);
		
		//mdt added 1/26/11
		String tempBuff = buffer.toString();
		
		
		
		String recLength = tempBuff.substring(0, 6);
		int recIntLength = Integer.parseInt(recLength);
		
		if(recIntLength > tempBuff.length()) {
			buffer = new StringBuffer();
			this.getEDIControlBlock().setTotalRecordSize( String.valueOf( (int) tempBuff.length() ) );
			buffer.append( (String) this.getEDIControlBlock().getData() );
			buffer.append( (String) this.getEDIStandardDataBlock().getData() );
			buffer.append( (String) dataPDB );
			buffer.append( (String) clData );
			tempBuff = buffer.toString();
			
		}
		
		tempBuff.replaceAll(studId, this.getEDIStandardDataBlock().getStudentID());
			

		this.setResponse( tempBuff );
		System.out.println("_______________________________________________________________________");
		System.out.println("Response back starts for CourseList");
		System.out.println(this.getResponse());
		System.out.println("End of Response");
		System.out.println("_______________________________________________________________________");
		//this.setResponse( (String) buffer.toString() );
		//mdt end of add
		
	}
}