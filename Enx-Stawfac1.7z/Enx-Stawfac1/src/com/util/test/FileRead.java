package com.util.test;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

import edu.fccj.student.stawfac1.bean.StawFac1Bean;

public class FileRead {

	
	public String readXMLFile(String filename){
		StringBuffer sb = new StringBuffer();

	    try {
	        BufferedReader in = new BufferedReader(new FileReader(filename));
	        String str;
	        while ((str = in.readLine()) != null) {
	            sb.append(str);
	        }
	        in.close();
	    } catch (IOException e) {
	    }

	    return sb.toString();

	}
}
