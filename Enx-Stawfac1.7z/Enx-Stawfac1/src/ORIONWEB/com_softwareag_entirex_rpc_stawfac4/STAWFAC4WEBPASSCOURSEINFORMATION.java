/**
 * STAWFAC4WEBPASSCOURSEINFORMATION.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package ORIONWEB.com_softwareag_entirex_rpc_stawfac4;

public class STAWFAC4WEBPASSCOURSEINFORMATION  implements java.io.Serializable {
    private java.lang.String[] CRSID;

    private java.lang.String[] CRSTITLE;

    private java.math.BigDecimal[] CRSCREDITHOURS;

    private java.lang.String[] CRSUSES;

    private java.lang.String[] EQUIVALENT;

    private java.lang.String[] CRSAPPROVAL;

    private java.lang.String[] CRSDISTANCELEARNING;

    private java.lang.String[] CRSFAELIGIBILITY;

    public STAWFAC4WEBPASSCOURSEINFORMATION() {
    }

    public STAWFAC4WEBPASSCOURSEINFORMATION(
           java.lang.String[] CRSID,
           java.lang.String[] CRSTITLE,
           java.math.BigDecimal[] CRSCREDITHOURS,
           java.lang.String[] CRSUSES,
           java.lang.String[] EQUIVALENT,
           java.lang.String[] CRSAPPROVAL,
           java.lang.String[] CRSDISTANCELEARNING,
           java.lang.String[] CRSFAELIGIBILITY) {
           this.CRSID = CRSID;
           this.CRSTITLE = CRSTITLE;
           this.CRSCREDITHOURS = CRSCREDITHOURS;
           this.CRSUSES = CRSUSES;
           this.EQUIVALENT = EQUIVALENT;
           this.CRSAPPROVAL = CRSAPPROVAL;
           this.CRSDISTANCELEARNING = CRSDISTANCELEARNING;
           this.CRSFAELIGIBILITY = CRSFAELIGIBILITY;
    }


    /**
     * Gets the CRSID value for this STAWFAC4WEBPASSCOURSEINFORMATION.
     * 
     * @return CRSID
     */
    public java.lang.String[] getCRSID() {
        return CRSID;
    }


    /**
     * Sets the CRSID value for this STAWFAC4WEBPASSCOURSEINFORMATION.
     * 
     * @param CRSID
     */
    public void setCRSID(java.lang.String[] CRSID) {
        this.CRSID = CRSID;
    }


    /**
     * Gets the CRSTITLE value for this STAWFAC4WEBPASSCOURSEINFORMATION.
     * 
     * @return CRSTITLE
     */
    public java.lang.String[] getCRSTITLE() {
        return CRSTITLE;
    }


    /**
     * Sets the CRSTITLE value for this STAWFAC4WEBPASSCOURSEINFORMATION.
     * 
     * @param CRSTITLE
     */
    public void setCRSTITLE(java.lang.String[] CRSTITLE) {
        this.CRSTITLE = CRSTITLE;
    }


    /**
     * Gets the CRSCREDITHOURS value for this STAWFAC4WEBPASSCOURSEINFORMATION.
     * 
     * @return CRSCREDITHOURS
     */
    public java.math.BigDecimal[] getCRSCREDITHOURS() {
        return CRSCREDITHOURS;
    }


    /**
     * Sets the CRSCREDITHOURS value for this STAWFAC4WEBPASSCOURSEINFORMATION.
     * 
     * @param CRSCREDITHOURS
     */
    public void setCRSCREDITHOURS(java.math.BigDecimal[] CRSCREDITHOURS) {
        this.CRSCREDITHOURS = CRSCREDITHOURS;
    }


    /**
     * Gets the CRSUSES value for this STAWFAC4WEBPASSCOURSEINFORMATION.
     * 
     * @return CRSUSES
     */
    public java.lang.String[] getCRSUSES() {
        return CRSUSES;
    }


    /**
     * Sets the CRSUSES value for this STAWFAC4WEBPASSCOURSEINFORMATION.
     * 
     * @param CRSUSES
     */
    public void setCRSUSES(java.lang.String[] CRSUSES) {
        this.CRSUSES = CRSUSES;
    }


    /**
     * Gets the EQUIVALENT value for this STAWFAC4WEBPASSCOURSEINFORMATION.
     * 
     * @return EQUIVALENT
     */
    public java.lang.String[] getEQUIVALENT() {
        return EQUIVALENT;
    }


    /**
     * Sets the EQUIVALENT value for this STAWFAC4WEBPASSCOURSEINFORMATION.
     * 
     * @param EQUIVALENT
     */
    public void setEQUIVALENT(java.lang.String[] EQUIVALENT) {
        this.EQUIVALENT = EQUIVALENT;
    }


    /**
     * Gets the CRSAPPROVAL value for this STAWFAC4WEBPASSCOURSEINFORMATION.
     * 
     * @return CRSAPPROVAL
     */
    public java.lang.String[] getCRSAPPROVAL() {
        return CRSAPPROVAL;
    }


    /**
     * Sets the CRSAPPROVAL value for this STAWFAC4WEBPASSCOURSEINFORMATION.
     * 
     * @param CRSAPPROVAL
     */
    public void setCRSAPPROVAL(java.lang.String[] CRSAPPROVAL) {
        this.CRSAPPROVAL = CRSAPPROVAL;
    }


    /**
     * Gets the CRSDISTANCELEARNING value for this STAWFAC4WEBPASSCOURSEINFORMATION.
     * 
     * @return CRSDISTANCELEARNING
     */
    public java.lang.String[] getCRSDISTANCELEARNING() {
        return CRSDISTANCELEARNING;
    }


    /**
     * Sets the CRSDISTANCELEARNING value for this STAWFAC4WEBPASSCOURSEINFORMATION.
     * 
     * @param CRSDISTANCELEARNING
     */
    public void setCRSDISTANCELEARNING(java.lang.String[] CRSDISTANCELEARNING) {
        this.CRSDISTANCELEARNING = CRSDISTANCELEARNING;
    }


    /**
     * Gets the CRSFAELIGIBILITY value for this STAWFAC4WEBPASSCOURSEINFORMATION.
     * 
     * @return CRSFAELIGIBILITY
     */
    public java.lang.String[] getCRSFAELIGIBILITY() {
        return CRSFAELIGIBILITY;
    }


    /**
     * Sets the CRSFAELIGIBILITY value for this STAWFAC4WEBPASSCOURSEINFORMATION.
     * 
     * @param CRSFAELIGIBILITY
     */
    public void setCRSFAELIGIBILITY(java.lang.String[] CRSFAELIGIBILITY) {
        this.CRSFAELIGIBILITY = CRSFAELIGIBILITY;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof STAWFAC4WEBPASSCOURSEINFORMATION)) return false;
        STAWFAC4WEBPASSCOURSEINFORMATION other = (STAWFAC4WEBPASSCOURSEINFORMATION) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.CRSID==null && other.getCRSID()==null) || 
             (this.CRSID!=null &&
              java.util.Arrays.equals(this.CRSID, other.getCRSID()))) &&
            ((this.CRSTITLE==null && other.getCRSTITLE()==null) || 
             (this.CRSTITLE!=null &&
              java.util.Arrays.equals(this.CRSTITLE, other.getCRSTITLE()))) &&
            ((this.CRSCREDITHOURS==null && other.getCRSCREDITHOURS()==null) || 
             (this.CRSCREDITHOURS!=null &&
              java.util.Arrays.equals(this.CRSCREDITHOURS, other.getCRSCREDITHOURS()))) &&
            ((this.CRSUSES==null && other.getCRSUSES()==null) || 
             (this.CRSUSES!=null &&
              java.util.Arrays.equals(this.CRSUSES, other.getCRSUSES()))) &&
            ((this.EQUIVALENT==null && other.getEQUIVALENT()==null) || 
             (this.EQUIVALENT!=null &&
              java.util.Arrays.equals(this.EQUIVALENT, other.getEQUIVALENT()))) &&
            ((this.CRSAPPROVAL==null && other.getCRSAPPROVAL()==null) || 
             (this.CRSAPPROVAL!=null &&
              java.util.Arrays.equals(this.CRSAPPROVAL, other.getCRSAPPROVAL()))) &&
            ((this.CRSDISTANCELEARNING==null && other.getCRSDISTANCELEARNING()==null) || 
             (this.CRSDISTANCELEARNING!=null &&
              java.util.Arrays.equals(this.CRSDISTANCELEARNING, other.getCRSDISTANCELEARNING()))) &&
            ((this.CRSFAELIGIBILITY==null && other.getCRSFAELIGIBILITY()==null) || 
             (this.CRSFAELIGIBILITY!=null &&
              java.util.Arrays.equals(this.CRSFAELIGIBILITY, other.getCRSFAELIGIBILITY())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getCRSID() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getCRSID());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getCRSID(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getCRSTITLE() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getCRSTITLE());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getCRSTITLE(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getCRSCREDITHOURS() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getCRSCREDITHOURS());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getCRSCREDITHOURS(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getCRSUSES() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getCRSUSES());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getCRSUSES(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getEQUIVALENT() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getEQUIVALENT());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getEQUIVALENT(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getCRSAPPROVAL() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getCRSAPPROVAL());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getCRSAPPROVAL(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getCRSDISTANCELEARNING() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getCRSDISTANCELEARNING());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getCRSDISTANCELEARNING(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getCRSFAELIGIBILITY() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getCRSFAELIGIBILITY());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getCRSFAELIGIBILITY(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(STAWFAC4WEBPASSCOURSEINFORMATION.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("urn:com-softwareag-entirex-rpc:ORIONWEB", ">>>STAWFAC4>WEB-PASS>COURSE-INFORMATION"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CRSID");
        elemField.setXmlName(new javax.xml.namespace.QName("", "CRS-ID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("", "string"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CRSTITLE");
        elemField.setXmlName(new javax.xml.namespace.QName("", "CRS-TITLE"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("", "string"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CRSCREDITHOURS");
        elemField.setXmlName(new javax.xml.namespace.QName("", "CRS-CREDIT-HOURS"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "decimal"));
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("", "decimal"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CRSUSES");
        elemField.setXmlName(new javax.xml.namespace.QName("", "CRS-USES"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("", "string"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("EQUIVALENT");
        elemField.setXmlName(new javax.xml.namespace.QName("", "EQUIVALENT"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("", "string"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CRSAPPROVAL");
        elemField.setXmlName(new javax.xml.namespace.QName("", "CRS-APPROVAL"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("", "string"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CRSDISTANCELEARNING");
        elemField.setXmlName(new javax.xml.namespace.QName("", "CRS-DISTANCE-LEARNING"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("", "string"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CRSFAELIGIBILITY");
        elemField.setXmlName(new javax.xml.namespace.QName("", "CRS-FA-ELIGIBILITY"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("", "string"));
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
