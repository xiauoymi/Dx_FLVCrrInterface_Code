/**
 * STAWFAC4ResponseWEBPASS1COURSEINFORMATION1.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package ORIONWEB.com_softwareag_entirex_rpc_stawfac4;

public class STAWFAC4ResponseWEBPASS1COURSEINFORMATION1  implements java.io.Serializable {
    private java.lang.String[] CRSID1;

    private java.lang.String[] CRSTITLE1;

    private java.math.BigDecimal[] CRSCREDITHOURS1;

    private java.lang.String[] CRSUSES1;

    private java.lang.String[] EQUIVALENT1;

    private java.lang.String[] CRSAPPROVAL1;

    private java.lang.String[] CRSDISTANCELEARNING1;

    private java.lang.String[] CRSFAELIGIBILITY1;

    public STAWFAC4ResponseWEBPASS1COURSEINFORMATION1() {
    }

    public STAWFAC4ResponseWEBPASS1COURSEINFORMATION1(
           java.lang.String[] CRSID1,
           java.lang.String[] CRSTITLE1,
           java.math.BigDecimal[] CRSCREDITHOURS1,
           java.lang.String[] CRSUSES1,
           java.lang.String[] EQUIVALENT1,
           java.lang.String[] CRSAPPROVAL1,
           java.lang.String[] CRSDISTANCELEARNING1,
           java.lang.String[] CRSFAELIGIBILITY1) {
           this.CRSID1 = CRSID1;
           this.CRSTITLE1 = CRSTITLE1;
           this.CRSCREDITHOURS1 = CRSCREDITHOURS1;
           this.CRSUSES1 = CRSUSES1;
           this.EQUIVALENT1 = EQUIVALENT1;
           this.CRSAPPROVAL1 = CRSAPPROVAL1;
           this.CRSDISTANCELEARNING1 = CRSDISTANCELEARNING1;
           this.CRSFAELIGIBILITY1 = CRSFAELIGIBILITY1;
    }


    /**
     * Gets the CRSID1 value for this STAWFAC4ResponseWEBPASS1COURSEINFORMATION1.
     * 
     * @return CRSID1
     */
    public java.lang.String[] getCRSID1() {
        return CRSID1;
    }


    /**
     * Sets the CRSID1 value for this STAWFAC4ResponseWEBPASS1COURSEINFORMATION1.
     * 
     * @param CRSID1
     */
    public void setCRSID1(java.lang.String[] CRSID1) {
        this.CRSID1 = CRSID1;
    }


    /**
     * Gets the CRSTITLE1 value for this STAWFAC4ResponseWEBPASS1COURSEINFORMATION1.
     * 
     * @return CRSTITLE1
     */
    public java.lang.String[] getCRSTITLE1() {
        return CRSTITLE1;
    }


    /**
     * Sets the CRSTITLE1 value for this STAWFAC4ResponseWEBPASS1COURSEINFORMATION1.
     * 
     * @param CRSTITLE1
     */
    public void setCRSTITLE1(java.lang.String[] CRSTITLE1) {
        this.CRSTITLE1 = CRSTITLE1;
    }


    /**
     * Gets the CRSCREDITHOURS1 value for this STAWFAC4ResponseWEBPASS1COURSEINFORMATION1.
     * 
     * @return CRSCREDITHOURS1
     */
    public java.math.BigDecimal[] getCRSCREDITHOURS1() {
        return CRSCREDITHOURS1;
    }


    /**
     * Sets the CRSCREDITHOURS1 value for this STAWFAC4ResponseWEBPASS1COURSEINFORMATION1.
     * 
     * @param CRSCREDITHOURS1
     */
    public void setCRSCREDITHOURS1(java.math.BigDecimal[] CRSCREDITHOURS1) {
        this.CRSCREDITHOURS1 = CRSCREDITHOURS1;
    }


    /**
     * Gets the CRSUSES1 value for this STAWFAC4ResponseWEBPASS1COURSEINFORMATION1.
     * 
     * @return CRSUSES1
     */
    public java.lang.String[] getCRSUSES1() {
        return CRSUSES1;
    }


    /**
     * Sets the CRSUSES1 value for this STAWFAC4ResponseWEBPASS1COURSEINFORMATION1.
     * 
     * @param CRSUSES1
     */
    public void setCRSUSES1(java.lang.String[] CRSUSES1) {
        this.CRSUSES1 = CRSUSES1;
    }


    /**
     * Gets the EQUIVALENT1 value for this STAWFAC4ResponseWEBPASS1COURSEINFORMATION1.
     * 
     * @return EQUIVALENT1
     */
    public java.lang.String[] getEQUIVALENT1() {
        return EQUIVALENT1;
    }


    /**
     * Sets the EQUIVALENT1 value for this STAWFAC4ResponseWEBPASS1COURSEINFORMATION1.
     * 
     * @param EQUIVALENT1
     */
    public void setEQUIVALENT1(java.lang.String[] EQUIVALENT1) {
        this.EQUIVALENT1 = EQUIVALENT1;
    }


    /**
     * Gets the CRSAPPROVAL1 value for this STAWFAC4ResponseWEBPASS1COURSEINFORMATION1.
     * 
     * @return CRSAPPROVAL1
     */
    public java.lang.String[] getCRSAPPROVAL1() {
        return CRSAPPROVAL1;
    }


    /**
     * Sets the CRSAPPROVAL1 value for this STAWFAC4ResponseWEBPASS1COURSEINFORMATION1.
     * 
     * @param CRSAPPROVAL1
     */
    public void setCRSAPPROVAL1(java.lang.String[] CRSAPPROVAL1) {
        this.CRSAPPROVAL1 = CRSAPPROVAL1;
    }


    /**
     * Gets the CRSDISTANCELEARNING1 value for this STAWFAC4ResponseWEBPASS1COURSEINFORMATION1.
     * 
     * @return CRSDISTANCELEARNING1
     */
    public java.lang.String[] getCRSDISTANCELEARNING1() {
        return CRSDISTANCELEARNING1;
    }


    /**
     * Sets the CRSDISTANCELEARNING1 value for this STAWFAC4ResponseWEBPASS1COURSEINFORMATION1.
     * 
     * @param CRSDISTANCELEARNING1
     */
    public void setCRSDISTANCELEARNING1(java.lang.String[] CRSDISTANCELEARNING1) {
        this.CRSDISTANCELEARNING1 = CRSDISTANCELEARNING1;
    }


    /**
     * Gets the CRSFAELIGIBILITY1 value for this STAWFAC4ResponseWEBPASS1COURSEINFORMATION1.
     * 
     * @return CRSFAELIGIBILITY1
     */
    public java.lang.String[] getCRSFAELIGIBILITY1() {
        return CRSFAELIGIBILITY1;
    }


    /**
     * Sets the CRSFAELIGIBILITY1 value for this STAWFAC4ResponseWEBPASS1COURSEINFORMATION1.
     * 
     * @param CRSFAELIGIBILITY1
     */
    public void setCRSFAELIGIBILITY1(java.lang.String[] CRSFAELIGIBILITY1) {
        this.CRSFAELIGIBILITY1 = CRSFAELIGIBILITY1;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof STAWFAC4ResponseWEBPASS1COURSEINFORMATION1)) return false;
        STAWFAC4ResponseWEBPASS1COURSEINFORMATION1 other = (STAWFAC4ResponseWEBPASS1COURSEINFORMATION1) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.CRSID1==null && other.getCRSID1()==null) || 
             (this.CRSID1!=null &&
              java.util.Arrays.equals(this.CRSID1, other.getCRSID1()))) &&
            ((this.CRSTITLE1==null && other.getCRSTITLE1()==null) || 
             (this.CRSTITLE1!=null &&
              java.util.Arrays.equals(this.CRSTITLE1, other.getCRSTITLE1()))) &&
            ((this.CRSCREDITHOURS1==null && other.getCRSCREDITHOURS1()==null) || 
             (this.CRSCREDITHOURS1!=null &&
              java.util.Arrays.equals(this.CRSCREDITHOURS1, other.getCRSCREDITHOURS1()))) &&
            ((this.CRSUSES1==null && other.getCRSUSES1()==null) || 
             (this.CRSUSES1!=null &&
              java.util.Arrays.equals(this.CRSUSES1, other.getCRSUSES1()))) &&
            ((this.EQUIVALENT1==null && other.getEQUIVALENT1()==null) || 
             (this.EQUIVALENT1!=null &&
              java.util.Arrays.equals(this.EQUIVALENT1, other.getEQUIVALENT1()))) &&
            ((this.CRSAPPROVAL1==null && other.getCRSAPPROVAL1()==null) || 
             (this.CRSAPPROVAL1!=null &&
              java.util.Arrays.equals(this.CRSAPPROVAL1, other.getCRSAPPROVAL1()))) &&
            ((this.CRSDISTANCELEARNING1==null && other.getCRSDISTANCELEARNING1()==null) || 
             (this.CRSDISTANCELEARNING1!=null &&
              java.util.Arrays.equals(this.CRSDISTANCELEARNING1, other.getCRSDISTANCELEARNING1()))) &&
            ((this.CRSFAELIGIBILITY1==null && other.getCRSFAELIGIBILITY1()==null) || 
             (this.CRSFAELIGIBILITY1!=null &&
              java.util.Arrays.equals(this.CRSFAELIGIBILITY1, other.getCRSFAELIGIBILITY1())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getCRSID1() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getCRSID1());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getCRSID1(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getCRSTITLE1() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getCRSTITLE1());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getCRSTITLE1(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getCRSCREDITHOURS1() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getCRSCREDITHOURS1());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getCRSCREDITHOURS1(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getCRSUSES1() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getCRSUSES1());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getCRSUSES1(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getEQUIVALENT1() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getEQUIVALENT1());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getEQUIVALENT1(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getCRSAPPROVAL1() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getCRSAPPROVAL1());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getCRSAPPROVAL1(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getCRSDISTANCELEARNING1() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getCRSDISTANCELEARNING1());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getCRSDISTANCELEARNING1(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getCRSFAELIGIBILITY1() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getCRSFAELIGIBILITY1());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getCRSFAELIGIBILITY1(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(STAWFAC4ResponseWEBPASS1COURSEINFORMATION1.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("urn:com-softwareag-entirex-rpc:ORIONWEB", ">>>STAWFAC4Response>WEB-PASS1>COURSE-INFORMATION1"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CRSID1");
        elemField.setXmlName(new javax.xml.namespace.QName("", "CRS-ID1"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("", "string"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CRSTITLE1");
        elemField.setXmlName(new javax.xml.namespace.QName("", "CRS-TITLE1"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("", "string"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CRSCREDITHOURS1");
        elemField.setXmlName(new javax.xml.namespace.QName("", "CRS-CREDIT-HOURS1"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "decimal"));
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("", "decimal"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CRSUSES1");
        elemField.setXmlName(new javax.xml.namespace.QName("", "CRS-USES1"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("", "string"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("EQUIVALENT1");
        elemField.setXmlName(new javax.xml.namespace.QName("", "EQUIVALENT1"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("", "string"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CRSAPPROVAL1");
        elemField.setXmlName(new javax.xml.namespace.QName("", "CRS-APPROVAL1"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("", "string"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CRSDISTANCELEARNING1");
        elemField.setXmlName(new javax.xml.namespace.QName("", "CRS-DISTANCE-LEARNING1"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("", "string"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CRSFAELIGIBILITY1");
        elemField.setXmlName(new javax.xml.namespace.QName("", "CRS-FA-ELIGIBILITY1"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("", "string"));
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
