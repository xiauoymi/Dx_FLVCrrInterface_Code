/**
 * STAWFAC4ResponseWEBPASS1.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package ORIONWEB.com_softwareag_entirex_rpc_stawfac4;

public class STAWFAC4ResponseWEBPASS1  implements java.io.Serializable {
    private java.lang.String STDNTID1;

    private java.lang.String STDNTSSN1;

    private java.lang.String INSTID1;

    private java.lang.String INSTTYPE1;

    private java.lang.String RECVDDATE1;

    private java.lang.String RECVDTIME1;

    private java.lang.String STDNTCOMMENT1;

    private java.math.BigDecimal c_COURSEINFORMATION1;

    private ORIONWEB.com_softwareag_entirex_rpc_stawfac4.STAWFAC4ResponseWEBPASS1COURSEINFORMATION1 COURSEINFORMATION1;

    private java.lang.String[] ADMISSIONSNOTES1;

    private java.lang.String APPLIEDFORFINAID1;

    private java.lang.String CONTINUENOFINAID1;

    private java.lang.String FACTSID1;

    private java.lang.String CONFIRMATIONNUMBER1;

    private java.lang.String CONFIRMATIONCODE1;

    private java.lang.String TRACKINGNUMBER1;

    private java.lang.String REQUIREDVACCINATIONSIND1;

    private java.lang.String ELIGIBLETOREENROLLIND1;

    private java.lang.String DEGREEPROGRAMENROLLMENTIND1;

    private java.lang.String HOMEINSTITUTIONFICECODE1;

    private java.math.BigDecimal c_SECTION1;

    private ORIONWEB.com_softwareag_entirex_rpc_stawfac4.STAWFAC4ResponseWEBPASS1SECTION1 SECTION1;

    private java.lang.String QUESTION11;

    private java.lang.String ANSWER11;

    private java.lang.String QUESTION21;

    private java.lang.String ANSWER21;

    private java.lang.String QUESTION31;

    private java.lang.String ANSWER31;

    private java.lang.String QUESTION41;

    private java.lang.String ANSWER41;

    private java.lang.String QUESTION51;

    private java.lang.String ANSWER51;

    private java.lang.String RETURNCODE1;

    private java.lang.String[] RETURNMESSAGE1;

    private java.lang.String SUBMITTEDTIMESTAMP1;

    private java.lang.String _RC1;

    private java.lang.String _RCMSG1;

    public STAWFAC4ResponseWEBPASS1() {
    }

    public STAWFAC4ResponseWEBPASS1(
           java.lang.String STDNTID1,
           java.lang.String STDNTSSN1,
           java.lang.String INSTID1,
           java.lang.String INSTTYPE1,
           java.lang.String RECVDDATE1,
           java.lang.String RECVDTIME1,
           java.lang.String STDNTCOMMENT1,
           java.math.BigDecimal c_COURSEINFORMATION1,
           ORIONWEB.com_softwareag_entirex_rpc_stawfac4.STAWFAC4ResponseWEBPASS1COURSEINFORMATION1 COURSEINFORMATION1,
           java.lang.String[] ADMISSIONSNOTES1,
           java.lang.String APPLIEDFORFINAID1,
           java.lang.String CONTINUENOFINAID1,
           java.lang.String FACTSID1,
           java.lang.String CONFIRMATIONNUMBER1,
           java.lang.String CONFIRMATIONCODE1,
           java.lang.String TRACKINGNUMBER1,
           java.lang.String REQUIREDVACCINATIONSIND1,
           java.lang.String ELIGIBLETOREENROLLIND1,
           java.lang.String DEGREEPROGRAMENROLLMENTIND1,
           java.lang.String HOMEINSTITUTIONFICECODE1,
           java.math.BigDecimal c_SECTION1,
           ORIONWEB.com_softwareag_entirex_rpc_stawfac4.STAWFAC4ResponseWEBPASS1SECTION1 SECTION1,
           java.lang.String QUESTION11,
           java.lang.String ANSWER11,
           java.lang.String QUESTION21,
           java.lang.String ANSWER21,
           java.lang.String QUESTION31,
           java.lang.String ANSWER31,
           java.lang.String QUESTION41,
           java.lang.String ANSWER41,
           java.lang.String QUESTION51,
           java.lang.String ANSWER51,
           java.lang.String RETURNCODE1,
           java.lang.String[] RETURNMESSAGE1,
           java.lang.String SUBMITTEDTIMESTAMP1,
           java.lang.String _RC1,
           java.lang.String _RCMSG1) {
           this.STDNTID1 = STDNTID1;
           this.STDNTSSN1 = STDNTSSN1;
           this.INSTID1 = INSTID1;
           this.INSTTYPE1 = INSTTYPE1;
           this.RECVDDATE1 = RECVDDATE1;
           this.RECVDTIME1 = RECVDTIME1;
           this.STDNTCOMMENT1 = STDNTCOMMENT1;
           this.c_COURSEINFORMATION1 = c_COURSEINFORMATION1;
           this.COURSEINFORMATION1 = COURSEINFORMATION1;
           this.ADMISSIONSNOTES1 = ADMISSIONSNOTES1;
           this.APPLIEDFORFINAID1 = APPLIEDFORFINAID1;
           this.CONTINUENOFINAID1 = CONTINUENOFINAID1;
           this.FACTSID1 = FACTSID1;
           this.CONFIRMATIONNUMBER1 = CONFIRMATIONNUMBER1;
           this.CONFIRMATIONCODE1 = CONFIRMATIONCODE1;
           this.TRACKINGNUMBER1 = TRACKINGNUMBER1;
           this.REQUIREDVACCINATIONSIND1 = REQUIREDVACCINATIONSIND1;
           this.ELIGIBLETOREENROLLIND1 = ELIGIBLETOREENROLLIND1;
           this.DEGREEPROGRAMENROLLMENTIND1 = DEGREEPROGRAMENROLLMENTIND1;
           this.HOMEINSTITUTIONFICECODE1 = HOMEINSTITUTIONFICECODE1;
           this.c_SECTION1 = c_SECTION1;
           this.SECTION1 = SECTION1;
           this.QUESTION11 = QUESTION11;
           this.ANSWER11 = ANSWER11;
           this.QUESTION21 = QUESTION21;
           this.ANSWER21 = ANSWER21;
           this.QUESTION31 = QUESTION31;
           this.ANSWER31 = ANSWER31;
           this.QUESTION41 = QUESTION41;
           this.ANSWER41 = ANSWER41;
           this.QUESTION51 = QUESTION51;
           this.ANSWER51 = ANSWER51;
           this.RETURNCODE1 = RETURNCODE1;
           this.RETURNMESSAGE1 = RETURNMESSAGE1;
           this.SUBMITTEDTIMESTAMP1 = SUBMITTEDTIMESTAMP1;
           this._RC1 = _RC1;
           this._RCMSG1 = _RCMSG1;
    }


    /**
     * Gets the STDNTID1 value for this STAWFAC4ResponseWEBPASS1.
     * 
     * @return STDNTID1
     */
    public java.lang.String getSTDNTID1() {
        return STDNTID1;
    }


    /**
     * Sets the STDNTID1 value for this STAWFAC4ResponseWEBPASS1.
     * 
     * @param STDNTID1
     */
    public void setSTDNTID1(java.lang.String STDNTID1) {
        this.STDNTID1 = STDNTID1;
    }


    /**
     * Gets the STDNTSSN1 value for this STAWFAC4ResponseWEBPASS1.
     * 
     * @return STDNTSSN1
     */
    public java.lang.String getSTDNTSSN1() {
        return STDNTSSN1;
    }


    /**
     * Sets the STDNTSSN1 value for this STAWFAC4ResponseWEBPASS1.
     * 
     * @param STDNTSSN1
     */
    public void setSTDNTSSN1(java.lang.String STDNTSSN1) {
        this.STDNTSSN1 = STDNTSSN1;
    }


    /**
     * Gets the INSTID1 value for this STAWFAC4ResponseWEBPASS1.
     * 
     * @return INSTID1
     */
    public java.lang.String getINSTID1() {
        return INSTID1;
    }


    /**
     * Sets the INSTID1 value for this STAWFAC4ResponseWEBPASS1.
     * 
     * @param INSTID1
     */
    public void setINSTID1(java.lang.String INSTID1) {
        this.INSTID1 = INSTID1;
    }


    /**
     * Gets the INSTTYPE1 value for this STAWFAC4ResponseWEBPASS1.
     * 
     * @return INSTTYPE1
     */
    public java.lang.String getINSTTYPE1() {
        return INSTTYPE1;
    }


    /**
     * Sets the INSTTYPE1 value for this STAWFAC4ResponseWEBPASS1.
     * 
     * @param INSTTYPE1
     */
    public void setINSTTYPE1(java.lang.String INSTTYPE1) {
        this.INSTTYPE1 = INSTTYPE1;
    }


    /**
     * Gets the RECVDDATE1 value for this STAWFAC4ResponseWEBPASS1.
     * 
     * @return RECVDDATE1
     */
    public java.lang.String getRECVDDATE1() {
        return RECVDDATE1;
    }


    /**
     * Sets the RECVDDATE1 value for this STAWFAC4ResponseWEBPASS1.
     * 
     * @param RECVDDATE1
     */
    public void setRECVDDATE1(java.lang.String RECVDDATE1) {
        this.RECVDDATE1 = RECVDDATE1;
    }


    /**
     * Gets the RECVDTIME1 value for this STAWFAC4ResponseWEBPASS1.
     * 
     * @return RECVDTIME1
     */
    public java.lang.String getRECVDTIME1() {
        return RECVDTIME1;
    }


    /**
     * Sets the RECVDTIME1 value for this STAWFAC4ResponseWEBPASS1.
     * 
     * @param RECVDTIME1
     */
    public void setRECVDTIME1(java.lang.String RECVDTIME1) {
        this.RECVDTIME1 = RECVDTIME1;
    }


    /**
     * Gets the STDNTCOMMENT1 value for this STAWFAC4ResponseWEBPASS1.
     * 
     * @return STDNTCOMMENT1
     */
    public java.lang.String getSTDNTCOMMENT1() {
        return STDNTCOMMENT1;
    }


    /**
     * Sets the STDNTCOMMENT1 value for this STAWFAC4ResponseWEBPASS1.
     * 
     * @param STDNTCOMMENT1
     */
    public void setSTDNTCOMMENT1(java.lang.String STDNTCOMMENT1) {
        this.STDNTCOMMENT1 = STDNTCOMMENT1;
    }


    /**
     * Gets the c_COURSEINFORMATION1 value for this STAWFAC4ResponseWEBPASS1.
     * 
     * @return c_COURSEINFORMATION1
     */
    public java.math.BigDecimal getC_COURSEINFORMATION1() {
        return c_COURSEINFORMATION1;
    }


    /**
     * Sets the c_COURSEINFORMATION1 value for this STAWFAC4ResponseWEBPASS1.
     * 
     * @param c_COURSEINFORMATION1
     */
    public void setC_COURSEINFORMATION1(java.math.BigDecimal c_COURSEINFORMATION1) {
        this.c_COURSEINFORMATION1 = c_COURSEINFORMATION1;
    }


    /**
     * Gets the COURSEINFORMATION1 value for this STAWFAC4ResponseWEBPASS1.
     * 
     * @return COURSEINFORMATION1
     */
    public ORIONWEB.com_softwareag_entirex_rpc_stawfac4.STAWFAC4ResponseWEBPASS1COURSEINFORMATION1 getCOURSEINFORMATION1() {
        return COURSEINFORMATION1;
    }


    /**
     * Sets the COURSEINFORMATION1 value for this STAWFAC4ResponseWEBPASS1.
     * 
     * @param COURSEINFORMATION1
     */
    public void setCOURSEINFORMATION1(ORIONWEB.com_softwareag_entirex_rpc_stawfac4.STAWFAC4ResponseWEBPASS1COURSEINFORMATION1 COURSEINFORMATION1) {
        this.COURSEINFORMATION1 = COURSEINFORMATION1;
    }


    /**
     * Gets the ADMISSIONSNOTES1 value for this STAWFAC4ResponseWEBPASS1.
     * 
     * @return ADMISSIONSNOTES1
     */
    public java.lang.String[] getADMISSIONSNOTES1() {
        return ADMISSIONSNOTES1;
    }


    /**
     * Sets the ADMISSIONSNOTES1 value for this STAWFAC4ResponseWEBPASS1.
     * 
     * @param ADMISSIONSNOTES1
     */
    public void setADMISSIONSNOTES1(java.lang.String[] ADMISSIONSNOTES1) {
        this.ADMISSIONSNOTES1 = ADMISSIONSNOTES1;
    }


    /**
     * Gets the APPLIEDFORFINAID1 value for this STAWFAC4ResponseWEBPASS1.
     * 
     * @return APPLIEDFORFINAID1
     */
    public java.lang.String getAPPLIEDFORFINAID1() {
        return APPLIEDFORFINAID1;
    }


    /**
     * Sets the APPLIEDFORFINAID1 value for this STAWFAC4ResponseWEBPASS1.
     * 
     * @param APPLIEDFORFINAID1
     */
    public void setAPPLIEDFORFINAID1(java.lang.String APPLIEDFORFINAID1) {
        this.APPLIEDFORFINAID1 = APPLIEDFORFINAID1;
    }


    /**
     * Gets the CONTINUENOFINAID1 value for this STAWFAC4ResponseWEBPASS1.
     * 
     * @return CONTINUENOFINAID1
     */
    public java.lang.String getCONTINUENOFINAID1() {
        return CONTINUENOFINAID1;
    }


    /**
     * Sets the CONTINUENOFINAID1 value for this STAWFAC4ResponseWEBPASS1.
     * 
     * @param CONTINUENOFINAID1
     */
    public void setCONTINUENOFINAID1(java.lang.String CONTINUENOFINAID1) {
        this.CONTINUENOFINAID1 = CONTINUENOFINAID1;
    }


    /**
     * Gets the FACTSID1 value for this STAWFAC4ResponseWEBPASS1.
     * 
     * @return FACTSID1
     */
    public java.lang.String getFACTSID1() {
        return FACTSID1;
    }


    /**
     * Sets the FACTSID1 value for this STAWFAC4ResponseWEBPASS1.
     * 
     * @param FACTSID1
     */
    public void setFACTSID1(java.lang.String FACTSID1) {
        this.FACTSID1 = FACTSID1;
    }


    /**
     * Gets the CONFIRMATIONNUMBER1 value for this STAWFAC4ResponseWEBPASS1.
     * 
     * @return CONFIRMATIONNUMBER1
     */
    public java.lang.String getCONFIRMATIONNUMBER1() {
        return CONFIRMATIONNUMBER1;
    }


    /**
     * Sets the CONFIRMATIONNUMBER1 value for this STAWFAC4ResponseWEBPASS1.
     * 
     * @param CONFIRMATIONNUMBER1
     */
    public void setCONFIRMATIONNUMBER1(java.lang.String CONFIRMATIONNUMBER1) {
        this.CONFIRMATIONNUMBER1 = CONFIRMATIONNUMBER1;
    }


    /**
     * Gets the CONFIRMATIONCODE1 value for this STAWFAC4ResponseWEBPASS1.
     * 
     * @return CONFIRMATIONCODE1
     */
    public java.lang.String getCONFIRMATIONCODE1() {
        return CONFIRMATIONCODE1;
    }


    /**
     * Sets the CONFIRMATIONCODE1 value for this STAWFAC4ResponseWEBPASS1.
     * 
     * @param CONFIRMATIONCODE1
     */
    public void setCONFIRMATIONCODE1(java.lang.String CONFIRMATIONCODE1) {
        this.CONFIRMATIONCODE1 = CONFIRMATIONCODE1;
    }


    /**
     * Gets the TRACKINGNUMBER1 value for this STAWFAC4ResponseWEBPASS1.
     * 
     * @return TRACKINGNUMBER1
     */
    public java.lang.String getTRACKINGNUMBER1() {
        return TRACKINGNUMBER1;
    }


    /**
     * Sets the TRACKINGNUMBER1 value for this STAWFAC4ResponseWEBPASS1.
     * 
     * @param TRACKINGNUMBER1
     */
    public void setTRACKINGNUMBER1(java.lang.String TRACKINGNUMBER1) {
        this.TRACKINGNUMBER1 = TRACKINGNUMBER1;
    }


    /**
     * Gets the REQUIREDVACCINATIONSIND1 value for this STAWFAC4ResponseWEBPASS1.
     * 
     * @return REQUIREDVACCINATIONSIND1
     */
    public java.lang.String getREQUIREDVACCINATIONSIND1() {
        return REQUIREDVACCINATIONSIND1;
    }


    /**
     * Sets the REQUIREDVACCINATIONSIND1 value for this STAWFAC4ResponseWEBPASS1.
     * 
     * @param REQUIREDVACCINATIONSIND1
     */
    public void setREQUIREDVACCINATIONSIND1(java.lang.String REQUIREDVACCINATIONSIND1) {
        this.REQUIREDVACCINATIONSIND1 = REQUIREDVACCINATIONSIND1;
    }


    /**
     * Gets the ELIGIBLETOREENROLLIND1 value for this STAWFAC4ResponseWEBPASS1.
     * 
     * @return ELIGIBLETOREENROLLIND1
     */
    public java.lang.String getELIGIBLETOREENROLLIND1() {
        return ELIGIBLETOREENROLLIND1;
    }


    /**
     * Sets the ELIGIBLETOREENROLLIND1 value for this STAWFAC4ResponseWEBPASS1.
     * 
     * @param ELIGIBLETOREENROLLIND1
     */
    public void setELIGIBLETOREENROLLIND1(java.lang.String ELIGIBLETOREENROLLIND1) {
        this.ELIGIBLETOREENROLLIND1 = ELIGIBLETOREENROLLIND1;
    }


    /**
     * Gets the DEGREEPROGRAMENROLLMENTIND1 value for this STAWFAC4ResponseWEBPASS1.
     * 
     * @return DEGREEPROGRAMENROLLMENTIND1
     */
    public java.lang.String getDEGREEPROGRAMENROLLMENTIND1() {
        return DEGREEPROGRAMENROLLMENTIND1;
    }


    /**
     * Sets the DEGREEPROGRAMENROLLMENTIND1 value for this STAWFAC4ResponseWEBPASS1.
     * 
     * @param DEGREEPROGRAMENROLLMENTIND1
     */
    public void setDEGREEPROGRAMENROLLMENTIND1(java.lang.String DEGREEPROGRAMENROLLMENTIND1) {
        this.DEGREEPROGRAMENROLLMENTIND1 = DEGREEPROGRAMENROLLMENTIND1;
    }


    /**
     * Gets the HOMEINSTITUTIONFICECODE1 value for this STAWFAC4ResponseWEBPASS1.
     * 
     * @return HOMEINSTITUTIONFICECODE1
     */
    public java.lang.String getHOMEINSTITUTIONFICECODE1() {
        return HOMEINSTITUTIONFICECODE1;
    }


    /**
     * Sets the HOMEINSTITUTIONFICECODE1 value for this STAWFAC4ResponseWEBPASS1.
     * 
     * @param HOMEINSTITUTIONFICECODE1
     */
    public void setHOMEINSTITUTIONFICECODE1(java.lang.String HOMEINSTITUTIONFICECODE1) {
        this.HOMEINSTITUTIONFICECODE1 = HOMEINSTITUTIONFICECODE1;
    }


    /**
     * Gets the c_SECTION1 value for this STAWFAC4ResponseWEBPASS1.
     * 
     * @return c_SECTION1
     */
    public java.math.BigDecimal getC_SECTION1() {
        return c_SECTION1;
    }


    /**
     * Sets the c_SECTION1 value for this STAWFAC4ResponseWEBPASS1.
     * 
     * @param c_SECTION1
     */
    public void setC_SECTION1(java.math.BigDecimal c_SECTION1) {
        this.c_SECTION1 = c_SECTION1;
    }


    /**
     * Gets the SECTION1 value for this STAWFAC4ResponseWEBPASS1.
     * 
     * @return SECTION1
     */
    public ORIONWEB.com_softwareag_entirex_rpc_stawfac4.STAWFAC4ResponseWEBPASS1SECTION1 getSECTION1() {
        return SECTION1;
    }


    /**
     * Sets the SECTION1 value for this STAWFAC4ResponseWEBPASS1.
     * 
     * @param SECTION1
     */
    public void setSECTION1(ORIONWEB.com_softwareag_entirex_rpc_stawfac4.STAWFAC4ResponseWEBPASS1SECTION1 SECTION1) {
        this.SECTION1 = SECTION1;
    }


    /**
     * Gets the QUESTION11 value for this STAWFAC4ResponseWEBPASS1.
     * 
     * @return QUESTION11
     */
    public java.lang.String getQUESTION11() {
        return QUESTION11;
    }


    /**
     * Sets the QUESTION11 value for this STAWFAC4ResponseWEBPASS1.
     * 
     * @param QUESTION11
     */
    public void setQUESTION11(java.lang.String QUESTION11) {
        this.QUESTION11 = QUESTION11;
    }


    /**
     * Gets the ANSWER11 value for this STAWFAC4ResponseWEBPASS1.
     * 
     * @return ANSWER11
     */
    public java.lang.String getANSWER11() {
        return ANSWER11;
    }


    /**
     * Sets the ANSWER11 value for this STAWFAC4ResponseWEBPASS1.
     * 
     * @param ANSWER11
     */
    public void setANSWER11(java.lang.String ANSWER11) {
        this.ANSWER11 = ANSWER11;
    }


    /**
     * Gets the QUESTION21 value for this STAWFAC4ResponseWEBPASS1.
     * 
     * @return QUESTION21
     */
    public java.lang.String getQUESTION21() {
        return QUESTION21;
    }


    /**
     * Sets the QUESTION21 value for this STAWFAC4ResponseWEBPASS1.
     * 
     * @param QUESTION21
     */
    public void setQUESTION21(java.lang.String QUESTION21) {
        this.QUESTION21 = QUESTION21;
    }


    /**
     * Gets the ANSWER21 value for this STAWFAC4ResponseWEBPASS1.
     * 
     * @return ANSWER21
     */
    public java.lang.String getANSWER21() {
        return ANSWER21;
    }


    /**
     * Sets the ANSWER21 value for this STAWFAC4ResponseWEBPASS1.
     * 
     * @param ANSWER21
     */
    public void setANSWER21(java.lang.String ANSWER21) {
        this.ANSWER21 = ANSWER21;
    }


    /**
     * Gets the QUESTION31 value for this STAWFAC4ResponseWEBPASS1.
     * 
     * @return QUESTION31
     */
    public java.lang.String getQUESTION31() {
        return QUESTION31;
    }


    /**
     * Sets the QUESTION31 value for this STAWFAC4ResponseWEBPASS1.
     * 
     * @param QUESTION31
     */
    public void setQUESTION31(java.lang.String QUESTION31) {
        this.QUESTION31 = QUESTION31;
    }


    /**
     * Gets the ANSWER31 value for this STAWFAC4ResponseWEBPASS1.
     * 
     * @return ANSWER31
     */
    public java.lang.String getANSWER31() {
        return ANSWER31;
    }


    /**
     * Sets the ANSWER31 value for this STAWFAC4ResponseWEBPASS1.
     * 
     * @param ANSWER31
     */
    public void setANSWER31(java.lang.String ANSWER31) {
        this.ANSWER31 = ANSWER31;
    }


    /**
     * Gets the QUESTION41 value for this STAWFAC4ResponseWEBPASS1.
     * 
     * @return QUESTION41
     */
    public java.lang.String getQUESTION41() {
        return QUESTION41;
    }


    /**
     * Sets the QUESTION41 value for this STAWFAC4ResponseWEBPASS1.
     * 
     * @param QUESTION41
     */
    public void setQUESTION41(java.lang.String QUESTION41) {
        this.QUESTION41 = QUESTION41;
    }


    /**
     * Gets the ANSWER41 value for this STAWFAC4ResponseWEBPASS1.
     * 
     * @return ANSWER41
     */
    public java.lang.String getANSWER41() {
        return ANSWER41;
    }


    /**
     * Sets the ANSWER41 value for this STAWFAC4ResponseWEBPASS1.
     * 
     * @param ANSWER41
     */
    public void setANSWER41(java.lang.String ANSWER41) {
        this.ANSWER41 = ANSWER41;
    }


    /**
     * Gets the QUESTION51 value for this STAWFAC4ResponseWEBPASS1.
     * 
     * @return QUESTION51
     */
    public java.lang.String getQUESTION51() {
        return QUESTION51;
    }


    /**
     * Sets the QUESTION51 value for this STAWFAC4ResponseWEBPASS1.
     * 
     * @param QUESTION51
     */
    public void setQUESTION51(java.lang.String QUESTION51) {
        this.QUESTION51 = QUESTION51;
    }


    /**
     * Gets the ANSWER51 value for this STAWFAC4ResponseWEBPASS1.
     * 
     * @return ANSWER51
     */
    public java.lang.String getANSWER51() {
        return ANSWER51;
    }


    /**
     * Sets the ANSWER51 value for this STAWFAC4ResponseWEBPASS1.
     * 
     * @param ANSWER51
     */
    public void setANSWER51(java.lang.String ANSWER51) {
        this.ANSWER51 = ANSWER51;
    }


    /**
     * Gets the RETURNCODE1 value for this STAWFAC4ResponseWEBPASS1.
     * 
     * @return RETURNCODE1
     */
    public java.lang.String getRETURNCODE1() {
        return RETURNCODE1;
    }


    /**
     * Sets the RETURNCODE1 value for this STAWFAC4ResponseWEBPASS1.
     * 
     * @param RETURNCODE1
     */
    public void setRETURNCODE1(java.lang.String RETURNCODE1) {
        this.RETURNCODE1 = RETURNCODE1;
    }


    /**
     * Gets the RETURNMESSAGE1 value for this STAWFAC4ResponseWEBPASS1.
     * 
     * @return RETURNMESSAGE1
     */
    public java.lang.String[] getRETURNMESSAGE1() {
        return RETURNMESSAGE1;
    }


    /**
     * Sets the RETURNMESSAGE1 value for this STAWFAC4ResponseWEBPASS1.
     * 
     * @param RETURNMESSAGE1
     */
    public void setRETURNMESSAGE1(java.lang.String[] RETURNMESSAGE1) {
        this.RETURNMESSAGE1 = RETURNMESSAGE1;
    }


    /**
     * Gets the SUBMITTEDTIMESTAMP1 value for this STAWFAC4ResponseWEBPASS1.
     * 
     * @return SUBMITTEDTIMESTAMP1
     */
    public java.lang.String getSUBMITTEDTIMESTAMP1() {
        return SUBMITTEDTIMESTAMP1;
    }


    /**
     * Sets the SUBMITTEDTIMESTAMP1 value for this STAWFAC4ResponseWEBPASS1.
     * 
     * @param SUBMITTEDTIMESTAMP1
     */
    public void setSUBMITTEDTIMESTAMP1(java.lang.String SUBMITTEDTIMESTAMP1) {
        this.SUBMITTEDTIMESTAMP1 = SUBMITTEDTIMESTAMP1;
    }


    /**
     * Gets the _RC1 value for this STAWFAC4ResponseWEBPASS1.
     * 
     * @return _RC1
     */
    public java.lang.String get_RC1() {
        return _RC1;
    }


    /**
     * Sets the _RC1 value for this STAWFAC4ResponseWEBPASS1.
     * 
     * @param _RC1
     */
    public void set_RC1(java.lang.String _RC1) {
        this._RC1 = _RC1;
    }


    /**
     * Gets the _RCMSG1 value for this STAWFAC4ResponseWEBPASS1.
     * 
     * @return _RCMSG1
     */
    public java.lang.String get_RCMSG1() {
        return _RCMSG1;
    }


    /**
     * Sets the _RCMSG1 value for this STAWFAC4ResponseWEBPASS1.
     * 
     * @param _RCMSG1
     */
    public void set_RCMSG1(java.lang.String _RCMSG1) {
        this._RCMSG1 = _RCMSG1;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof STAWFAC4ResponseWEBPASS1)) return false;
        STAWFAC4ResponseWEBPASS1 other = (STAWFAC4ResponseWEBPASS1) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.STDNTID1==null && other.getSTDNTID1()==null) || 
             (this.STDNTID1!=null &&
              this.STDNTID1.equals(other.getSTDNTID1()))) &&
            ((this.STDNTSSN1==null && other.getSTDNTSSN1()==null) || 
             (this.STDNTSSN1!=null &&
              this.STDNTSSN1.equals(other.getSTDNTSSN1()))) &&
            ((this.INSTID1==null && other.getINSTID1()==null) || 
             (this.INSTID1!=null &&
              this.INSTID1.equals(other.getINSTID1()))) &&
            ((this.INSTTYPE1==null && other.getINSTTYPE1()==null) || 
             (this.INSTTYPE1!=null &&
              this.INSTTYPE1.equals(other.getINSTTYPE1()))) &&
            ((this.RECVDDATE1==null && other.getRECVDDATE1()==null) || 
             (this.RECVDDATE1!=null &&
              this.RECVDDATE1.equals(other.getRECVDDATE1()))) &&
            ((this.RECVDTIME1==null && other.getRECVDTIME1()==null) || 
             (this.RECVDTIME1!=null &&
              this.RECVDTIME1.equals(other.getRECVDTIME1()))) &&
            ((this.STDNTCOMMENT1==null && other.getSTDNTCOMMENT1()==null) || 
             (this.STDNTCOMMENT1!=null &&
              this.STDNTCOMMENT1.equals(other.getSTDNTCOMMENT1()))) &&
            ((this.c_COURSEINFORMATION1==null && other.getC_COURSEINFORMATION1()==null) || 
             (this.c_COURSEINFORMATION1!=null &&
              this.c_COURSEINFORMATION1.equals(other.getC_COURSEINFORMATION1()))) &&
            ((this.COURSEINFORMATION1==null && other.getCOURSEINFORMATION1()==null) || 
             (this.COURSEINFORMATION1!=null &&
              this.COURSEINFORMATION1.equals(other.getCOURSEINFORMATION1()))) &&
            ((this.ADMISSIONSNOTES1==null && other.getADMISSIONSNOTES1()==null) || 
             (this.ADMISSIONSNOTES1!=null &&
              java.util.Arrays.equals(this.ADMISSIONSNOTES1, other.getADMISSIONSNOTES1()))) &&
            ((this.APPLIEDFORFINAID1==null && other.getAPPLIEDFORFINAID1()==null) || 
             (this.APPLIEDFORFINAID1!=null &&
              this.APPLIEDFORFINAID1.equals(other.getAPPLIEDFORFINAID1()))) &&
            ((this.CONTINUENOFINAID1==null && other.getCONTINUENOFINAID1()==null) || 
             (this.CONTINUENOFINAID1!=null &&
              this.CONTINUENOFINAID1.equals(other.getCONTINUENOFINAID1()))) &&
            ((this.FACTSID1==null && other.getFACTSID1()==null) || 
             (this.FACTSID1!=null &&
              this.FACTSID1.equals(other.getFACTSID1()))) &&
            ((this.CONFIRMATIONNUMBER1==null && other.getCONFIRMATIONNUMBER1()==null) || 
             (this.CONFIRMATIONNUMBER1!=null &&
              this.CONFIRMATIONNUMBER1.equals(other.getCONFIRMATIONNUMBER1()))) &&
            ((this.CONFIRMATIONCODE1==null && other.getCONFIRMATIONCODE1()==null) || 
             (this.CONFIRMATIONCODE1!=null &&
              this.CONFIRMATIONCODE1.equals(other.getCONFIRMATIONCODE1()))) &&
            ((this.TRACKINGNUMBER1==null && other.getTRACKINGNUMBER1()==null) || 
             (this.TRACKINGNUMBER1!=null &&
              this.TRACKINGNUMBER1.equals(other.getTRACKINGNUMBER1()))) &&
            ((this.REQUIREDVACCINATIONSIND1==null && other.getREQUIREDVACCINATIONSIND1()==null) || 
             (this.REQUIREDVACCINATIONSIND1!=null &&
              this.REQUIREDVACCINATIONSIND1.equals(other.getREQUIREDVACCINATIONSIND1()))) &&
            ((this.ELIGIBLETOREENROLLIND1==null && other.getELIGIBLETOREENROLLIND1()==null) || 
             (this.ELIGIBLETOREENROLLIND1!=null &&
              this.ELIGIBLETOREENROLLIND1.equals(other.getELIGIBLETOREENROLLIND1()))) &&
            ((this.DEGREEPROGRAMENROLLMENTIND1==null && other.getDEGREEPROGRAMENROLLMENTIND1()==null) || 
             (this.DEGREEPROGRAMENROLLMENTIND1!=null &&
              this.DEGREEPROGRAMENROLLMENTIND1.equals(other.getDEGREEPROGRAMENROLLMENTIND1()))) &&
            ((this.HOMEINSTITUTIONFICECODE1==null && other.getHOMEINSTITUTIONFICECODE1()==null) || 
             (this.HOMEINSTITUTIONFICECODE1!=null &&
              this.HOMEINSTITUTIONFICECODE1.equals(other.getHOMEINSTITUTIONFICECODE1()))) &&
            ((this.c_SECTION1==null && other.getC_SECTION1()==null) || 
             (this.c_SECTION1!=null &&
              this.c_SECTION1.equals(other.getC_SECTION1()))) &&
            ((this.SECTION1==null && other.getSECTION1()==null) || 
             (this.SECTION1!=null &&
              this.SECTION1.equals(other.getSECTION1()))) &&
            ((this.QUESTION11==null && other.getQUESTION11()==null) || 
             (this.QUESTION11!=null &&
              this.QUESTION11.equals(other.getQUESTION11()))) &&
            ((this.ANSWER11==null && other.getANSWER11()==null) || 
             (this.ANSWER11!=null &&
              this.ANSWER11.equals(other.getANSWER11()))) &&
            ((this.QUESTION21==null && other.getQUESTION21()==null) || 
             (this.QUESTION21!=null &&
              this.QUESTION21.equals(other.getQUESTION21()))) &&
            ((this.ANSWER21==null && other.getANSWER21()==null) || 
             (this.ANSWER21!=null &&
              this.ANSWER21.equals(other.getANSWER21()))) &&
            ((this.QUESTION31==null && other.getQUESTION31()==null) || 
             (this.QUESTION31!=null &&
              this.QUESTION31.equals(other.getQUESTION31()))) &&
            ((this.ANSWER31==null && other.getANSWER31()==null) || 
             (this.ANSWER31!=null &&
              this.ANSWER31.equals(other.getANSWER31()))) &&
            ((this.QUESTION41==null && other.getQUESTION41()==null) || 
             (this.QUESTION41!=null &&
              this.QUESTION41.equals(other.getQUESTION41()))) &&
            ((this.ANSWER41==null && other.getANSWER41()==null) || 
             (this.ANSWER41!=null &&
              this.ANSWER41.equals(other.getANSWER41()))) &&
            ((this.QUESTION51==null && other.getQUESTION51()==null) || 
             (this.QUESTION51!=null &&
              this.QUESTION51.equals(other.getQUESTION51()))) &&
            ((this.ANSWER51==null && other.getANSWER51()==null) || 
             (this.ANSWER51!=null &&
              this.ANSWER51.equals(other.getANSWER51()))) &&
            ((this.RETURNCODE1==null && other.getRETURNCODE1()==null) || 
             (this.RETURNCODE1!=null &&
              this.RETURNCODE1.equals(other.getRETURNCODE1()))) &&
            ((this.RETURNMESSAGE1==null && other.getRETURNMESSAGE1()==null) || 
             (this.RETURNMESSAGE1!=null &&
              java.util.Arrays.equals(this.RETURNMESSAGE1, other.getRETURNMESSAGE1()))) &&
            ((this.SUBMITTEDTIMESTAMP1==null && other.getSUBMITTEDTIMESTAMP1()==null) || 
             (this.SUBMITTEDTIMESTAMP1!=null &&
              this.SUBMITTEDTIMESTAMP1.equals(other.getSUBMITTEDTIMESTAMP1()))) &&
            ((this._RC1==null && other.get_RC1()==null) || 
             (this._RC1!=null &&
              this._RC1.equals(other.get_RC1()))) &&
            ((this._RCMSG1==null && other.get_RCMSG1()==null) || 
             (this._RCMSG1!=null &&
              this._RCMSG1.equals(other.get_RCMSG1())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getSTDNTID1() != null) {
            _hashCode += getSTDNTID1().hashCode();
        }
        if (getSTDNTSSN1() != null) {
            _hashCode += getSTDNTSSN1().hashCode();
        }
        if (getINSTID1() != null) {
            _hashCode += getINSTID1().hashCode();
        }
        if (getINSTTYPE1() != null) {
            _hashCode += getINSTTYPE1().hashCode();
        }
        if (getRECVDDATE1() != null) {
            _hashCode += getRECVDDATE1().hashCode();
        }
        if (getRECVDTIME1() != null) {
            _hashCode += getRECVDTIME1().hashCode();
        }
        if (getSTDNTCOMMENT1() != null) {
            _hashCode += getSTDNTCOMMENT1().hashCode();
        }
        if (getC_COURSEINFORMATION1() != null) {
            _hashCode += getC_COURSEINFORMATION1().hashCode();
        }
        if (getCOURSEINFORMATION1() != null) {
            _hashCode += getCOURSEINFORMATION1().hashCode();
        }
        if (getADMISSIONSNOTES1() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getADMISSIONSNOTES1());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getADMISSIONSNOTES1(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getAPPLIEDFORFINAID1() != null) {
            _hashCode += getAPPLIEDFORFINAID1().hashCode();
        }
        if (getCONTINUENOFINAID1() != null) {
            _hashCode += getCONTINUENOFINAID1().hashCode();
        }
        if (getFACTSID1() != null) {
            _hashCode += getFACTSID1().hashCode();
        }
        if (getCONFIRMATIONNUMBER1() != null) {
            _hashCode += getCONFIRMATIONNUMBER1().hashCode();
        }
        if (getCONFIRMATIONCODE1() != null) {
            _hashCode += getCONFIRMATIONCODE1().hashCode();
        }
        if (getTRACKINGNUMBER1() != null) {
            _hashCode += getTRACKINGNUMBER1().hashCode();
        }
        if (getREQUIREDVACCINATIONSIND1() != null) {
            _hashCode += getREQUIREDVACCINATIONSIND1().hashCode();
        }
        if (getELIGIBLETOREENROLLIND1() != null) {
            _hashCode += getELIGIBLETOREENROLLIND1().hashCode();
        }
        if (getDEGREEPROGRAMENROLLMENTIND1() != null) {
            _hashCode += getDEGREEPROGRAMENROLLMENTIND1().hashCode();
        }
        if (getHOMEINSTITUTIONFICECODE1() != null) {
            _hashCode += getHOMEINSTITUTIONFICECODE1().hashCode();
        }
        if (getC_SECTION1() != null) {
            _hashCode += getC_SECTION1().hashCode();
        }
        if (getSECTION1() != null) {
            _hashCode += getSECTION1().hashCode();
        }
        if (getQUESTION11() != null) {
            _hashCode += getQUESTION11().hashCode();
        }
        if (getANSWER11() != null) {
            _hashCode += getANSWER11().hashCode();
        }
        if (getQUESTION21() != null) {
            _hashCode += getQUESTION21().hashCode();
        }
        if (getANSWER21() != null) {
            _hashCode += getANSWER21().hashCode();
        }
        if (getQUESTION31() != null) {
            _hashCode += getQUESTION31().hashCode();
        }
        if (getANSWER31() != null) {
            _hashCode += getANSWER31().hashCode();
        }
        if (getQUESTION41() != null) {
            _hashCode += getQUESTION41().hashCode();
        }
        if (getANSWER41() != null) {
            _hashCode += getANSWER41().hashCode();
        }
        if (getQUESTION51() != null) {
            _hashCode += getQUESTION51().hashCode();
        }
        if (getANSWER51() != null) {
            _hashCode += getANSWER51().hashCode();
        }
        if (getRETURNCODE1() != null) {
            _hashCode += getRETURNCODE1().hashCode();
        }
        if (getRETURNMESSAGE1() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getRETURNMESSAGE1());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getRETURNMESSAGE1(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getSUBMITTEDTIMESTAMP1() != null) {
            _hashCode += getSUBMITTEDTIMESTAMP1().hashCode();
        }
        if (get_RC1() != null) {
            _hashCode += get_RC1().hashCode();
        }
        if (get_RCMSG1() != null) {
            _hashCode += get_RCMSG1().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(STAWFAC4ResponseWEBPASS1.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("urn:com-softwareag-entirex-rpc:ORIONWEB", ">>STAWFAC4Response>WEB-PASS1"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("STDNTID1");
        elemField.setXmlName(new javax.xml.namespace.QName("", "STDNT-ID1"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("STDNTSSN1");
        elemField.setXmlName(new javax.xml.namespace.QName("", "STDNT-SSN1"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("INSTID1");
        elemField.setXmlName(new javax.xml.namespace.QName("", "INST-ID1"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("INSTTYPE1");
        elemField.setXmlName(new javax.xml.namespace.QName("", "INST-TYPE1"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("RECVDDATE1");
        elemField.setXmlName(new javax.xml.namespace.QName("", "RECVD-DATE1"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("RECVDTIME1");
        elemField.setXmlName(new javax.xml.namespace.QName("", "RECVD-TIME1"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("STDNTCOMMENT1");
        elemField.setXmlName(new javax.xml.namespace.QName("", "STDNT-COMMENT1"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c_COURSEINFORMATION1");
        elemField.setXmlName(new javax.xml.namespace.QName("", "C_COURSE-INFORMATION1"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "decimal"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("COURSEINFORMATION1");
        elemField.setXmlName(new javax.xml.namespace.QName("", "COURSE-INFORMATION1"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:com-softwareag-entirex-rpc:ORIONWEB", ">>>STAWFAC4Response>WEB-PASS1>COURSE-INFORMATION1"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ADMISSIONSNOTES1");
        elemField.setXmlName(new javax.xml.namespace.QName("", "ADMISSIONS-NOTES1"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("", "string"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("APPLIEDFORFINAID1");
        elemField.setXmlName(new javax.xml.namespace.QName("", "APPLIED-FOR-FIN-AID1"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CONTINUENOFINAID1");
        elemField.setXmlName(new javax.xml.namespace.QName("", "CONTINUE-NO-FIN-AID1"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("FACTSID1");
        elemField.setXmlName(new javax.xml.namespace.QName("", "FACTS-ID1"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CONFIRMATIONNUMBER1");
        elemField.setXmlName(new javax.xml.namespace.QName("", "CONFIRMATION-NUMBER1"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CONFIRMATIONCODE1");
        elemField.setXmlName(new javax.xml.namespace.QName("", "CONFIRMATION-CODE1"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("TRACKINGNUMBER1");
        elemField.setXmlName(new javax.xml.namespace.QName("", "TRACKING-NUMBER1"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("REQUIREDVACCINATIONSIND1");
        elemField.setXmlName(new javax.xml.namespace.QName("", "REQUIRED-VACCINATIONS-IND1"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ELIGIBLETOREENROLLIND1");
        elemField.setXmlName(new javax.xml.namespace.QName("", "ELIGIBLE-TO-REENROLL-IND1"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("DEGREEPROGRAMENROLLMENTIND1");
        elemField.setXmlName(new javax.xml.namespace.QName("", "DEGREE-PROGRAM-ENROLLMENT-IND1"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("HOMEINSTITUTIONFICECODE1");
        elemField.setXmlName(new javax.xml.namespace.QName("", "HOME-INSTITUTION-FICE-CODE1"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c_SECTION1");
        elemField.setXmlName(new javax.xml.namespace.QName("", "C_SECTION1"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "decimal"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SECTION1");
        elemField.setXmlName(new javax.xml.namespace.QName("", "SECTION1"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:com-softwareag-entirex-rpc:ORIONWEB", ">>>STAWFAC4Response>WEB-PASS1>SECTION1"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("QUESTION11");
        elemField.setXmlName(new javax.xml.namespace.QName("", "QUESTION11"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ANSWER11");
        elemField.setXmlName(new javax.xml.namespace.QName("", "ANSWER11"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("QUESTION21");
        elemField.setXmlName(new javax.xml.namespace.QName("", "QUESTION21"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ANSWER21");
        elemField.setXmlName(new javax.xml.namespace.QName("", "ANSWER21"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("QUESTION31");
        elemField.setXmlName(new javax.xml.namespace.QName("", "QUESTION31"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ANSWER31");
        elemField.setXmlName(new javax.xml.namespace.QName("", "ANSWER31"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("QUESTION41");
        elemField.setXmlName(new javax.xml.namespace.QName("", "QUESTION41"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ANSWER41");
        elemField.setXmlName(new javax.xml.namespace.QName("", "ANSWER41"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("QUESTION51");
        elemField.setXmlName(new javax.xml.namespace.QName("", "QUESTION51"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ANSWER51");
        elemField.setXmlName(new javax.xml.namespace.QName("", "ANSWER51"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("RETURNCODE1");
        elemField.setXmlName(new javax.xml.namespace.QName("", "RETURN-CODE1"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("RETURNMESSAGE1");
        elemField.setXmlName(new javax.xml.namespace.QName("", "RETURN-MESSAGE1"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("", "string"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SUBMITTEDTIMESTAMP1");
        elemField.setXmlName(new javax.xml.namespace.QName("", "SUBMITTED-TIMESTAMP1"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("_RC1");
        elemField.setXmlName(new javax.xml.namespace.QName("", "_RC1"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("_RCMSG1");
        elemField.setXmlName(new javax.xml.namespace.QName("", "_RC-MSG1"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
