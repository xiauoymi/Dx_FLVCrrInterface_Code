/**
 * STAWFAC4WEBPASSSECTION.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package ORIONWEB.com_softwareag_entirex_rpc_stawfac4;

public class STAWFAC4WEBPASSSECTION  implements java.io.Serializable {
    private java.lang.String[] INSTITUTIONTYPEHOMEHOST;

    private java.lang.String[] SECTIONTITLE;

    private java.lang.String[] SECTIONROLE;

    private java.lang.String[] INSTITUTIONWORKFLOWLEVEL;

    private java.lang.String[] COMMENT;

    private java.lang.String[] AGENTID;

    private java.lang.String[] FULLNAME;

    private java.lang.String[] AGENTSIGNATUREDATE;

    private java.lang.String[] SECTIONSTATUS;

    public STAWFAC4WEBPASSSECTION() {
    }

    public STAWFAC4WEBPASSSECTION(
           java.lang.String[] INSTITUTIONTYPEHOMEHOST,
           java.lang.String[] SECTIONTITLE,
           java.lang.String[] SECTIONROLE,
           java.lang.String[] INSTITUTIONWORKFLOWLEVEL,
           java.lang.String[] COMMENT,
           java.lang.String[] AGENTID,
           java.lang.String[] FULLNAME,
           java.lang.String[] AGENTSIGNATUREDATE,
           java.lang.String[] SECTIONSTATUS) {
           this.INSTITUTIONTYPEHOMEHOST = INSTITUTIONTYPEHOMEHOST;
           this.SECTIONTITLE = SECTIONTITLE;
           this.SECTIONROLE = SECTIONROLE;
           this.INSTITUTIONWORKFLOWLEVEL = INSTITUTIONWORKFLOWLEVEL;
           this.COMMENT = COMMENT;
           this.AGENTID = AGENTID;
           this.FULLNAME = FULLNAME;
           this.AGENTSIGNATUREDATE = AGENTSIGNATUREDATE;
           this.SECTIONSTATUS = SECTIONSTATUS;
    }


    /**
     * Gets the INSTITUTIONTYPEHOMEHOST value for this STAWFAC4WEBPASSSECTION.
     * 
     * @return INSTITUTIONTYPEHOMEHOST
     */
    public java.lang.String[] getINSTITUTIONTYPEHOMEHOST() {
        return INSTITUTIONTYPEHOMEHOST;
    }


    /**
     * Sets the INSTITUTIONTYPEHOMEHOST value for this STAWFAC4WEBPASSSECTION.
     * 
     * @param INSTITUTIONTYPEHOMEHOST
     */
    public void setINSTITUTIONTYPEHOMEHOST(java.lang.String[] INSTITUTIONTYPEHOMEHOST) {
        this.INSTITUTIONTYPEHOMEHOST = INSTITUTIONTYPEHOMEHOST;
    }


    /**
     * Gets the SECTIONTITLE value for this STAWFAC4WEBPASSSECTION.
     * 
     * @return SECTIONTITLE
     */
    public java.lang.String[] getSECTIONTITLE() {
        return SECTIONTITLE;
    }


    /**
     * Sets the SECTIONTITLE value for this STAWFAC4WEBPASSSECTION.
     * 
     * @param SECTIONTITLE
     */
    public void setSECTIONTITLE(java.lang.String[] SECTIONTITLE) {
        this.SECTIONTITLE = SECTIONTITLE;
    }


    /**
     * Gets the SECTIONROLE value for this STAWFAC4WEBPASSSECTION.
     * 
     * @return SECTIONROLE
     */
    public java.lang.String[] getSECTIONROLE() {
        return SECTIONROLE;
    }


    /**
     * Sets the SECTIONROLE value for this STAWFAC4WEBPASSSECTION.
     * 
     * @param SECTIONROLE
     */
    public void setSECTIONROLE(java.lang.String[] SECTIONROLE) {
        this.SECTIONROLE = SECTIONROLE;
    }


    /**
     * Gets the INSTITUTIONWORKFLOWLEVEL value for this STAWFAC4WEBPASSSECTION.
     * 
     * @return INSTITUTIONWORKFLOWLEVEL
     */
    public java.lang.String[] getINSTITUTIONWORKFLOWLEVEL() {
        return INSTITUTIONWORKFLOWLEVEL;
    }


    /**
     * Sets the INSTITUTIONWORKFLOWLEVEL value for this STAWFAC4WEBPASSSECTION.
     * 
     * @param INSTITUTIONWORKFLOWLEVEL
     */
    public void setINSTITUTIONWORKFLOWLEVEL(java.lang.String[] INSTITUTIONWORKFLOWLEVEL) {
        this.INSTITUTIONWORKFLOWLEVEL = INSTITUTIONWORKFLOWLEVEL;
    }


    /**
     * Gets the COMMENT value for this STAWFAC4WEBPASSSECTION.
     * 
     * @return COMMENT
     */
    public java.lang.String[] getCOMMENT() {
        return COMMENT;
    }


    /**
     * Sets the COMMENT value for this STAWFAC4WEBPASSSECTION.
     * 
     * @param COMMENT
     */
    public void setCOMMENT(java.lang.String[] COMMENT) {
        this.COMMENT = COMMENT;
    }


    /**
     * Gets the AGENTID value for this STAWFAC4WEBPASSSECTION.
     * 
     * @return AGENTID
     */
    public java.lang.String[] getAGENTID() {
        return AGENTID;
    }


    /**
     * Sets the AGENTID value for this STAWFAC4WEBPASSSECTION.
     * 
     * @param AGENTID
     */
    public void setAGENTID(java.lang.String[] AGENTID) {
        this.AGENTID = AGENTID;
    }


    /**
     * Gets the FULLNAME value for this STAWFAC4WEBPASSSECTION.
     * 
     * @return FULLNAME
     */
    public java.lang.String[] getFULLNAME() {
        return FULLNAME;
    }


    /**
     * Sets the FULLNAME value for this STAWFAC4WEBPASSSECTION.
     * 
     * @param FULLNAME
     */
    public void setFULLNAME(java.lang.String[] FULLNAME) {
        this.FULLNAME = FULLNAME;
    }


    /**
     * Gets the AGENTSIGNATUREDATE value for this STAWFAC4WEBPASSSECTION.
     * 
     * @return AGENTSIGNATUREDATE
     */
    public java.lang.String[] getAGENTSIGNATUREDATE() {
        return AGENTSIGNATUREDATE;
    }


    /**
     * Sets the AGENTSIGNATUREDATE value for this STAWFAC4WEBPASSSECTION.
     * 
     * @param AGENTSIGNATUREDATE
     */
    public void setAGENTSIGNATUREDATE(java.lang.String[] AGENTSIGNATUREDATE) {
        this.AGENTSIGNATUREDATE = AGENTSIGNATUREDATE;
    }


    /**
     * Gets the SECTIONSTATUS value for this STAWFAC4WEBPASSSECTION.
     * 
     * @return SECTIONSTATUS
     */
    public java.lang.String[] getSECTIONSTATUS() {
        return SECTIONSTATUS;
    }


    /**
     * Sets the SECTIONSTATUS value for this STAWFAC4WEBPASSSECTION.
     * 
     * @param SECTIONSTATUS
     */
    public void setSECTIONSTATUS(java.lang.String[] SECTIONSTATUS) {
        this.SECTIONSTATUS = SECTIONSTATUS;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof STAWFAC4WEBPASSSECTION)) return false;
        STAWFAC4WEBPASSSECTION other = (STAWFAC4WEBPASSSECTION) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.INSTITUTIONTYPEHOMEHOST==null && other.getINSTITUTIONTYPEHOMEHOST()==null) || 
             (this.INSTITUTIONTYPEHOMEHOST!=null &&
              java.util.Arrays.equals(this.INSTITUTIONTYPEHOMEHOST, other.getINSTITUTIONTYPEHOMEHOST()))) &&
            ((this.SECTIONTITLE==null && other.getSECTIONTITLE()==null) || 
             (this.SECTIONTITLE!=null &&
              java.util.Arrays.equals(this.SECTIONTITLE, other.getSECTIONTITLE()))) &&
            ((this.SECTIONROLE==null && other.getSECTIONROLE()==null) || 
             (this.SECTIONROLE!=null &&
              java.util.Arrays.equals(this.SECTIONROLE, other.getSECTIONROLE()))) &&
            ((this.INSTITUTIONWORKFLOWLEVEL==null && other.getINSTITUTIONWORKFLOWLEVEL()==null) || 
             (this.INSTITUTIONWORKFLOWLEVEL!=null &&
              java.util.Arrays.equals(this.INSTITUTIONWORKFLOWLEVEL, other.getINSTITUTIONWORKFLOWLEVEL()))) &&
            ((this.COMMENT==null && other.getCOMMENT()==null) || 
             (this.COMMENT!=null &&
              java.util.Arrays.equals(this.COMMENT, other.getCOMMENT()))) &&
            ((this.AGENTID==null && other.getAGENTID()==null) || 
             (this.AGENTID!=null &&
              java.util.Arrays.equals(this.AGENTID, other.getAGENTID()))) &&
            ((this.FULLNAME==null && other.getFULLNAME()==null) || 
             (this.FULLNAME!=null &&
              java.util.Arrays.equals(this.FULLNAME, other.getFULLNAME()))) &&
            ((this.AGENTSIGNATUREDATE==null && other.getAGENTSIGNATUREDATE()==null) || 
             (this.AGENTSIGNATUREDATE!=null &&
              java.util.Arrays.equals(this.AGENTSIGNATUREDATE, other.getAGENTSIGNATUREDATE()))) &&
            ((this.SECTIONSTATUS==null && other.getSECTIONSTATUS()==null) || 
             (this.SECTIONSTATUS!=null &&
              java.util.Arrays.equals(this.SECTIONSTATUS, other.getSECTIONSTATUS())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getINSTITUTIONTYPEHOMEHOST() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getINSTITUTIONTYPEHOMEHOST());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getINSTITUTIONTYPEHOMEHOST(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getSECTIONTITLE() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getSECTIONTITLE());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getSECTIONTITLE(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getSECTIONROLE() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getSECTIONROLE());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getSECTIONROLE(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getINSTITUTIONWORKFLOWLEVEL() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getINSTITUTIONWORKFLOWLEVEL());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getINSTITUTIONWORKFLOWLEVEL(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getCOMMENT() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getCOMMENT());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getCOMMENT(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getAGENTID() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getAGENTID());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getAGENTID(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getFULLNAME() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getFULLNAME());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getFULLNAME(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getAGENTSIGNATUREDATE() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getAGENTSIGNATUREDATE());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getAGENTSIGNATUREDATE(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getSECTIONSTATUS() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getSECTIONSTATUS());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getSECTIONSTATUS(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(STAWFAC4WEBPASSSECTION.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("urn:com-softwareag-entirex-rpc:ORIONWEB", ">>>STAWFAC4>WEB-PASS>SECTION"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("INSTITUTIONTYPEHOMEHOST");
        elemField.setXmlName(new javax.xml.namespace.QName("", "INSTITUTION-TYPE-HOME-HOST"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("", "string"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SECTIONTITLE");
        elemField.setXmlName(new javax.xml.namespace.QName("", "SECTION-TITLE"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("", "string"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SECTIONROLE");
        elemField.setXmlName(new javax.xml.namespace.QName("", "SECTION-ROLE"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("", "string"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("INSTITUTIONWORKFLOWLEVEL");
        elemField.setXmlName(new javax.xml.namespace.QName("", "INSTITUTION-WORKFLOW-LEVEL"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("", "string"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("COMMENT");
        elemField.setXmlName(new javax.xml.namespace.QName("", "COMMENT"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("", "string"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AGENTID");
        elemField.setXmlName(new javax.xml.namespace.QName("", "AGENT-ID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("", "string"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("FULLNAME");
        elemField.setXmlName(new javax.xml.namespace.QName("", "FULL-NAME"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("", "string"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AGENTSIGNATUREDATE");
        elemField.setXmlName(new javax.xml.namespace.QName("", "AGENT-SIGNATURE-DATE"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("", "string"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SECTIONSTATUS");
        elemField.setXmlName(new javax.xml.namespace.QName("", "SECTION-STATUS"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("", "string"));
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
