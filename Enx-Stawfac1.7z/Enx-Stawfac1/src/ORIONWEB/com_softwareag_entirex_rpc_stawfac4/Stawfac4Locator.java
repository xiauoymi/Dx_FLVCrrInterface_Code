/**
 * Stawfac4Locator.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package ORIONWEB.com_softwareag_entirex_rpc_stawfac4;
import edu.fccj.student.stawfac1.config.config;
public class Stawfac4Locator extends org.apache.axis.client.Service implements ORIONWEB.com_softwareag_entirex_rpc_stawfac4.Stawfac4 {

    public Stawfac4Locator() {
    }


    public Stawfac4Locator(org.apache.axis.EngineConfiguration config) {
        super(config);
    }

    public Stawfac4Locator(java.lang.String wsdlLoc, javax.xml.namespace.QName sName) throws javax.xml.rpc.ServiceException {
        super(wsdlLoc, sName);
    }

    // Use to get a proxy class for ORIONWEBPort
    private java.lang.String ORIONWEBPort_address = config.WebServiceURL;

    public java.lang.String getORIONWEBPortAddress() {
        return ORIONWEBPort_address;
    }

    // The WSDD service name defaults to the port name.
    private java.lang.String ORIONWEBPortWSDDServiceName = "ORIONWEBPort";

    public java.lang.String getORIONWEBPortWSDDServiceName() {
        return ORIONWEBPortWSDDServiceName;
    }

    public void setORIONWEBPortWSDDServiceName(java.lang.String name) {
        ORIONWEBPortWSDDServiceName = name;
    }

    public ORIONWEB.com_softwareag_entirex_rpc_stawfac4.ORIONWEBPort getORIONWEBPort() throws javax.xml.rpc.ServiceException {
       java.net.URL endpoint;
        try {
            endpoint = new java.net.URL(ORIONWEBPort_address);
        }
        catch (java.net.MalformedURLException e) {
            throw new javax.xml.rpc.ServiceException(e);
        }
        return getORIONWEBPort(endpoint);
    }

    public ORIONWEB.com_softwareag_entirex_rpc_stawfac4.ORIONWEBPort getORIONWEBPort(java.net.URL portAddress) throws javax.xml.rpc.ServiceException {
        try {
            ORIONWEB.com_softwareag_entirex_rpc_stawfac4.ORIONWEBSoapBindingStub _stub = new ORIONWEB.com_softwareag_entirex_rpc_stawfac4.ORIONWEBSoapBindingStub(portAddress, this);
            _stub.setPortName(getORIONWEBPortWSDDServiceName());
            return _stub;
        }
        catch (org.apache.axis.AxisFault e) {
            return null;
        }
    }

    public void setORIONWEBPortEndpointAddress(java.lang.String address) {
        ORIONWEBPort_address = address;
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        try {
            if (ORIONWEB.com_softwareag_entirex_rpc_stawfac4.ORIONWEBPort.class.isAssignableFrom(serviceEndpointInterface)) {
                ORIONWEB.com_softwareag_entirex_rpc_stawfac4.ORIONWEBSoapBindingStub _stub = new ORIONWEB.com_softwareag_entirex_rpc_stawfac4.ORIONWEBSoapBindingStub(new java.net.URL(ORIONWEBPort_address), this);
                _stub.setPortName(getORIONWEBPortWSDDServiceName());
                return _stub;
            }
        }
        catch (java.lang.Throwable t) {
            throw new javax.xml.rpc.ServiceException(t);
        }
        throw new javax.xml.rpc.ServiceException("There is no stub implementation for the interface:  " + (serviceEndpointInterface == null ? "null" : serviceEndpointInterface.getName()));
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(javax.xml.namespace.QName portName, Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        if (portName == null) {
            return getPort(serviceEndpointInterface);
        }
        java.lang.String inputPortName = portName.getLocalPart();
        if ("ORIONWEBPort".equals(inputPortName)) {
            return getORIONWEBPort();
        }
        else  {
            java.rmi.Remote _stub = getPort(serviceEndpointInterface);
            ((org.apache.axis.client.Stub) _stub).setPortName(portName);
            return _stub;
        }
    }

    public javax.xml.namespace.QName getServiceName() {
        return new javax.xml.namespace.QName("urn:com-softwareag-entirex-rpc:ORIONWEB", "stawfac4");
    }

    private java.util.HashSet ports = null;

    public java.util.Iterator getPorts() {
        if (ports == null) {
            ports = new java.util.HashSet();
            ports.add(new javax.xml.namespace.QName("urn:com-softwareag-entirex-rpc:ORIONWEB", "ORIONWEBPort"));
        }
        return ports.iterator();
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(java.lang.String portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        
if ("ORIONWEBPort".equals(portName)) {
            setORIONWEBPortEndpointAddress(address);
        }
        else 
{ // Unknown Port Name
            throw new javax.xml.rpc.ServiceException(" Cannot set Endpoint Address for Unknown Port" + portName);
        }
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(javax.xml.namespace.QName portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        setEndpointAddress(portName.getLocalPart(), address);
    }

}
