/**
 * STAWFAC4ResponseWEBPASS1SECTION1.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package ORIONWEB.com_softwareag_entirex_rpc_stawfac4;

public class STAWFAC4ResponseWEBPASS1SECTION1  implements java.io.Serializable {
    private java.lang.String[] INSTITUTIONTYPEHOMEHOST1;

    private java.lang.String[] SECTIONTITLE1;

    private java.lang.String[] SECTIONROLE1;

    private java.lang.String[] INSTITUTIONWORKFLOWLEVEL1;

    private java.lang.String[] COMMENT1;

    private java.lang.String[] AGENTID1;

    private java.lang.String[] FULLNAME1;

    private java.lang.String[] AGENTSIGNATUREDATE1;

    private java.lang.String[] SECTIONSTATUS1;

    public STAWFAC4ResponseWEBPASS1SECTION1() {
    }

    public STAWFAC4ResponseWEBPASS1SECTION1(
           java.lang.String[] INSTITUTIONTYPEHOMEHOST1,
           java.lang.String[] SECTIONTITLE1,
           java.lang.String[] SECTIONROLE1,
           java.lang.String[] INSTITUTIONWORKFLOWLEVEL1,
           java.lang.String[] COMMENT1,
           java.lang.String[] AGENTID1,
           java.lang.String[] FULLNAME1,
           java.lang.String[] AGENTSIGNATUREDATE1,
           java.lang.String[] SECTIONSTATUS1) {
           this.INSTITUTIONTYPEHOMEHOST1 = INSTITUTIONTYPEHOMEHOST1;
           this.SECTIONTITLE1 = SECTIONTITLE1;
           this.SECTIONROLE1 = SECTIONROLE1;
           this.INSTITUTIONWORKFLOWLEVEL1 = INSTITUTIONWORKFLOWLEVEL1;
           this.COMMENT1 = COMMENT1;
           this.AGENTID1 = AGENTID1;
           this.FULLNAME1 = FULLNAME1;
           this.AGENTSIGNATUREDATE1 = AGENTSIGNATUREDATE1;
           this.SECTIONSTATUS1 = SECTIONSTATUS1;
    }


    /**
     * Gets the INSTITUTIONTYPEHOMEHOST1 value for this STAWFAC4ResponseWEBPASS1SECTION1.
     * 
     * @return INSTITUTIONTYPEHOMEHOST1
     */
    public java.lang.String[] getINSTITUTIONTYPEHOMEHOST1() {
        return INSTITUTIONTYPEHOMEHOST1;
    }


    /**
     * Sets the INSTITUTIONTYPEHOMEHOST1 value for this STAWFAC4ResponseWEBPASS1SECTION1.
     * 
     * @param INSTITUTIONTYPEHOMEHOST1
     */
    public void setINSTITUTIONTYPEHOMEHOST1(java.lang.String[] INSTITUTIONTYPEHOMEHOST1) {
        this.INSTITUTIONTYPEHOMEHOST1 = INSTITUTIONTYPEHOMEHOST1;
    }


    /**
     * Gets the SECTIONTITLE1 value for this STAWFAC4ResponseWEBPASS1SECTION1.
     * 
     * @return SECTIONTITLE1
     */
    public java.lang.String[] getSECTIONTITLE1() {
        return SECTIONTITLE1;
    }


    /**
     * Sets the SECTIONTITLE1 value for this STAWFAC4ResponseWEBPASS1SECTION1.
     * 
     * @param SECTIONTITLE1
     */
    public void setSECTIONTITLE1(java.lang.String[] SECTIONTITLE1) {
        this.SECTIONTITLE1 = SECTIONTITLE1;
    }


    /**
     * Gets the SECTIONROLE1 value for this STAWFAC4ResponseWEBPASS1SECTION1.
     * 
     * @return SECTIONROLE1
     */
    public java.lang.String[] getSECTIONROLE1() {
        return SECTIONROLE1;
    }


    /**
     * Sets the SECTIONROLE1 value for this STAWFAC4ResponseWEBPASS1SECTION1.
     * 
     * @param SECTIONROLE1
     */
    public void setSECTIONROLE1(java.lang.String[] SECTIONROLE1) {
        this.SECTIONROLE1 = SECTIONROLE1;
    }


    /**
     * Gets the INSTITUTIONWORKFLOWLEVEL1 value for this STAWFAC4ResponseWEBPASS1SECTION1.
     * 
     * @return INSTITUTIONWORKFLOWLEVEL1
     */
    public java.lang.String[] getINSTITUTIONWORKFLOWLEVEL1() {
        return INSTITUTIONWORKFLOWLEVEL1;
    }


    /**
     * Sets the INSTITUTIONWORKFLOWLEVEL1 value for this STAWFAC4ResponseWEBPASS1SECTION1.
     * 
     * @param INSTITUTIONWORKFLOWLEVEL1
     */
    public void setINSTITUTIONWORKFLOWLEVEL1(java.lang.String[] INSTITUTIONWORKFLOWLEVEL1) {
        this.INSTITUTIONWORKFLOWLEVEL1 = INSTITUTIONWORKFLOWLEVEL1;
    }


    /**
     * Gets the COMMENT1 value for this STAWFAC4ResponseWEBPASS1SECTION1.
     * 
     * @return COMMENT1
     */
    public java.lang.String[] getCOMMENT1() {
        return COMMENT1;
    }


    /**
     * Sets the COMMENT1 value for this STAWFAC4ResponseWEBPASS1SECTION1.
     * 
     * @param COMMENT1
     */
    public void setCOMMENT1(java.lang.String[] COMMENT1) {
        this.COMMENT1 = COMMENT1;
    }


    /**
     * Gets the AGENTID1 value for this STAWFAC4ResponseWEBPASS1SECTION1.
     * 
     * @return AGENTID1
     */
    public java.lang.String[] getAGENTID1() {
        return AGENTID1;
    }


    /**
     * Sets the AGENTID1 value for this STAWFAC4ResponseWEBPASS1SECTION1.
     * 
     * @param AGENTID1
     */
    public void setAGENTID1(java.lang.String[] AGENTID1) {
        this.AGENTID1 = AGENTID1;
    }


    /**
     * Gets the FULLNAME1 value for this STAWFAC4ResponseWEBPASS1SECTION1.
     * 
     * @return FULLNAME1
     */
    public java.lang.String[] getFULLNAME1() {
        return FULLNAME1;
    }


    /**
     * Sets the FULLNAME1 value for this STAWFAC4ResponseWEBPASS1SECTION1.
     * 
     * @param FULLNAME1
     */
    public void setFULLNAME1(java.lang.String[] FULLNAME1) {
        this.FULLNAME1 = FULLNAME1;
    }


    /**
     * Gets the AGENTSIGNATUREDATE1 value for this STAWFAC4ResponseWEBPASS1SECTION1.
     * 
     * @return AGENTSIGNATUREDATE1
     */
    public java.lang.String[] getAGENTSIGNATUREDATE1() {
        return AGENTSIGNATUREDATE1;
    }


    /**
     * Sets the AGENTSIGNATUREDATE1 value for this STAWFAC4ResponseWEBPASS1SECTION1.
     * 
     * @param AGENTSIGNATUREDATE1
     */
    public void setAGENTSIGNATUREDATE1(java.lang.String[] AGENTSIGNATUREDATE1) {
        this.AGENTSIGNATUREDATE1 = AGENTSIGNATUREDATE1;
    }


    /**
     * Gets the SECTIONSTATUS1 value for this STAWFAC4ResponseWEBPASS1SECTION1.
     * 
     * @return SECTIONSTATUS1
     */
    public java.lang.String[] getSECTIONSTATUS1() {
        return SECTIONSTATUS1;
    }


    /**
     * Sets the SECTIONSTATUS1 value for this STAWFAC4ResponseWEBPASS1SECTION1.
     * 
     * @param SECTIONSTATUS1
     */
    public void setSECTIONSTATUS1(java.lang.String[] SECTIONSTATUS1) {
        this.SECTIONSTATUS1 = SECTIONSTATUS1;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof STAWFAC4ResponseWEBPASS1SECTION1)) return false;
        STAWFAC4ResponseWEBPASS1SECTION1 other = (STAWFAC4ResponseWEBPASS1SECTION1) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.INSTITUTIONTYPEHOMEHOST1==null && other.getINSTITUTIONTYPEHOMEHOST1()==null) || 
             (this.INSTITUTIONTYPEHOMEHOST1!=null &&
              java.util.Arrays.equals(this.INSTITUTIONTYPEHOMEHOST1, other.getINSTITUTIONTYPEHOMEHOST1()))) &&
            ((this.SECTIONTITLE1==null && other.getSECTIONTITLE1()==null) || 
             (this.SECTIONTITLE1!=null &&
              java.util.Arrays.equals(this.SECTIONTITLE1, other.getSECTIONTITLE1()))) &&
            ((this.SECTIONROLE1==null && other.getSECTIONROLE1()==null) || 
             (this.SECTIONROLE1!=null &&
              java.util.Arrays.equals(this.SECTIONROLE1, other.getSECTIONROLE1()))) &&
            ((this.INSTITUTIONWORKFLOWLEVEL1==null && other.getINSTITUTIONWORKFLOWLEVEL1()==null) || 
             (this.INSTITUTIONWORKFLOWLEVEL1!=null &&
              java.util.Arrays.equals(this.INSTITUTIONWORKFLOWLEVEL1, other.getINSTITUTIONWORKFLOWLEVEL1()))) &&
            ((this.COMMENT1==null && other.getCOMMENT1()==null) || 
             (this.COMMENT1!=null &&
              java.util.Arrays.equals(this.COMMENT1, other.getCOMMENT1()))) &&
            ((this.AGENTID1==null && other.getAGENTID1()==null) || 
             (this.AGENTID1!=null &&
              java.util.Arrays.equals(this.AGENTID1, other.getAGENTID1()))) &&
            ((this.FULLNAME1==null && other.getFULLNAME1()==null) || 
             (this.FULLNAME1!=null &&
              java.util.Arrays.equals(this.FULLNAME1, other.getFULLNAME1()))) &&
            ((this.AGENTSIGNATUREDATE1==null && other.getAGENTSIGNATUREDATE1()==null) || 
             (this.AGENTSIGNATUREDATE1!=null &&
              java.util.Arrays.equals(this.AGENTSIGNATUREDATE1, other.getAGENTSIGNATUREDATE1()))) &&
            ((this.SECTIONSTATUS1==null && other.getSECTIONSTATUS1()==null) || 
             (this.SECTIONSTATUS1!=null &&
              java.util.Arrays.equals(this.SECTIONSTATUS1, other.getSECTIONSTATUS1())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getINSTITUTIONTYPEHOMEHOST1() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getINSTITUTIONTYPEHOMEHOST1());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getINSTITUTIONTYPEHOMEHOST1(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getSECTIONTITLE1() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getSECTIONTITLE1());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getSECTIONTITLE1(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getSECTIONROLE1() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getSECTIONROLE1());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getSECTIONROLE1(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getINSTITUTIONWORKFLOWLEVEL1() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getINSTITUTIONWORKFLOWLEVEL1());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getINSTITUTIONWORKFLOWLEVEL1(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getCOMMENT1() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getCOMMENT1());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getCOMMENT1(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getAGENTID1() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getAGENTID1());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getAGENTID1(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getFULLNAME1() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getFULLNAME1());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getFULLNAME1(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getAGENTSIGNATUREDATE1() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getAGENTSIGNATUREDATE1());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getAGENTSIGNATUREDATE1(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getSECTIONSTATUS1() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getSECTIONSTATUS1());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getSECTIONSTATUS1(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(STAWFAC4ResponseWEBPASS1SECTION1.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("urn:com-softwareag-entirex-rpc:ORIONWEB", ">>>STAWFAC4Response>WEB-PASS1>SECTION1"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("INSTITUTIONTYPEHOMEHOST1");
        elemField.setXmlName(new javax.xml.namespace.QName("", "INSTITUTION-TYPE-HOME-HOST1"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("", "string"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SECTIONTITLE1");
        elemField.setXmlName(new javax.xml.namespace.QName("", "SECTION-TITLE1"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("", "string"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SECTIONROLE1");
        elemField.setXmlName(new javax.xml.namespace.QName("", "SECTION-ROLE1"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("", "string"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("INSTITUTIONWORKFLOWLEVEL1");
        elemField.setXmlName(new javax.xml.namespace.QName("", "INSTITUTION-WORKFLOW-LEVEL1"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("", "string"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("COMMENT1");
        elemField.setXmlName(new javax.xml.namespace.QName("", "COMMENT1"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("", "string"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AGENTID1");
        elemField.setXmlName(new javax.xml.namespace.QName("", "AGENT-ID1"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("", "string"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("FULLNAME1");
        elemField.setXmlName(new javax.xml.namespace.QName("", "FULL-NAME1"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("", "string"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AGENTSIGNATUREDATE1");
        elemField.setXmlName(new javax.xml.namespace.QName("", "AGENT-SIGNATURE-DATE1"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("", "string"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SECTIONSTATUS1");
        elemField.setXmlName(new javax.xml.namespace.QName("", "SECTION-STATUS1"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("", "string"));
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
