/**
 * Stawfac4.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package ORIONWEB.com_softwareag_entirex_rpc_stawfac4;

public interface Stawfac4 extends javax.xml.rpc.Service {
    public java.lang.String getORIONWEBPortAddress();

    public ORIONWEB.com_softwareag_entirex_rpc_stawfac4.ORIONWEBPort getORIONWEBPort() throws javax.xml.rpc.ServiceException;

    public ORIONWEB.com_softwareag_entirex_rpc_stawfac4.ORIONWEBPort getORIONWEBPort(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
