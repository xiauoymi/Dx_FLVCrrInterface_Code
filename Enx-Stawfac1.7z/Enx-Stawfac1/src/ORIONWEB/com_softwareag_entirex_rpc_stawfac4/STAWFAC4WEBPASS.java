/**
 * STAWFAC4WEBPASS.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package ORIONWEB.com_softwareag_entirex_rpc_stawfac4;

public class STAWFAC4WEBPASS  implements java.io.Serializable {
    private java.lang.String STDNTID;

    private java.lang.String STDNTSSN;

    private java.lang.String INSTID;

    private java.lang.String INSTTYPE;

    private java.lang.String RECVDDATE;

    private java.lang.String RECVDTIME;

    private java.lang.String STDNTCOMMENT;

    private java.math.BigDecimal c_COURSEINFORMATION;

    private ORIONWEB.com_softwareag_entirex_rpc_stawfac4.STAWFAC4WEBPASSCOURSEINFORMATION COURSEINFORMATION;

    private java.lang.String[] ADMISSIONSNOTES;

    private java.lang.String APPLIEDFORFINAID;

    private java.lang.String CONTINUENOFINAID;

    private java.lang.String FACTSID;

    private java.lang.String CONFIRMATIONNUMBER;

    private java.lang.String CONFIRMATIONCODE;

    private java.lang.String TRACKINGNUMBER;

    private java.lang.String REQUIREDVACCINATIONSIND;

    private java.lang.String ELIGIBLETOREENROLLIND;

    private java.lang.String DEGREEPROGRAMENROLLMENTIND;

    private java.lang.String HOMEINSTITUTIONFICECODE;

    private java.math.BigDecimal c_SECTION;

    private ORIONWEB.com_softwareag_entirex_rpc_stawfac4.STAWFAC4WEBPASSSECTION SECTION;

    private java.lang.String QUESTION1;

    private java.lang.String ANSWER1;

    private java.lang.String QUESTION2;

    private java.lang.String ANSWER2;

    private java.lang.String QUESTION3;

    private java.lang.String ANSWER3;

    private java.lang.String QUESTION4;

    private java.lang.String ANSWER4;

    private java.lang.String QUESTION5;

    private java.lang.String ANSWER5;

    private java.lang.String RETURNCODE;

    private java.lang.String[] RETURNMESSAGE;

    private java.lang.String SUBMITTEDTIMESTAMP;

    private java.lang.String _RC;

    private java.lang.String _RCMSG;

    public STAWFAC4WEBPASS() {
    }

    public STAWFAC4WEBPASS(
           java.lang.String STDNTID,
           java.lang.String STDNTSSN,
           java.lang.String INSTID,
           java.lang.String INSTTYPE,
           java.lang.String RECVDDATE,
           java.lang.String RECVDTIME,
           java.lang.String STDNTCOMMENT,
           java.math.BigDecimal c_COURSEINFORMATION,
           ORIONWEB.com_softwareag_entirex_rpc_stawfac4.STAWFAC4WEBPASSCOURSEINFORMATION COURSEINFORMATION,
           java.lang.String[] ADMISSIONSNOTES,
           java.lang.String APPLIEDFORFINAID,
           java.lang.String CONTINUENOFINAID,
           java.lang.String FACTSID,
           java.lang.String CONFIRMATIONNUMBER,
           java.lang.String CONFIRMATIONCODE,
           java.lang.String TRACKINGNUMBER,
           java.lang.String REQUIREDVACCINATIONSIND,
           java.lang.String ELIGIBLETOREENROLLIND,
           java.lang.String DEGREEPROGRAMENROLLMENTIND,
           java.lang.String HOMEINSTITUTIONFICECODE,
           java.math.BigDecimal c_SECTION,
           ORIONWEB.com_softwareag_entirex_rpc_stawfac4.STAWFAC4WEBPASSSECTION SECTION,
           java.lang.String QUESTION1,
           java.lang.String ANSWER1,
           java.lang.String QUESTION2,
           java.lang.String ANSWER2,
           java.lang.String QUESTION3,
           java.lang.String ANSWER3,
           java.lang.String QUESTION4,
           java.lang.String ANSWER4,
           java.lang.String QUESTION5,
           java.lang.String ANSWER5,
           java.lang.String RETURNCODE,
           java.lang.String[] RETURNMESSAGE,
           java.lang.String SUBMITTEDTIMESTAMP,
           java.lang.String _RC,
           java.lang.String _RCMSG) {
           this.STDNTID = STDNTID;
           this.STDNTSSN = STDNTSSN;
           this.INSTID = INSTID;
           this.INSTTYPE = INSTTYPE;
           this.RECVDDATE = RECVDDATE;
           this.RECVDTIME = RECVDTIME;
           this.STDNTCOMMENT = STDNTCOMMENT;
           this.c_COURSEINFORMATION = c_COURSEINFORMATION;
           this.COURSEINFORMATION = COURSEINFORMATION;
           this.ADMISSIONSNOTES = ADMISSIONSNOTES;
           this.APPLIEDFORFINAID = APPLIEDFORFINAID;
           this.CONTINUENOFINAID = CONTINUENOFINAID;
           this.FACTSID = FACTSID;
           this.CONFIRMATIONNUMBER = CONFIRMATIONNUMBER;
           this.CONFIRMATIONCODE = CONFIRMATIONCODE;
           this.TRACKINGNUMBER = TRACKINGNUMBER;
           this.REQUIREDVACCINATIONSIND = REQUIREDVACCINATIONSIND;
           this.ELIGIBLETOREENROLLIND = ELIGIBLETOREENROLLIND;
           this.DEGREEPROGRAMENROLLMENTIND = DEGREEPROGRAMENROLLMENTIND;
           this.HOMEINSTITUTIONFICECODE = HOMEINSTITUTIONFICECODE;
           this.c_SECTION = c_SECTION;
           this.SECTION = SECTION;
           this.QUESTION1 = QUESTION1;
           this.ANSWER1 = ANSWER1;
           this.QUESTION2 = QUESTION2;
           this.ANSWER2 = ANSWER2;
           this.QUESTION3 = QUESTION3;
           this.ANSWER3 = ANSWER3;
           this.QUESTION4 = QUESTION4;
           this.ANSWER4 = ANSWER4;
           this.QUESTION5 = QUESTION5;
           this.ANSWER5 = ANSWER5;
           this.RETURNCODE = RETURNCODE;
           this.RETURNMESSAGE = RETURNMESSAGE;
           this.SUBMITTEDTIMESTAMP = SUBMITTEDTIMESTAMP;
           this._RC = _RC;
           this._RCMSG = _RCMSG;
    }


    /**
     * Gets the STDNTID value for this STAWFAC4WEBPASS.
     * 
     * @return STDNTID
     */
    public java.lang.String getSTDNTID() {
        return STDNTID;
    }


    /**
     * Sets the STDNTID value for this STAWFAC4WEBPASS.
     * 
     * @param STDNTID
     */
    public void setSTDNTID(java.lang.String STDNTID) {
        this.STDNTID = STDNTID;
    }


    /**
     * Gets the STDNTSSN value for this STAWFAC4WEBPASS.
     * 
     * @return STDNTSSN
     */
    public java.lang.String getSTDNTSSN() {
        return STDNTSSN;
    }


    /**
     * Sets the STDNTSSN value for this STAWFAC4WEBPASS.
     * 
     * @param STDNTSSN
     */
    public void setSTDNTSSN(java.lang.String STDNTSSN) {
        this.STDNTSSN = STDNTSSN;
    }


    /**
     * Gets the INSTID value for this STAWFAC4WEBPASS.
     * 
     * @return INSTID
     */
    public java.lang.String getINSTID() {
        return INSTID;
    }


    /**
     * Sets the INSTID value for this STAWFAC4WEBPASS.
     * 
     * @param INSTID
     */
    public void setINSTID(java.lang.String INSTID) {
        this.INSTID = INSTID;
    }


    /**
     * Gets the INSTTYPE value for this STAWFAC4WEBPASS.
     * 
     * @return INSTTYPE
     */
    public java.lang.String getINSTTYPE() {
        return INSTTYPE;
    }


    /**
     * Sets the INSTTYPE value for this STAWFAC4WEBPASS.
     * 
     * @param INSTTYPE
     */
    public void setINSTTYPE(java.lang.String INSTTYPE) {
        this.INSTTYPE = INSTTYPE;
    }


    /**
     * Gets the RECVDDATE value for this STAWFAC4WEBPASS.
     * 
     * @return RECVDDATE
     */
    public java.lang.String getRECVDDATE() {
        return RECVDDATE;
    }


    /**
     * Sets the RECVDDATE value for this STAWFAC4WEBPASS.
     * 
     * @param RECVDDATE
     */
    public void setRECVDDATE(java.lang.String RECVDDATE) {
        this.RECVDDATE = RECVDDATE;
    }


    /**
     * Gets the RECVDTIME value for this STAWFAC4WEBPASS.
     * 
     * @return RECVDTIME
     */
    public java.lang.String getRECVDTIME() {
        return RECVDTIME;
    }


    /**
     * Sets the RECVDTIME value for this STAWFAC4WEBPASS.
     * 
     * @param RECVDTIME
     */
    public void setRECVDTIME(java.lang.String RECVDTIME) {
        this.RECVDTIME = RECVDTIME;
    }


    /**
     * Gets the STDNTCOMMENT value for this STAWFAC4WEBPASS.
     * 
     * @return STDNTCOMMENT
     */
    public java.lang.String getSTDNTCOMMENT() {
        return STDNTCOMMENT;
    }


    /**
     * Sets the STDNTCOMMENT value for this STAWFAC4WEBPASS.
     * 
     * @param STDNTCOMMENT
     */
    public void setSTDNTCOMMENT(java.lang.String STDNTCOMMENT) {
        this.STDNTCOMMENT = STDNTCOMMENT;
    }


    /**
     * Gets the c_COURSEINFORMATION value for this STAWFAC4WEBPASS.
     * 
     * @return c_COURSEINFORMATION
     */
    public java.math.BigDecimal getC_COURSEINFORMATION() {
        return c_COURSEINFORMATION;
    }


    /**
     * Sets the c_COURSEINFORMATION value for this STAWFAC4WEBPASS.
     * 
     * @param c_COURSEINFORMATION
     */
    public void setC_COURSEINFORMATION(java.math.BigDecimal c_COURSEINFORMATION) {
        this.c_COURSEINFORMATION = c_COURSEINFORMATION;
    }


    /**
     * Gets the COURSEINFORMATION value for this STAWFAC4WEBPASS.
     * 
     * @return COURSEINFORMATION
     */
    public ORIONWEB.com_softwareag_entirex_rpc_stawfac4.STAWFAC4WEBPASSCOURSEINFORMATION getCOURSEINFORMATION() {
        return COURSEINFORMATION;
    }


    /**
     * Sets the COURSEINFORMATION value for this STAWFAC4WEBPASS.
     * 
     * @param COURSEINFORMATION
     */
    public void setCOURSEINFORMATION(ORIONWEB.com_softwareag_entirex_rpc_stawfac4.STAWFAC4WEBPASSCOURSEINFORMATION COURSEINFORMATION) {
        this.COURSEINFORMATION = COURSEINFORMATION;
    }


    /**
     * Gets the ADMISSIONSNOTES value for this STAWFAC4WEBPASS.
     * 
     * @return ADMISSIONSNOTES
     */
    public java.lang.String[] getADMISSIONSNOTES() {
        return ADMISSIONSNOTES;
    }


    /**
     * Sets the ADMISSIONSNOTES value for this STAWFAC4WEBPASS.
     * 
     * @param ADMISSIONSNOTES
     */
    public void setADMISSIONSNOTES(java.lang.String[] ADMISSIONSNOTES) {
        this.ADMISSIONSNOTES = ADMISSIONSNOTES;
    }


    /**
     * Gets the APPLIEDFORFINAID value for this STAWFAC4WEBPASS.
     * 
     * @return APPLIEDFORFINAID
     */
    public java.lang.String getAPPLIEDFORFINAID() {
        return APPLIEDFORFINAID;
    }


    /**
     * Sets the APPLIEDFORFINAID value for this STAWFAC4WEBPASS.
     * 
     * @param APPLIEDFORFINAID
     */
    public void setAPPLIEDFORFINAID(java.lang.String APPLIEDFORFINAID) {
        this.APPLIEDFORFINAID = APPLIEDFORFINAID;
    }


    /**
     * Gets the CONTINUENOFINAID value for this STAWFAC4WEBPASS.
     * 
     * @return CONTINUENOFINAID
     */
    public java.lang.String getCONTINUENOFINAID() {
        return CONTINUENOFINAID;
    }


    /**
     * Sets the CONTINUENOFINAID value for this STAWFAC4WEBPASS.
     * 
     * @param CONTINUENOFINAID
     */
    public void setCONTINUENOFINAID(java.lang.String CONTINUENOFINAID) {
        this.CONTINUENOFINAID = CONTINUENOFINAID;
    }


    /**
     * Gets the FACTSID value for this STAWFAC4WEBPASS.
     * 
     * @return FACTSID
     */
    public java.lang.String getFACTSID() {
        return FACTSID;
    }


    /**
     * Sets the FACTSID value for this STAWFAC4WEBPASS.
     * 
     * @param FACTSID
     */
    public void setFACTSID(java.lang.String FACTSID) {
        this.FACTSID = FACTSID;
    }


    /**
     * Gets the CONFIRMATIONNUMBER value for this STAWFAC4WEBPASS.
     * 
     * @return CONFIRMATIONNUMBER
     */
    public java.lang.String getCONFIRMATIONNUMBER() {
        return CONFIRMATIONNUMBER;
    }


    /**
     * Sets the CONFIRMATIONNUMBER value for this STAWFAC4WEBPASS.
     * 
     * @param CONFIRMATIONNUMBER
     */
    public void setCONFIRMATIONNUMBER(java.lang.String CONFIRMATIONNUMBER) {
        this.CONFIRMATIONNUMBER = CONFIRMATIONNUMBER;
    }


    /**
     * Gets the CONFIRMATIONCODE value for this STAWFAC4WEBPASS.
     * 
     * @return CONFIRMATIONCODE
     */
    public java.lang.String getCONFIRMATIONCODE() {
        return CONFIRMATIONCODE;
    }


    /**
     * Sets the CONFIRMATIONCODE value for this STAWFAC4WEBPASS.
     * 
     * @param CONFIRMATIONCODE
     */
    public void setCONFIRMATIONCODE(java.lang.String CONFIRMATIONCODE) {
        this.CONFIRMATIONCODE = CONFIRMATIONCODE;
    }


    /**
     * Gets the TRACKINGNUMBER value for this STAWFAC4WEBPASS.
     * 
     * @return TRACKINGNUMBER
     */
    public java.lang.String getTRACKINGNUMBER() {
        return TRACKINGNUMBER;
    }


    /**
     * Sets the TRACKINGNUMBER value for this STAWFAC4WEBPASS.
     * 
     * @param TRACKINGNUMBER
     */
    public void setTRACKINGNUMBER(java.lang.String TRACKINGNUMBER) {
        this.TRACKINGNUMBER = TRACKINGNUMBER;
    }


    /**
     * Gets the REQUIREDVACCINATIONSIND value for this STAWFAC4WEBPASS.
     * 
     * @return REQUIREDVACCINATIONSIND
     */
    public java.lang.String getREQUIREDVACCINATIONSIND() {
        return REQUIREDVACCINATIONSIND;
    }


    /**
     * Sets the REQUIREDVACCINATIONSIND value for this STAWFAC4WEBPASS.
     * 
     * @param REQUIREDVACCINATIONSIND
     */
    public void setREQUIREDVACCINATIONSIND(java.lang.String REQUIREDVACCINATIONSIND) {
        this.REQUIREDVACCINATIONSIND = REQUIREDVACCINATIONSIND;
    }


    /**
     * Gets the ELIGIBLETOREENROLLIND value for this STAWFAC4WEBPASS.
     * 
     * @return ELIGIBLETOREENROLLIND
     */
    public java.lang.String getELIGIBLETOREENROLLIND() {
        return ELIGIBLETOREENROLLIND;
    }


    /**
     * Sets the ELIGIBLETOREENROLLIND value for this STAWFAC4WEBPASS.
     * 
     * @param ELIGIBLETOREENROLLIND
     */
    public void setELIGIBLETOREENROLLIND(java.lang.String ELIGIBLETOREENROLLIND) {
        this.ELIGIBLETOREENROLLIND = ELIGIBLETOREENROLLIND;
    }


    /**
     * Gets the DEGREEPROGRAMENROLLMENTIND value for this STAWFAC4WEBPASS.
     * 
     * @return DEGREEPROGRAMENROLLMENTIND
     */
    public java.lang.String getDEGREEPROGRAMENROLLMENTIND() {
        return DEGREEPROGRAMENROLLMENTIND;
    }


    /**
     * Sets the DEGREEPROGRAMENROLLMENTIND value for this STAWFAC4WEBPASS.
     * 
     * @param DEGREEPROGRAMENROLLMENTIND
     */
    public void setDEGREEPROGRAMENROLLMENTIND(java.lang.String DEGREEPROGRAMENROLLMENTIND) {
        this.DEGREEPROGRAMENROLLMENTIND = DEGREEPROGRAMENROLLMENTIND;
    }


    /**
     * Gets the HOMEINSTITUTIONFICECODE value for this STAWFAC4WEBPASS.
     * 
     * @return HOMEINSTITUTIONFICECODE
     */
    public java.lang.String getHOMEINSTITUTIONFICECODE() {
        return HOMEINSTITUTIONFICECODE;
    }


    /**
     * Sets the HOMEINSTITUTIONFICECODE value for this STAWFAC4WEBPASS.
     * 
     * @param HOMEINSTITUTIONFICECODE
     */
    public void setHOMEINSTITUTIONFICECODE(java.lang.String HOMEINSTITUTIONFICECODE) {
        this.HOMEINSTITUTIONFICECODE = HOMEINSTITUTIONFICECODE;
    }


    /**
     * Gets the c_SECTION value for this STAWFAC4WEBPASS.
     * 
     * @return c_SECTION
     */
    public java.math.BigDecimal getC_SECTION() {
        return c_SECTION;
    }


    /**
     * Sets the c_SECTION value for this STAWFAC4WEBPASS.
     * 
     * @param c_SECTION
     */
    public void setC_SECTION(java.math.BigDecimal c_SECTION) {
        this.c_SECTION = c_SECTION;
    }


    /**
     * Gets the SECTION value for this STAWFAC4WEBPASS.
     * 
     * @return SECTION
     */
    public ORIONWEB.com_softwareag_entirex_rpc_stawfac4.STAWFAC4WEBPASSSECTION getSECTION() {
        return SECTION;
    }


    /**
     * Sets the SECTION value for this STAWFAC4WEBPASS.
     * 
     * @param SECTION
     */
    public void setSECTION(ORIONWEB.com_softwareag_entirex_rpc_stawfac4.STAWFAC4WEBPASSSECTION SECTION) {
        this.SECTION = SECTION;
    }


    /**
     * Gets the QUESTION1 value for this STAWFAC4WEBPASS.
     * 
     * @return QUESTION1
     */
    public java.lang.String getQUESTION1() {
        return QUESTION1;
    }


    /**
     * Sets the QUESTION1 value for this STAWFAC4WEBPASS.
     * 
     * @param QUESTION1
     */
    public void setQUESTION1(java.lang.String QUESTION1) {
        this.QUESTION1 = QUESTION1;
    }


    /**
     * Gets the ANSWER1 value for this STAWFAC4WEBPASS.
     * 
     * @return ANSWER1
     */
    public java.lang.String getANSWER1() {
        return ANSWER1;
    }


    /**
     * Sets the ANSWER1 value for this STAWFAC4WEBPASS.
     * 
     * @param ANSWER1
     */
    public void setANSWER1(java.lang.String ANSWER1) {
        this.ANSWER1 = ANSWER1;
    }


    /**
     * Gets the QUESTION2 value for this STAWFAC4WEBPASS.
     * 
     * @return QUESTION2
     */
    public java.lang.String getQUESTION2() {
        return QUESTION2;
    }


    /**
     * Sets the QUESTION2 value for this STAWFAC4WEBPASS.
     * 
     * @param QUESTION2
     */
    public void setQUESTION2(java.lang.String QUESTION2) {
        this.QUESTION2 = QUESTION2;
    }


    /**
     * Gets the ANSWER2 value for this STAWFAC4WEBPASS.
     * 
     * @return ANSWER2
     */
    public java.lang.String getANSWER2() {
        return ANSWER2;
    }


    /**
     * Sets the ANSWER2 value for this STAWFAC4WEBPASS.
     * 
     * @param ANSWER2
     */
    public void setANSWER2(java.lang.String ANSWER2) {
        this.ANSWER2 = ANSWER2;
    }


    /**
     * Gets the QUESTION3 value for this STAWFAC4WEBPASS.
     * 
     * @return QUESTION3
     */
    public java.lang.String getQUESTION3() {
        return QUESTION3;
    }


    /**
     * Sets the QUESTION3 value for this STAWFAC4WEBPASS.
     * 
     * @param QUESTION3
     */
    public void setQUESTION3(java.lang.String QUESTION3) {
        this.QUESTION3 = QUESTION3;
    }


    /**
     * Gets the ANSWER3 value for this STAWFAC4WEBPASS.
     * 
     * @return ANSWER3
     */
    public java.lang.String getANSWER3() {
        return ANSWER3;
    }


    /**
     * Sets the ANSWER3 value for this STAWFAC4WEBPASS.
     * 
     * @param ANSWER3
     */
    public void setANSWER3(java.lang.String ANSWER3) {
        this.ANSWER3 = ANSWER3;
    }


    /**
     * Gets the QUESTION4 value for this STAWFAC4WEBPASS.
     * 
     * @return QUESTION4
     */
    public java.lang.String getQUESTION4() {
        return QUESTION4;
    }


    /**
     * Sets the QUESTION4 value for this STAWFAC4WEBPASS.
     * 
     * @param QUESTION4
     */
    public void setQUESTION4(java.lang.String QUESTION4) {
        this.QUESTION4 = QUESTION4;
    }


    /**
     * Gets the ANSWER4 value for this STAWFAC4WEBPASS.
     * 
     * @return ANSWER4
     */
    public java.lang.String getANSWER4() {
        return ANSWER4;
    }


    /**
     * Sets the ANSWER4 value for this STAWFAC4WEBPASS.
     * 
     * @param ANSWER4
     */
    public void setANSWER4(java.lang.String ANSWER4) {
        this.ANSWER4 = ANSWER4;
    }


    /**
     * Gets the QUESTION5 value for this STAWFAC4WEBPASS.
     * 
     * @return QUESTION5
     */
    public java.lang.String getQUESTION5() {
        return QUESTION5;
    }


    /**
     * Sets the QUESTION5 value for this STAWFAC4WEBPASS.
     * 
     * @param QUESTION5
     */
    public void setQUESTION5(java.lang.String QUESTION5) {
        this.QUESTION5 = QUESTION5;
    }


    /**
     * Gets the ANSWER5 value for this STAWFAC4WEBPASS.
     * 
     * @return ANSWER5
     */
    public java.lang.String getANSWER5() {
        return ANSWER5;
    }


    /**
     * Sets the ANSWER5 value for this STAWFAC4WEBPASS.
     * 
     * @param ANSWER5
     */
    public void setANSWER5(java.lang.String ANSWER5) {
        this.ANSWER5 = ANSWER5;
    }


    /**
     * Gets the RETURNCODE value for this STAWFAC4WEBPASS.
     * 
     * @return RETURNCODE
     */
    public java.lang.String getRETURNCODE() {
        return RETURNCODE;
    }


    /**
     * Sets the RETURNCODE value for this STAWFAC4WEBPASS.
     * 
     * @param RETURNCODE
     */
    public void setRETURNCODE(java.lang.String RETURNCODE) {
        this.RETURNCODE = RETURNCODE;
    }


    /**
     * Gets the RETURNMESSAGE value for this STAWFAC4WEBPASS.
     * 
     * @return RETURNMESSAGE
     */
    public java.lang.String[] getRETURNMESSAGE() {
        return RETURNMESSAGE;
    }


    /**
     * Sets the RETURNMESSAGE value for this STAWFAC4WEBPASS.
     * 
     * @param RETURNMESSAGE
     */
    public void setRETURNMESSAGE(java.lang.String[] RETURNMESSAGE) {
        this.RETURNMESSAGE = RETURNMESSAGE;
    }


    /**
     * Gets the SUBMITTEDTIMESTAMP value for this STAWFAC4WEBPASS.
     * 
     * @return SUBMITTEDTIMESTAMP
     */
    public java.lang.String getSUBMITTEDTIMESTAMP() {
        return SUBMITTEDTIMESTAMP;
    }


    /**
     * Sets the SUBMITTEDTIMESTAMP value for this STAWFAC4WEBPASS.
     * 
     * @param SUBMITTEDTIMESTAMP
     */
    public void setSUBMITTEDTIMESTAMP(java.lang.String SUBMITTEDTIMESTAMP) {
        this.SUBMITTEDTIMESTAMP = SUBMITTEDTIMESTAMP;
    }


    /**
     * Gets the _RC value for this STAWFAC4WEBPASS.
     * 
     * @return _RC
     */
    public java.lang.String get_RC() {
        return _RC;
    }


    /**
     * Sets the _RC value for this STAWFAC4WEBPASS.
     * 
     * @param _RC
     */
    public void set_RC(java.lang.String _RC) {
        this._RC = _RC;
    }


    /**
     * Gets the _RCMSG value for this STAWFAC4WEBPASS.
     * 
     * @return _RCMSG
     */
    public java.lang.String get_RCMSG() {
        return _RCMSG;
    }


    /**
     * Sets the _RCMSG value for this STAWFAC4WEBPASS.
     * 
     * @param _RCMSG
     */
    public void set_RCMSG(java.lang.String _RCMSG) {
        this._RCMSG = _RCMSG;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof STAWFAC4WEBPASS)) return false;
        STAWFAC4WEBPASS other = (STAWFAC4WEBPASS) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.STDNTID==null && other.getSTDNTID()==null) || 
             (this.STDNTID!=null &&
              this.STDNTID.equals(other.getSTDNTID()))) &&
            ((this.STDNTSSN==null && other.getSTDNTSSN()==null) || 
             (this.STDNTSSN!=null &&
              this.STDNTSSN.equals(other.getSTDNTSSN()))) &&
            ((this.INSTID==null && other.getINSTID()==null) || 
             (this.INSTID!=null &&
              this.INSTID.equals(other.getINSTID()))) &&
            ((this.INSTTYPE==null && other.getINSTTYPE()==null) || 
             (this.INSTTYPE!=null &&
              this.INSTTYPE.equals(other.getINSTTYPE()))) &&
            ((this.RECVDDATE==null && other.getRECVDDATE()==null) || 
             (this.RECVDDATE!=null &&
              this.RECVDDATE.equals(other.getRECVDDATE()))) &&
            ((this.RECVDTIME==null && other.getRECVDTIME()==null) || 
             (this.RECVDTIME!=null &&
              this.RECVDTIME.equals(other.getRECVDTIME()))) &&
            ((this.STDNTCOMMENT==null && other.getSTDNTCOMMENT()==null) || 
             (this.STDNTCOMMENT!=null &&
              this.STDNTCOMMENT.equals(other.getSTDNTCOMMENT()))) &&
            ((this.c_COURSEINFORMATION==null && other.getC_COURSEINFORMATION()==null) || 
             (this.c_COURSEINFORMATION!=null &&
              this.c_COURSEINFORMATION.equals(other.getC_COURSEINFORMATION()))) &&
            ((this.COURSEINFORMATION==null && other.getCOURSEINFORMATION()==null) || 
             (this.COURSEINFORMATION!=null &&
              this.COURSEINFORMATION.equals(other.getCOURSEINFORMATION()))) &&
            ((this.ADMISSIONSNOTES==null && other.getADMISSIONSNOTES()==null) || 
             (this.ADMISSIONSNOTES!=null &&
              java.util.Arrays.equals(this.ADMISSIONSNOTES, other.getADMISSIONSNOTES()))) &&
            ((this.APPLIEDFORFINAID==null && other.getAPPLIEDFORFINAID()==null) || 
             (this.APPLIEDFORFINAID!=null &&
              this.APPLIEDFORFINAID.equals(other.getAPPLIEDFORFINAID()))) &&
            ((this.CONTINUENOFINAID==null && other.getCONTINUENOFINAID()==null) || 
             (this.CONTINUENOFINAID!=null &&
              this.CONTINUENOFINAID.equals(other.getCONTINUENOFINAID()))) &&
            ((this.FACTSID==null && other.getFACTSID()==null) || 
             (this.FACTSID!=null &&
              this.FACTSID.equals(other.getFACTSID()))) &&
            ((this.CONFIRMATIONNUMBER==null && other.getCONFIRMATIONNUMBER()==null) || 
             (this.CONFIRMATIONNUMBER!=null &&
              this.CONFIRMATIONNUMBER.equals(other.getCONFIRMATIONNUMBER()))) &&
            ((this.CONFIRMATIONCODE==null && other.getCONFIRMATIONCODE()==null) || 
             (this.CONFIRMATIONCODE!=null &&
              this.CONFIRMATIONCODE.equals(other.getCONFIRMATIONCODE()))) &&
            ((this.TRACKINGNUMBER==null && other.getTRACKINGNUMBER()==null) || 
             (this.TRACKINGNUMBER!=null &&
              this.TRACKINGNUMBER.equals(other.getTRACKINGNUMBER()))) &&
            ((this.REQUIREDVACCINATIONSIND==null && other.getREQUIREDVACCINATIONSIND()==null) || 
             (this.REQUIREDVACCINATIONSIND!=null &&
              this.REQUIREDVACCINATIONSIND.equals(other.getREQUIREDVACCINATIONSIND()))) &&
            ((this.ELIGIBLETOREENROLLIND==null && other.getELIGIBLETOREENROLLIND()==null) || 
             (this.ELIGIBLETOREENROLLIND!=null &&
              this.ELIGIBLETOREENROLLIND.equals(other.getELIGIBLETOREENROLLIND()))) &&
            ((this.DEGREEPROGRAMENROLLMENTIND==null && other.getDEGREEPROGRAMENROLLMENTIND()==null) || 
             (this.DEGREEPROGRAMENROLLMENTIND!=null &&
              this.DEGREEPROGRAMENROLLMENTIND.equals(other.getDEGREEPROGRAMENROLLMENTIND()))) &&
            ((this.HOMEINSTITUTIONFICECODE==null && other.getHOMEINSTITUTIONFICECODE()==null) || 
             (this.HOMEINSTITUTIONFICECODE!=null &&
              this.HOMEINSTITUTIONFICECODE.equals(other.getHOMEINSTITUTIONFICECODE()))) &&
            ((this.c_SECTION==null && other.getC_SECTION()==null) || 
             (this.c_SECTION!=null &&
              this.c_SECTION.equals(other.getC_SECTION()))) &&
            ((this.SECTION==null && other.getSECTION()==null) || 
             (this.SECTION!=null &&
              this.SECTION.equals(other.getSECTION()))) &&
            ((this.QUESTION1==null && other.getQUESTION1()==null) || 
             (this.QUESTION1!=null &&
              this.QUESTION1.equals(other.getQUESTION1()))) &&
            ((this.ANSWER1==null && other.getANSWER1()==null) || 
             (this.ANSWER1!=null &&
              this.ANSWER1.equals(other.getANSWER1()))) &&
            ((this.QUESTION2==null && other.getQUESTION2()==null) || 
             (this.QUESTION2!=null &&
              this.QUESTION2.equals(other.getQUESTION2()))) &&
            ((this.ANSWER2==null && other.getANSWER2()==null) || 
             (this.ANSWER2!=null &&
              this.ANSWER2.equals(other.getANSWER2()))) &&
            ((this.QUESTION3==null && other.getQUESTION3()==null) || 
             (this.QUESTION3!=null &&
              this.QUESTION3.equals(other.getQUESTION3()))) &&
            ((this.ANSWER3==null && other.getANSWER3()==null) || 
             (this.ANSWER3!=null &&
              this.ANSWER3.equals(other.getANSWER3()))) &&
            ((this.QUESTION4==null && other.getQUESTION4()==null) || 
             (this.QUESTION4!=null &&
              this.QUESTION4.equals(other.getQUESTION4()))) &&
            ((this.ANSWER4==null && other.getANSWER4()==null) || 
             (this.ANSWER4!=null &&
              this.ANSWER4.equals(other.getANSWER4()))) &&
            ((this.QUESTION5==null && other.getQUESTION5()==null) || 
             (this.QUESTION5!=null &&
              this.QUESTION5.equals(other.getQUESTION5()))) &&
            ((this.ANSWER5==null && other.getANSWER5()==null) || 
             (this.ANSWER5!=null &&
              this.ANSWER5.equals(other.getANSWER5()))) &&
            ((this.RETURNCODE==null && other.getRETURNCODE()==null) || 
             (this.RETURNCODE!=null &&
              this.RETURNCODE.equals(other.getRETURNCODE()))) &&
            ((this.RETURNMESSAGE==null && other.getRETURNMESSAGE()==null) || 
             (this.RETURNMESSAGE!=null &&
              java.util.Arrays.equals(this.RETURNMESSAGE, other.getRETURNMESSAGE()))) &&
            ((this.SUBMITTEDTIMESTAMP==null && other.getSUBMITTEDTIMESTAMP()==null) || 
             (this.SUBMITTEDTIMESTAMP!=null &&
              this.SUBMITTEDTIMESTAMP.equals(other.getSUBMITTEDTIMESTAMP()))) &&
            ((this._RC==null && other.get_RC()==null) || 
             (this._RC!=null &&
              this._RC.equals(other.get_RC()))) &&
            ((this._RCMSG==null && other.get_RCMSG()==null) || 
             (this._RCMSG!=null &&
              this._RCMSG.equals(other.get_RCMSG())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getSTDNTID() != null) {
            _hashCode += getSTDNTID().hashCode();
        }
        if (getSTDNTSSN() != null) {
            _hashCode += getSTDNTSSN().hashCode();
        }
        if (getINSTID() != null) {
            _hashCode += getINSTID().hashCode();
        }
        if (getINSTTYPE() != null) {
            _hashCode += getINSTTYPE().hashCode();
        }
        if (getRECVDDATE() != null) {
            _hashCode += getRECVDDATE().hashCode();
        }
        if (getRECVDTIME() != null) {
            _hashCode += getRECVDTIME().hashCode();
        }
        if (getSTDNTCOMMENT() != null) {
            _hashCode += getSTDNTCOMMENT().hashCode();
        }
        if (getC_COURSEINFORMATION() != null) {
            _hashCode += getC_COURSEINFORMATION().hashCode();
        }
        if (getCOURSEINFORMATION() != null) {
            _hashCode += getCOURSEINFORMATION().hashCode();
        }
        if (getADMISSIONSNOTES() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getADMISSIONSNOTES());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getADMISSIONSNOTES(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getAPPLIEDFORFINAID() != null) {
            _hashCode += getAPPLIEDFORFINAID().hashCode();
        }
        if (getCONTINUENOFINAID() != null) {
            _hashCode += getCONTINUENOFINAID().hashCode();
        }
        if (getFACTSID() != null) {
            _hashCode += getFACTSID().hashCode();
        }
        if (getCONFIRMATIONNUMBER() != null) {
            _hashCode += getCONFIRMATIONNUMBER().hashCode();
        }
        if (getCONFIRMATIONCODE() != null) {
            _hashCode += getCONFIRMATIONCODE().hashCode();
        }
        if (getTRACKINGNUMBER() != null) {
            _hashCode += getTRACKINGNUMBER().hashCode();
        }
        if (getREQUIREDVACCINATIONSIND() != null) {
            _hashCode += getREQUIREDVACCINATIONSIND().hashCode();
        }
        if (getELIGIBLETOREENROLLIND() != null) {
            _hashCode += getELIGIBLETOREENROLLIND().hashCode();
        }
        if (getDEGREEPROGRAMENROLLMENTIND() != null) {
            _hashCode += getDEGREEPROGRAMENROLLMENTIND().hashCode();
        }
        if (getHOMEINSTITUTIONFICECODE() != null) {
            _hashCode += getHOMEINSTITUTIONFICECODE().hashCode();
        }
        if (getC_SECTION() != null) {
            _hashCode += getC_SECTION().hashCode();
        }
        if (getSECTION() != null) {
            _hashCode += getSECTION().hashCode();
        }
        if (getQUESTION1() != null) {
            _hashCode += getQUESTION1().hashCode();
        }
        if (getANSWER1() != null) {
            _hashCode += getANSWER1().hashCode();
        }
        if (getQUESTION2() != null) {
            _hashCode += getQUESTION2().hashCode();
        }
        if (getANSWER2() != null) {
            _hashCode += getANSWER2().hashCode();
        }
        if (getQUESTION3() != null) {
            _hashCode += getQUESTION3().hashCode();
        }
        if (getANSWER3() != null) {
            _hashCode += getANSWER3().hashCode();
        }
        if (getQUESTION4() != null) {
            _hashCode += getQUESTION4().hashCode();
        }
        if (getANSWER4() != null) {
            _hashCode += getANSWER4().hashCode();
        }
        if (getQUESTION5() != null) {
            _hashCode += getQUESTION5().hashCode();
        }
        if (getANSWER5() != null) {
            _hashCode += getANSWER5().hashCode();
        }
        if (getRETURNCODE() != null) {
            _hashCode += getRETURNCODE().hashCode();
        }
        if (getRETURNMESSAGE() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getRETURNMESSAGE());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getRETURNMESSAGE(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getSUBMITTEDTIMESTAMP() != null) {
            _hashCode += getSUBMITTEDTIMESTAMP().hashCode();
        }
        if (get_RC() != null) {
            _hashCode += get_RC().hashCode();
        }
        if (get_RCMSG() != null) {
            _hashCode += get_RCMSG().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(STAWFAC4WEBPASS.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("urn:com-softwareag-entirex-rpc:ORIONWEB", ">>STAWFAC4>WEB-PASS"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("STDNTID");
        elemField.setXmlName(new javax.xml.namespace.QName("", "STDNT-ID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("STDNTSSN");
        elemField.setXmlName(new javax.xml.namespace.QName("", "STDNT-SSN"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("INSTID");
        elemField.setXmlName(new javax.xml.namespace.QName("", "INST-ID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("INSTTYPE");
        elemField.setXmlName(new javax.xml.namespace.QName("", "INST-TYPE"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("RECVDDATE");
        elemField.setXmlName(new javax.xml.namespace.QName("", "RECVD-DATE"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("RECVDTIME");
        elemField.setXmlName(new javax.xml.namespace.QName("", "RECVD-TIME"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("STDNTCOMMENT");
        elemField.setXmlName(new javax.xml.namespace.QName("", "STDNT-COMMENT"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c_COURSEINFORMATION");
        elemField.setXmlName(new javax.xml.namespace.QName("", "C_COURSE-INFORMATION"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "decimal"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("COURSEINFORMATION");
        elemField.setXmlName(new javax.xml.namespace.QName("", "COURSE-INFORMATION"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:com-softwareag-entirex-rpc:ORIONWEB", ">>>STAWFAC4>WEB-PASS>COURSE-INFORMATION"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ADMISSIONSNOTES");
        elemField.setXmlName(new javax.xml.namespace.QName("", "ADMISSIONS-NOTES"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("", "string"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("APPLIEDFORFINAID");
        elemField.setXmlName(new javax.xml.namespace.QName("", "APPLIED-FOR-FIN-AID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CONTINUENOFINAID");
        elemField.setXmlName(new javax.xml.namespace.QName("", "CONTINUE-NO-FIN-AID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("FACTSID");
        elemField.setXmlName(new javax.xml.namespace.QName("", "FACTS-ID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CONFIRMATIONNUMBER");
        elemField.setXmlName(new javax.xml.namespace.QName("", "CONFIRMATION-NUMBER"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CONFIRMATIONCODE");
        elemField.setXmlName(new javax.xml.namespace.QName("", "CONFIRMATION-CODE"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("TRACKINGNUMBER");
        elemField.setXmlName(new javax.xml.namespace.QName("", "TRACKING-NUMBER"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("REQUIREDVACCINATIONSIND");
        elemField.setXmlName(new javax.xml.namespace.QName("", "REQUIRED-VACCINATIONS-IND"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ELIGIBLETOREENROLLIND");
        elemField.setXmlName(new javax.xml.namespace.QName("", "ELIGIBLE-TO-REENROLL-IND"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("DEGREEPROGRAMENROLLMENTIND");
        elemField.setXmlName(new javax.xml.namespace.QName("", "DEGREE-PROGRAM-ENROLLMENT-IND"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("HOMEINSTITUTIONFICECODE");
        elemField.setXmlName(new javax.xml.namespace.QName("", "HOME-INSTITUTION-FICE-CODE"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c_SECTION");
        elemField.setXmlName(new javax.xml.namespace.QName("", "C_SECTION"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "decimal"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SECTION");
        elemField.setXmlName(new javax.xml.namespace.QName("", "SECTION"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:com-softwareag-entirex-rpc:ORIONWEB", ">>>STAWFAC4>WEB-PASS>SECTION"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("QUESTION1");
        elemField.setXmlName(new javax.xml.namespace.QName("", "QUESTION1"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ANSWER1");
        elemField.setXmlName(new javax.xml.namespace.QName("", "ANSWER1"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("QUESTION2");
        elemField.setXmlName(new javax.xml.namespace.QName("", "QUESTION2"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ANSWER2");
        elemField.setXmlName(new javax.xml.namespace.QName("", "ANSWER2"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("QUESTION3");
        elemField.setXmlName(new javax.xml.namespace.QName("", "QUESTION3"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ANSWER3");
        elemField.setXmlName(new javax.xml.namespace.QName("", "ANSWER3"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("QUESTION4");
        elemField.setXmlName(new javax.xml.namespace.QName("", "QUESTION4"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ANSWER4");
        elemField.setXmlName(new javax.xml.namespace.QName("", "ANSWER4"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("QUESTION5");
        elemField.setXmlName(new javax.xml.namespace.QName("", "QUESTION5"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ANSWER5");
        elemField.setXmlName(new javax.xml.namespace.QName("", "ANSWER5"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("RETURNCODE");
        elemField.setXmlName(new javax.xml.namespace.QName("", "RETURN-CODE"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("RETURNMESSAGE");
        elemField.setXmlName(new javax.xml.namespace.QName("", "RETURN-MESSAGE"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("", "string"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SUBMITTEDTIMESTAMP");
        elemField.setXmlName(new javax.xml.namespace.QName("", "SUBMITTED-TIMESTAMP"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("_RC");
        elemField.setXmlName(new javax.xml.namespace.QName("", "_RC"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("_RCMSG");
        elemField.setXmlName(new javax.xml.namespace.QName("", "_RC-MSG"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
