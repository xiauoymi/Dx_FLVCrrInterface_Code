/**
 * ORIONWEBPort.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package ORIONWEB.com_softwareag_entirex_rpc_stawfac1;

public interface ORIONWEBPort extends java.rmi.Remote {
    public ORIONWEB.com_softwareag_entirex_rpc_stawfac1.STAWFAC1ResponseWEBPASS1 STAWFAC1(ORIONWEB.com_softwareag_entirex_rpc_stawfac1.STAWFAC1WEBPASS WEBPASS) throws java.rmi.RemoteException;
}
