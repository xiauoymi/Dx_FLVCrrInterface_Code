/**
 * STAWFAC1WEBPASS.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package ORIONWEB.com_softwareag_entirex_rpc_stawfac1;

public class STAWFAC1WEBPASS  implements java.io.Serializable {
    private java.lang.String _STDNTID;

    private java.lang.String _LSTNM;

    private java.lang.String _FRSTNM;

    private java.lang.String _MDLNM;

    private java.lang.String _APPEND;

    private java.lang.String _STREET1;

    private java.lang.String _CITY;

    private java.lang.String _STATE;

    private java.lang.String _ZIPCD;

    private java.lang.String _HMPHN;

    private java.lang.String _EMAILADDR;

    private java.lang.String _CITIZENSHIP;

    private java.lang.String _IMMIGSTAT;

    private java.lang.String _SEX;

    private java.lang.String _DOB;

    private java.lang.String _RACEETHNICITY;

    private java.lang.String _HSGRADDT;

    private java.lang.String _STATEBIRTH;

    private java.lang.String _CNTRYBIRTH;

    private java.lang.String _RESCD;

    private java.lang.String _EXTRNLINST;

    private java.lang.String _ADDMISSIONRESPTYPE;

    private java.lang.String OFFENSEQUES1;

    private java.lang.String OFFENSEQUES2;

    private java.lang.String _RC;

    private java.lang.String _RCMSG;

    public STAWFAC1WEBPASS() {
    }

    public STAWFAC1WEBPASS(
           java.lang.String _STDNTID,
           java.lang.String _LSTNM,
           java.lang.String _FRSTNM,
           java.lang.String _MDLNM,
           java.lang.String _APPEND,
           java.lang.String _STREET1,
           java.lang.String _CITY,
           java.lang.String _STATE,
           java.lang.String _ZIPCD,
           java.lang.String _HMPHN,
           java.lang.String _EMAILADDR,
           java.lang.String _CITIZENSHIP,
           java.lang.String _IMMIGSTAT,
           java.lang.String _SEX,
           java.lang.String _DOB,
           java.lang.String _RACEETHNICITY,
           java.lang.String _HSGRADDT,
           java.lang.String _STATEBIRTH,
           java.lang.String _CNTRYBIRTH,
           java.lang.String _RESCD,
           java.lang.String _EXTRNLINST,
           java.lang.String _ADDMISSIONRESPTYPE,
           java.lang.String OFFENSEQUES1,
           java.lang.String OFFENSEQUES2,
           java.lang.String _RC,
           java.lang.String _RCMSG) {
           this._STDNTID = _STDNTID;
           this._LSTNM = _LSTNM;
           this._FRSTNM = _FRSTNM;
           this._MDLNM = _MDLNM;
           this._APPEND = _APPEND;
           this._STREET1 = _STREET1;
           this._CITY = _CITY;
           this._STATE = _STATE;
           this._ZIPCD = _ZIPCD;
           this._HMPHN = _HMPHN;
           this._EMAILADDR = _EMAILADDR;
           this._CITIZENSHIP = _CITIZENSHIP;
           this._IMMIGSTAT = _IMMIGSTAT;
           this._SEX = _SEX;
           this._DOB = _DOB;
           this._RACEETHNICITY = _RACEETHNICITY;
           this._HSGRADDT = _HSGRADDT;
           this._STATEBIRTH = _STATEBIRTH;
           this._CNTRYBIRTH = _CNTRYBIRTH;
           this._RESCD = _RESCD;
           this._EXTRNLINST = _EXTRNLINST;
           this._ADDMISSIONRESPTYPE = _ADDMISSIONRESPTYPE;
           this.OFFENSEQUES1 = OFFENSEQUES1;
           this.OFFENSEQUES2 = OFFENSEQUES2;
           this._RC = _RC;
           this._RCMSG = _RCMSG;
    }


    /**
     * Gets the _STDNTID value for this STAWFAC1WEBPASS.
     * 
     * @return _STDNTID
     */
    public java.lang.String get_STDNTID() {
        return _STDNTID;
    }


    /**
     * Sets the _STDNTID value for this STAWFAC1WEBPASS.
     * 
     * @param _STDNTID
     */
    public void set_STDNTID(java.lang.String _STDNTID) {
        this._STDNTID = _STDNTID;
    }


    /**
     * Gets the _LSTNM value for this STAWFAC1WEBPASS.
     * 
     * @return _LSTNM
     */
    public java.lang.String get_LSTNM() {
        return _LSTNM;
    }


    /**
     * Sets the _LSTNM value for this STAWFAC1WEBPASS.
     * 
     * @param _LSTNM
     */
    public void set_LSTNM(java.lang.String _LSTNM) {
        this._LSTNM = _LSTNM;
    }


    /**
     * Gets the _FRSTNM value for this STAWFAC1WEBPASS.
     * 
     * @return _FRSTNM
     */
    public java.lang.String get_FRSTNM() {
        return _FRSTNM;
    }


    /**
     * Sets the _FRSTNM value for this STAWFAC1WEBPASS.
     * 
     * @param _FRSTNM
     */
    public void set_FRSTNM(java.lang.String _FRSTNM) {
        this._FRSTNM = _FRSTNM;
    }


    /**
     * Gets the _MDLNM value for this STAWFAC1WEBPASS.
     * 
     * @return _MDLNM
     */
    public java.lang.String get_MDLNM() {
        return _MDLNM;
    }


    /**
     * Sets the _MDLNM value for this STAWFAC1WEBPASS.
     * 
     * @param _MDLNM
     */
    public void set_MDLNM(java.lang.String _MDLNM) {
        this._MDLNM = _MDLNM;
    }


    /**
     * Gets the _APPEND value for this STAWFAC1WEBPASS.
     * 
     * @return _APPEND
     */
    public java.lang.String get_APPEND() {
        return _APPEND;
    }


    /**
     * Sets the _APPEND value for this STAWFAC1WEBPASS.
     * 
     * @param _APPEND
     */
    public void set_APPEND(java.lang.String _APPEND) {
        this._APPEND = _APPEND;
    }


    /**
     * Gets the _STREET1 value for this STAWFAC1WEBPASS.
     * 
     * @return _STREET1
     */
    public java.lang.String get_STREET1() {
        return _STREET1;
    }


    /**
     * Sets the _STREET1 value for this STAWFAC1WEBPASS.
     * 
     * @param _STREET1
     */
    public void set_STREET1(java.lang.String _STREET1) {
        this._STREET1 = _STREET1;
    }


    /**
     * Gets the _CITY value for this STAWFAC1WEBPASS.
     * 
     * @return _CITY
     */
    public java.lang.String get_CITY() {
        return _CITY;
    }


    /**
     * Sets the _CITY value for this STAWFAC1WEBPASS.
     * 
     * @param _CITY
     */
    public void set_CITY(java.lang.String _CITY) {
        this._CITY = _CITY;
    }


    /**
     * Gets the _STATE value for this STAWFAC1WEBPASS.
     * 
     * @return _STATE
     */
    public java.lang.String get_STATE() {
        return _STATE;
    }


    /**
     * Sets the _STATE value for this STAWFAC1WEBPASS.
     * 
     * @param _STATE
     */
    public void set_STATE(java.lang.String _STATE) {
        this._STATE = _STATE;
    }


    /**
     * Gets the _ZIPCD value for this STAWFAC1WEBPASS.
     * 
     * @return _ZIPCD
     */
    public java.lang.String get_ZIPCD() {
        return _ZIPCD;
    }


    /**
     * Sets the _ZIPCD value for this STAWFAC1WEBPASS.
     * 
     * @param _ZIPCD
     */
    public void set_ZIPCD(java.lang.String _ZIPCD) {
        this._ZIPCD = _ZIPCD;
    }


    /**
     * Gets the _HMPHN value for this STAWFAC1WEBPASS.
     * 
     * @return _HMPHN
     */
    public java.lang.String get_HMPHN() {
        return _HMPHN;
    }


    /**
     * Sets the _HMPHN value for this STAWFAC1WEBPASS.
     * 
     * @param _HMPHN
     */
    public void set_HMPHN(java.lang.String _HMPHN) {
        this._HMPHN = _HMPHN;
    }


    /**
     * Gets the _EMAILADDR value for this STAWFAC1WEBPASS.
     * 
     * @return _EMAILADDR
     */
    public java.lang.String get_EMAILADDR() {
        return _EMAILADDR;
    }


    /**
     * Sets the _EMAILADDR value for this STAWFAC1WEBPASS.
     * 
     * @param _EMAILADDR
     */
    public void set_EMAILADDR(java.lang.String _EMAILADDR) {
        this._EMAILADDR = _EMAILADDR;
    }


    /**
     * Gets the _CITIZENSHIP value for this STAWFAC1WEBPASS.
     * 
     * @return _CITIZENSHIP
     */
    public java.lang.String get_CITIZENSHIP() {
        return _CITIZENSHIP;
    }


    /**
     * Sets the _CITIZENSHIP value for this STAWFAC1WEBPASS.
     * 
     * @param _CITIZENSHIP
     */
    public void set_CITIZENSHIP(java.lang.String _CITIZENSHIP) {
        this._CITIZENSHIP = _CITIZENSHIP;
    }


    /**
     * Gets the _IMMIGSTAT value for this STAWFAC1WEBPASS.
     * 
     * @return _IMMIGSTAT
     */
    public java.lang.String get_IMMIGSTAT() {
        return _IMMIGSTAT;
    }


    /**
     * Sets the _IMMIGSTAT value for this STAWFAC1WEBPASS.
     * 
     * @param _IMMIGSTAT
     */
    public void set_IMMIGSTAT(java.lang.String _IMMIGSTAT) {
        this._IMMIGSTAT = _IMMIGSTAT;
    }


    /**
     * Gets the _SEX value for this STAWFAC1WEBPASS.
     * 
     * @return _SEX
     */
    public java.lang.String get_SEX() {
        return _SEX;
    }


    /**
     * Sets the _SEX value for this STAWFAC1WEBPASS.
     * 
     * @param _SEX
     */
    public void set_SEX(java.lang.String _SEX) {
        this._SEX = _SEX;
    }


    /**
     * Gets the _DOB value for this STAWFAC1WEBPASS.
     * 
     * @return _DOB
     */
    public java.lang.String get_DOB() {
        return _DOB;
    }


    /**
     * Sets the _DOB value for this STAWFAC1WEBPASS.
     * 
     * @param _DOB
     */
    public void set_DOB(java.lang.String _DOB) {
        this._DOB = _DOB;
    }


    /**
     * Gets the _RACEETHNICITY value for this STAWFAC1WEBPASS.
     * 
     * @return _RACEETHNICITY
     */
    public java.lang.String get_RACEETHNICITY() {
        return _RACEETHNICITY;
    }


    /**
     * Sets the _RACEETHNICITY value for this STAWFAC1WEBPASS.
     * 
     * @param _RACEETHNICITY
     */
    public void set_RACEETHNICITY(java.lang.String _RACEETHNICITY) {
        this._RACEETHNICITY = _RACEETHNICITY;
    }


    /**
     * Gets the _HSGRADDT value for this STAWFAC1WEBPASS.
     * 
     * @return _HSGRADDT
     */
    public java.lang.String get_HSGRADDT() {
        return _HSGRADDT;
    }


    /**
     * Sets the _HSGRADDT value for this STAWFAC1WEBPASS.
     * 
     * @param _HSGRADDT
     */
    public void set_HSGRADDT(java.lang.String _HSGRADDT) {
        this._HSGRADDT = _HSGRADDT;
    }


    /**
     * Gets the _STATEBIRTH value for this STAWFAC1WEBPASS.
     * 
     * @return _STATEBIRTH
     */
    public java.lang.String get_STATEBIRTH() {
        return _STATEBIRTH;
    }


    /**
     * Sets the _STATEBIRTH value for this STAWFAC1WEBPASS.
     * 
     * @param _STATEBIRTH
     */
    public void set_STATEBIRTH(java.lang.String _STATEBIRTH) {
        this._STATEBIRTH = _STATEBIRTH;
    }


    /**
     * Gets the _CNTRYBIRTH value for this STAWFAC1WEBPASS.
     * 
     * @return _CNTRYBIRTH
     */
    public java.lang.String get_CNTRYBIRTH() {
        return _CNTRYBIRTH;
    }


    /**
     * Sets the _CNTRYBIRTH value for this STAWFAC1WEBPASS.
     * 
     * @param _CNTRYBIRTH
     */
    public void set_CNTRYBIRTH(java.lang.String _CNTRYBIRTH) {
        this._CNTRYBIRTH = _CNTRYBIRTH;
    }


    /**
     * Gets the _RESCD value for this STAWFAC1WEBPASS.
     * 
     * @return _RESCD
     */
    public java.lang.String get_RESCD() {
        return _RESCD;
    }


    /**
     * Sets the _RESCD value for this STAWFAC1WEBPASS.
     * 
     * @param _RESCD
     */
    public void set_RESCD(java.lang.String _RESCD) {
        this._RESCD = _RESCD;
    }


    /**
     * Gets the _EXTRNLINST value for this STAWFAC1WEBPASS.
     * 
     * @return _EXTRNLINST
     */
    public java.lang.String get_EXTRNLINST() {
        return _EXTRNLINST;
    }


    /**
     * Sets the _EXTRNLINST value for this STAWFAC1WEBPASS.
     * 
     * @param _EXTRNLINST
     */
    public void set_EXTRNLINST(java.lang.String _EXTRNLINST) {
        this._EXTRNLINST = _EXTRNLINST;
    }


    /**
     * Gets the _ADDMISSIONRESPTYPE value for this STAWFAC1WEBPASS.
     * 
     * @return _ADDMISSIONRESPTYPE
     */
    public java.lang.String get_ADDMISSIONRESPTYPE() {
        return _ADDMISSIONRESPTYPE;
    }


    /**
     * Sets the _ADDMISSIONRESPTYPE value for this STAWFAC1WEBPASS.
     * 
     * @param _ADDMISSIONRESPTYPE
     */
    public void set_ADDMISSIONRESPTYPE(java.lang.String _ADDMISSIONRESPTYPE) {
        this._ADDMISSIONRESPTYPE = _ADDMISSIONRESPTYPE;
    }


    /**
     * Gets the OFFENSEQUES1 value for this STAWFAC1WEBPASS.
     * 
     * @return OFFENSEQUES1
     */
    public java.lang.String getOFFENSEQUES1() {
        return OFFENSEQUES1;
    }


    /**
     * Sets the OFFENSEQUES1 value for this STAWFAC1WEBPASS.
     * 
     * @param OFFENSEQUES1
     */
    public void setOFFENSEQUES1(java.lang.String OFFENSEQUES1) {
        this.OFFENSEQUES1 = OFFENSEQUES1;
    }


    /**
     * Gets the OFFENSEQUES2 value for this STAWFAC1WEBPASS.
     * 
     * @return OFFENSEQUES2
     */
    public java.lang.String getOFFENSEQUES2() {
        return OFFENSEQUES2;
    }


    /**
     * Sets the OFFENSEQUES2 value for this STAWFAC1WEBPASS.
     * 
     * @param OFFENSEQUES2
     */
    public void setOFFENSEQUES2(java.lang.String OFFENSEQUES2) {
        this.OFFENSEQUES2 = OFFENSEQUES2;
    }


    /**
     * Gets the _RC value for this STAWFAC1WEBPASS.
     * 
     * @return _RC
     */
    public java.lang.String get_RC() {
        return _RC;
    }


    /**
     * Sets the _RC value for this STAWFAC1WEBPASS.
     * 
     * @param _RC
     */
    public void set_RC(java.lang.String _RC) {
        this._RC = _RC;
    }


    /**
     * Gets the _RCMSG value for this STAWFAC1WEBPASS.
     * 
     * @return _RCMSG
     */
    public java.lang.String get_RCMSG() {
        return _RCMSG;
    }


    /**
     * Sets the _RCMSG value for this STAWFAC1WEBPASS.
     * 
     * @param _RCMSG
     */
    public void set_RCMSG(java.lang.String _RCMSG) {
        this._RCMSG = _RCMSG;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof STAWFAC1WEBPASS)) return false;
        STAWFAC1WEBPASS other = (STAWFAC1WEBPASS) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this._STDNTID==null && other.get_STDNTID()==null) || 
             (this._STDNTID!=null &&
              this._STDNTID.equals(other.get_STDNTID()))) &&
            ((this._LSTNM==null && other.get_LSTNM()==null) || 
             (this._LSTNM!=null &&
              this._LSTNM.equals(other.get_LSTNM()))) &&
            ((this._FRSTNM==null && other.get_FRSTNM()==null) || 
             (this._FRSTNM!=null &&
              this._FRSTNM.equals(other.get_FRSTNM()))) &&
            ((this._MDLNM==null && other.get_MDLNM()==null) || 
             (this._MDLNM!=null &&
              this._MDLNM.equals(other.get_MDLNM()))) &&
            ((this._APPEND==null && other.get_APPEND()==null) || 
             (this._APPEND!=null &&
              this._APPEND.equals(other.get_APPEND()))) &&
            ((this._STREET1==null && other.get_STREET1()==null) || 
             (this._STREET1!=null &&
              this._STREET1.equals(other.get_STREET1()))) &&
            ((this._CITY==null && other.get_CITY()==null) || 
             (this._CITY!=null &&
              this._CITY.equals(other.get_CITY()))) &&
            ((this._STATE==null && other.get_STATE()==null) || 
             (this._STATE!=null &&
              this._STATE.equals(other.get_STATE()))) &&
            ((this._ZIPCD==null && other.get_ZIPCD()==null) || 
             (this._ZIPCD!=null &&
              this._ZIPCD.equals(other.get_ZIPCD()))) &&
            ((this._HMPHN==null && other.get_HMPHN()==null) || 
             (this._HMPHN!=null &&
              this._HMPHN.equals(other.get_HMPHN()))) &&
            ((this._EMAILADDR==null && other.get_EMAILADDR()==null) || 
             (this._EMAILADDR!=null &&
              this._EMAILADDR.equals(other.get_EMAILADDR()))) &&
            ((this._CITIZENSHIP==null && other.get_CITIZENSHIP()==null) || 
             (this._CITIZENSHIP!=null &&
              this._CITIZENSHIP.equals(other.get_CITIZENSHIP()))) &&
            ((this._IMMIGSTAT==null && other.get_IMMIGSTAT()==null) || 
             (this._IMMIGSTAT!=null &&
              this._IMMIGSTAT.equals(other.get_IMMIGSTAT()))) &&
            ((this._SEX==null && other.get_SEX()==null) || 
             (this._SEX!=null &&
              this._SEX.equals(other.get_SEX()))) &&
            ((this._DOB==null && other.get_DOB()==null) || 
             (this._DOB!=null &&
              this._DOB.equals(other.get_DOB()))) &&
            ((this._RACEETHNICITY==null && other.get_RACEETHNICITY()==null) || 
             (this._RACEETHNICITY!=null &&
              this._RACEETHNICITY.equals(other.get_RACEETHNICITY()))) &&
            ((this._HSGRADDT==null && other.get_HSGRADDT()==null) || 
             (this._HSGRADDT!=null &&
              this._HSGRADDT.equals(other.get_HSGRADDT()))) &&
            ((this._STATEBIRTH==null && other.get_STATEBIRTH()==null) || 
             (this._STATEBIRTH!=null &&
              this._STATEBIRTH.equals(other.get_STATEBIRTH()))) &&
            ((this._CNTRYBIRTH==null && other.get_CNTRYBIRTH()==null) || 
             (this._CNTRYBIRTH!=null &&
              this._CNTRYBIRTH.equals(other.get_CNTRYBIRTH()))) &&
            ((this._RESCD==null && other.get_RESCD()==null) || 
             (this._RESCD!=null &&
              this._RESCD.equals(other.get_RESCD()))) &&
            ((this._EXTRNLINST==null && other.get_EXTRNLINST()==null) || 
             (this._EXTRNLINST!=null &&
              this._EXTRNLINST.equals(other.get_EXTRNLINST()))) &&
            ((this._ADDMISSIONRESPTYPE==null && other.get_ADDMISSIONRESPTYPE()==null) || 
             (this._ADDMISSIONRESPTYPE!=null &&
              this._ADDMISSIONRESPTYPE.equals(other.get_ADDMISSIONRESPTYPE()))) &&
            ((this.OFFENSEQUES1==null && other.getOFFENSEQUES1()==null) || 
             (this.OFFENSEQUES1!=null &&
              this.OFFENSEQUES1.equals(other.getOFFENSEQUES1()))) &&
            ((this.OFFENSEQUES2==null && other.getOFFENSEQUES2()==null) || 
             (this.OFFENSEQUES2!=null &&
              this.OFFENSEQUES2.equals(other.getOFFENSEQUES2()))) &&
            ((this._RC==null && other.get_RC()==null) || 
             (this._RC!=null &&
              this._RC.equals(other.get_RC()))) &&
            ((this._RCMSG==null && other.get_RCMSG()==null) || 
             (this._RCMSG!=null &&
              this._RCMSG.equals(other.get_RCMSG())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (get_STDNTID() != null) {
            _hashCode += get_STDNTID().hashCode();
        }
        if (get_LSTNM() != null) {
            _hashCode += get_LSTNM().hashCode();
        }
        if (get_FRSTNM() != null) {
            _hashCode += get_FRSTNM().hashCode();
        }
        if (get_MDLNM() != null) {
            _hashCode += get_MDLNM().hashCode();
        }
        if (get_APPEND() != null) {
            _hashCode += get_APPEND().hashCode();
        }
        if (get_STREET1() != null) {
            _hashCode += get_STREET1().hashCode();
        }
        if (get_CITY() != null) {
            _hashCode += get_CITY().hashCode();
        }
        if (get_STATE() != null) {
            _hashCode += get_STATE().hashCode();
        }
        if (get_ZIPCD() != null) {
            _hashCode += get_ZIPCD().hashCode();
        }
        if (get_HMPHN() != null) {
            _hashCode += get_HMPHN().hashCode();
        }
        if (get_EMAILADDR() != null) {
            _hashCode += get_EMAILADDR().hashCode();
        }
        if (get_CITIZENSHIP() != null) {
            _hashCode += get_CITIZENSHIP().hashCode();
        }
        if (get_IMMIGSTAT() != null) {
            _hashCode += get_IMMIGSTAT().hashCode();
        }
        if (get_SEX() != null) {
            _hashCode += get_SEX().hashCode();
        }
        if (get_DOB() != null) {
            _hashCode += get_DOB().hashCode();
        }
        if (get_RACEETHNICITY() != null) {
            _hashCode += get_RACEETHNICITY().hashCode();
        }
        if (get_HSGRADDT() != null) {
            _hashCode += get_HSGRADDT().hashCode();
        }
        if (get_STATEBIRTH() != null) {
            _hashCode += get_STATEBIRTH().hashCode();
        }
        if (get_CNTRYBIRTH() != null) {
            _hashCode += get_CNTRYBIRTH().hashCode();
        }
        if (get_RESCD() != null) {
            _hashCode += get_RESCD().hashCode();
        }
        if (get_EXTRNLINST() != null) {
            _hashCode += get_EXTRNLINST().hashCode();
        }
        if (get_ADDMISSIONRESPTYPE() != null) {
            _hashCode += get_ADDMISSIONRESPTYPE().hashCode();
        }
        if (getOFFENSEQUES1() != null) {
            _hashCode += getOFFENSEQUES1().hashCode();
        }
        if (getOFFENSEQUES2() != null) {
            _hashCode += getOFFENSEQUES2().hashCode();
        }
        if (get_RC() != null) {
            _hashCode += get_RC().hashCode();
        }
        if (get_RCMSG() != null) {
            _hashCode += get_RCMSG().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(STAWFAC1WEBPASS.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("urn:com-softwareag-entirex-rpc:ORIONWEB", ">>STAWFAC1>WEB-PASS"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("_STDNTID");
        elemField.setXmlName(new javax.xml.namespace.QName("", "_STDNT-ID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("_LSTNM");
        elemField.setXmlName(new javax.xml.namespace.QName("", "_LST-NM"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("_FRSTNM");
        elemField.setXmlName(new javax.xml.namespace.QName("", "_FRST-NM"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("_MDLNM");
        elemField.setXmlName(new javax.xml.namespace.QName("", "_MDL-NM"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("_APPEND");
        elemField.setXmlName(new javax.xml.namespace.QName("", "_APPEND"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("_STREET1");
        elemField.setXmlName(new javax.xml.namespace.QName("", "_STREET-1"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("_CITY");
        elemField.setXmlName(new javax.xml.namespace.QName("", "_CITY"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("_STATE");
        elemField.setXmlName(new javax.xml.namespace.QName("", "_STATE"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("_ZIPCD");
        elemField.setXmlName(new javax.xml.namespace.QName("", "_ZIP-CD"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("_HMPHN");
        elemField.setXmlName(new javax.xml.namespace.QName("", "_HM-PHN"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("_EMAILADDR");
        elemField.setXmlName(new javax.xml.namespace.QName("", "_EMAIL-ADDR"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("_CITIZENSHIP");
        elemField.setXmlName(new javax.xml.namespace.QName("", "_CITIZENSHIP"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("_IMMIGSTAT");
        elemField.setXmlName(new javax.xml.namespace.QName("", "_IMMIG-STAT"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("_SEX");
        elemField.setXmlName(new javax.xml.namespace.QName("", "_SEX"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("_DOB");
        elemField.setXmlName(new javax.xml.namespace.QName("", "_DOB"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("_RACEETHNICITY");
        elemField.setXmlName(new javax.xml.namespace.QName("", "_RACE-ETHNICITY"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("_HSGRADDT");
        elemField.setXmlName(new javax.xml.namespace.QName("", "_HS-GRAD-DT"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("_STATEBIRTH");
        elemField.setXmlName(new javax.xml.namespace.QName("", "_STATE-BIRTH"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("_CNTRYBIRTH");
        elemField.setXmlName(new javax.xml.namespace.QName("", "_CNTRY-BIRTH"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("_RESCD");
        elemField.setXmlName(new javax.xml.namespace.QName("", "_RES-CD"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("_EXTRNLINST");
        elemField.setXmlName(new javax.xml.namespace.QName("", "_EXTRNL-INST"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("_ADDMISSIONRESPTYPE");
        elemField.setXmlName(new javax.xml.namespace.QName("", "_ADDMISSION-RESP-TYPE"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("OFFENSEQUES1");
        elemField.setXmlName(new javax.xml.namespace.QName("", "OFFENSE-QUES-1"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("OFFENSEQUES2");
        elemField.setXmlName(new javax.xml.namespace.QName("", "OFFENSE-QUES-2"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("_RC");
        elemField.setXmlName(new javax.xml.namespace.QName("", "_RC"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("_RCMSG");
        elemField.setXmlName(new javax.xml.namespace.QName("", "_RC-MSG"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
