/**
 * STAWFAC1ResponseWEBPASS1.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package ORIONWEB.com_softwareag_entirex_rpc_stawfac1;

public class STAWFAC1ResponseWEBPASS1  implements java.io.Serializable {
    private java.lang.String _STDNTID1;

    private java.lang.String _LSTNM1;

    private java.lang.String _FRSTNM1;

    private java.lang.String _MDLNM1;

    private java.lang.String _APPEND1;

    private java.lang.String _STREET11;

    private java.lang.String _CITY1;

    private java.lang.String _STATE1;

    private java.lang.String _ZIPCD1;

    private java.lang.String _HMPHN1;

    private java.lang.String _EMAILADDR1;

    private java.lang.String _CITIZENSHIP1;

    private java.lang.String _IMMIGSTAT1;

    private java.lang.String _SEX1;

    private java.lang.String _DOB1;

    private java.lang.String _RACEETHNICITY1;

    private java.lang.String _HSGRADDT1;

    private java.lang.String _STATEBIRTH1;

    private java.lang.String _CNTRYBIRTH1;

    private java.lang.String _RESCD1;

    private java.lang.String _EXTRNLINST1;

    private java.lang.String _ADDMISSIONRESPTYPE1;

    private java.lang.String OFFENSEQUES11;

    private java.lang.String OFFENSEQUES21;

    private java.lang.String _RC1;

    private java.lang.String _RCMSG1;

    public STAWFAC1ResponseWEBPASS1() {
    }

    public STAWFAC1ResponseWEBPASS1(
           java.lang.String _STDNTID1,
           java.lang.String _LSTNM1,
           java.lang.String _FRSTNM1,
           java.lang.String _MDLNM1,
           java.lang.String _APPEND1,
           java.lang.String _STREET11,
           java.lang.String _CITY1,
           java.lang.String _STATE1,
           java.lang.String _ZIPCD1,
           java.lang.String _HMPHN1,
           java.lang.String _EMAILADDR1,
           java.lang.String _CITIZENSHIP1,
           java.lang.String _IMMIGSTAT1,
           java.lang.String _SEX1,
           java.lang.String _DOB1,
           java.lang.String _RACEETHNICITY1,
           java.lang.String _HSGRADDT1,
           java.lang.String _STATEBIRTH1,
           java.lang.String _CNTRYBIRTH1,
           java.lang.String _RESCD1,
           java.lang.String _EXTRNLINST1,
           java.lang.String _ADDMISSIONRESPTYPE1,
           java.lang.String OFFENSEQUES11,
           java.lang.String OFFENSEQUES21,
           java.lang.String _RC1,
           java.lang.String _RCMSG1) {
           this._STDNTID1 = _STDNTID1;
           this._LSTNM1 = _LSTNM1;
           this._FRSTNM1 = _FRSTNM1;
           this._MDLNM1 = _MDLNM1;
           this._APPEND1 = _APPEND1;
           this._STREET11 = _STREET11;
           this._CITY1 = _CITY1;
           this._STATE1 = _STATE1;
           this._ZIPCD1 = _ZIPCD1;
           this._HMPHN1 = _HMPHN1;
           this._EMAILADDR1 = _EMAILADDR1;
           this._CITIZENSHIP1 = _CITIZENSHIP1;
           this._IMMIGSTAT1 = _IMMIGSTAT1;
           this._SEX1 = _SEX1;
           this._DOB1 = _DOB1;
           this._RACEETHNICITY1 = _RACEETHNICITY1;
           this._HSGRADDT1 = _HSGRADDT1;
           this._STATEBIRTH1 = _STATEBIRTH1;
           this._CNTRYBIRTH1 = _CNTRYBIRTH1;
           this._RESCD1 = _RESCD1;
           this._EXTRNLINST1 = _EXTRNLINST1;
           this._ADDMISSIONRESPTYPE1 = _ADDMISSIONRESPTYPE1;
           this.OFFENSEQUES11 = OFFENSEQUES11;
           this.OFFENSEQUES21 = OFFENSEQUES21;
           this._RC1 = _RC1;
           this._RCMSG1 = _RCMSG1;
    }


    /**
     * Gets the _STDNTID1 value for this STAWFAC1ResponseWEBPASS1.
     * 
     * @return _STDNTID1
     */
    public java.lang.String get_STDNTID1() {
        return _STDNTID1;
    }


    /**
     * Sets the _STDNTID1 value for this STAWFAC1ResponseWEBPASS1.
     * 
     * @param _STDNTID1
     */
    public void set_STDNTID1(java.lang.String _STDNTID1) {
        this._STDNTID1 = _STDNTID1;
    }


    /**
     * Gets the _LSTNM1 value for this STAWFAC1ResponseWEBPASS1.
     * 
     * @return _LSTNM1
     */
    public java.lang.String get_LSTNM1() {
        return _LSTNM1;
    }


    /**
     * Sets the _LSTNM1 value for this STAWFAC1ResponseWEBPASS1.
     * 
     * @param _LSTNM1
     */
    public void set_LSTNM1(java.lang.String _LSTNM1) {
        this._LSTNM1 = _LSTNM1;
    }


    /**
     * Gets the _FRSTNM1 value for this STAWFAC1ResponseWEBPASS1.
     * 
     * @return _FRSTNM1
     */
    public java.lang.String get_FRSTNM1() {
        return _FRSTNM1;
    }


    /**
     * Sets the _FRSTNM1 value for this STAWFAC1ResponseWEBPASS1.
     * 
     * @param _FRSTNM1
     */
    public void set_FRSTNM1(java.lang.String _FRSTNM1) {
        this._FRSTNM1 = _FRSTNM1;
    }


    /**
     * Gets the _MDLNM1 value for this STAWFAC1ResponseWEBPASS1.
     * 
     * @return _MDLNM1
     */
    public java.lang.String get_MDLNM1() {
        return _MDLNM1;
    }


    /**
     * Sets the _MDLNM1 value for this STAWFAC1ResponseWEBPASS1.
     * 
     * @param _MDLNM1
     */
    public void set_MDLNM1(java.lang.String _MDLNM1) {
        this._MDLNM1 = _MDLNM1;
    }


    /**
     * Gets the _APPEND1 value for this STAWFAC1ResponseWEBPASS1.
     * 
     * @return _APPEND1
     */
    public java.lang.String get_APPEND1() {
        return _APPEND1;
    }


    /**
     * Sets the _APPEND1 value for this STAWFAC1ResponseWEBPASS1.
     * 
     * @param _APPEND1
     */
    public void set_APPEND1(java.lang.String _APPEND1) {
        this._APPEND1 = _APPEND1;
    }


    /**
     * Gets the _STREET11 value for this STAWFAC1ResponseWEBPASS1.
     * 
     * @return _STREET11
     */
    public java.lang.String get_STREET11() {
        return _STREET11;
    }


    /**
     * Sets the _STREET11 value for this STAWFAC1ResponseWEBPASS1.
     * 
     * @param _STREET11
     */
    public void set_STREET11(java.lang.String _STREET11) {
        this._STREET11 = _STREET11;
    }


    /**
     * Gets the _CITY1 value for this STAWFAC1ResponseWEBPASS1.
     * 
     * @return _CITY1
     */
    public java.lang.String get_CITY1() {
        return _CITY1;
    }


    /**
     * Sets the _CITY1 value for this STAWFAC1ResponseWEBPASS1.
     * 
     * @param _CITY1
     */
    public void set_CITY1(java.lang.String _CITY1) {
        this._CITY1 = _CITY1;
    }


    /**
     * Gets the _STATE1 value for this STAWFAC1ResponseWEBPASS1.
     * 
     * @return _STATE1
     */
    public java.lang.String get_STATE1() {
        return _STATE1;
    }


    /**
     * Sets the _STATE1 value for this STAWFAC1ResponseWEBPASS1.
     * 
     * @param _STATE1
     */
    public void set_STATE1(java.lang.String _STATE1) {
        this._STATE1 = _STATE1;
    }


    /**
     * Gets the _ZIPCD1 value for this STAWFAC1ResponseWEBPASS1.
     * 
     * @return _ZIPCD1
     */
    public java.lang.String get_ZIPCD1() {
        return _ZIPCD1;
    }


    /**
     * Sets the _ZIPCD1 value for this STAWFAC1ResponseWEBPASS1.
     * 
     * @param _ZIPCD1
     */
    public void set_ZIPCD1(java.lang.String _ZIPCD1) {
        this._ZIPCD1 = _ZIPCD1;
    }


    /**
     * Gets the _HMPHN1 value for this STAWFAC1ResponseWEBPASS1.
     * 
     * @return _HMPHN1
     */
    public java.lang.String get_HMPHN1() {
        return _HMPHN1;
    }


    /**
     * Sets the _HMPHN1 value for this STAWFAC1ResponseWEBPASS1.
     * 
     * @param _HMPHN1
     */
    public void set_HMPHN1(java.lang.String _HMPHN1) {
        this._HMPHN1 = _HMPHN1;
    }


    /**
     * Gets the _EMAILADDR1 value for this STAWFAC1ResponseWEBPASS1.
     * 
     * @return _EMAILADDR1
     */
    public java.lang.String get_EMAILADDR1() {
        return _EMAILADDR1;
    }


    /**
     * Sets the _EMAILADDR1 value for this STAWFAC1ResponseWEBPASS1.
     * 
     * @param _EMAILADDR1
     */
    public void set_EMAILADDR1(java.lang.String _EMAILADDR1) {
        this._EMAILADDR1 = _EMAILADDR1;
    }


    /**
     * Gets the _CITIZENSHIP1 value for this STAWFAC1ResponseWEBPASS1.
     * 
     * @return _CITIZENSHIP1
     */
    public java.lang.String get_CITIZENSHIP1() {
        return _CITIZENSHIP1;
    }


    /**
     * Sets the _CITIZENSHIP1 value for this STAWFAC1ResponseWEBPASS1.
     * 
     * @param _CITIZENSHIP1
     */
    public void set_CITIZENSHIP1(java.lang.String _CITIZENSHIP1) {
        this._CITIZENSHIP1 = _CITIZENSHIP1;
    }


    /**
     * Gets the _IMMIGSTAT1 value for this STAWFAC1ResponseWEBPASS1.
     * 
     * @return _IMMIGSTAT1
     */
    public java.lang.String get_IMMIGSTAT1() {
        return _IMMIGSTAT1;
    }


    /**
     * Sets the _IMMIGSTAT1 value for this STAWFAC1ResponseWEBPASS1.
     * 
     * @param _IMMIGSTAT1
     */
    public void set_IMMIGSTAT1(java.lang.String _IMMIGSTAT1) {
        this._IMMIGSTAT1 = _IMMIGSTAT1;
    }


    /**
     * Gets the _SEX1 value for this STAWFAC1ResponseWEBPASS1.
     * 
     * @return _SEX1
     */
    public java.lang.String get_SEX1() {
        return _SEX1;
    }


    /**
     * Sets the _SEX1 value for this STAWFAC1ResponseWEBPASS1.
     * 
     * @param _SEX1
     */
    public void set_SEX1(java.lang.String _SEX1) {
        this._SEX1 = _SEX1;
    }


    /**
     * Gets the _DOB1 value for this STAWFAC1ResponseWEBPASS1.
     * 
     * @return _DOB1
     */
    public java.lang.String get_DOB1() {
        return _DOB1;
    }


    /**
     * Sets the _DOB1 value for this STAWFAC1ResponseWEBPASS1.
     * 
     * @param _DOB1
     */
    public void set_DOB1(java.lang.String _DOB1) {
        this._DOB1 = _DOB1;
    }


    /**
     * Gets the _RACEETHNICITY1 value for this STAWFAC1ResponseWEBPASS1.
     * 
     * @return _RACEETHNICITY1
     */
    public java.lang.String get_RACEETHNICITY1() {
        return _RACEETHNICITY1;
    }


    /**
     * Sets the _RACEETHNICITY1 value for this STAWFAC1ResponseWEBPASS1.
     * 
     * @param _RACEETHNICITY1
     */
    public void set_RACEETHNICITY1(java.lang.String _RACEETHNICITY1) {
        this._RACEETHNICITY1 = _RACEETHNICITY1;
    }


    /**
     * Gets the _HSGRADDT1 value for this STAWFAC1ResponseWEBPASS1.
     * 
     * @return _HSGRADDT1
     */
    public java.lang.String get_HSGRADDT1() {
        return _HSGRADDT1;
    }


    /**
     * Sets the _HSGRADDT1 value for this STAWFAC1ResponseWEBPASS1.
     * 
     * @param _HSGRADDT1
     */
    public void set_HSGRADDT1(java.lang.String _HSGRADDT1) {
        this._HSGRADDT1 = _HSGRADDT1;
    }


    /**
     * Gets the _STATEBIRTH1 value for this STAWFAC1ResponseWEBPASS1.
     * 
     * @return _STATEBIRTH1
     */
    public java.lang.String get_STATEBIRTH1() {
        return _STATEBIRTH1;
    }


    /**
     * Sets the _STATEBIRTH1 value for this STAWFAC1ResponseWEBPASS1.
     * 
     * @param _STATEBIRTH1
     */
    public void set_STATEBIRTH1(java.lang.String _STATEBIRTH1) {
        this._STATEBIRTH1 = _STATEBIRTH1;
    }


    /**
     * Gets the _CNTRYBIRTH1 value for this STAWFAC1ResponseWEBPASS1.
     * 
     * @return _CNTRYBIRTH1
     */
    public java.lang.String get_CNTRYBIRTH1() {
        return _CNTRYBIRTH1;
    }


    /**
     * Sets the _CNTRYBIRTH1 value for this STAWFAC1ResponseWEBPASS1.
     * 
     * @param _CNTRYBIRTH1
     */
    public void set_CNTRYBIRTH1(java.lang.String _CNTRYBIRTH1) {
        this._CNTRYBIRTH1 = _CNTRYBIRTH1;
    }


    /**
     * Gets the _RESCD1 value for this STAWFAC1ResponseWEBPASS1.
     * 
     * @return _RESCD1
     */
    public java.lang.String get_RESCD1() {
        return _RESCD1;
    }


    /**
     * Sets the _RESCD1 value for this STAWFAC1ResponseWEBPASS1.
     * 
     * @param _RESCD1
     */
    public void set_RESCD1(java.lang.String _RESCD1) {
        this._RESCD1 = _RESCD1;
    }


    /**
     * Gets the _EXTRNLINST1 value for this STAWFAC1ResponseWEBPASS1.
     * 
     * @return _EXTRNLINST1
     */
    public java.lang.String get_EXTRNLINST1() {
        return _EXTRNLINST1;
    }


    /**
     * Sets the _EXTRNLINST1 value for this STAWFAC1ResponseWEBPASS1.
     * 
     * @param _EXTRNLINST1
     */
    public void set_EXTRNLINST1(java.lang.String _EXTRNLINST1) {
        this._EXTRNLINST1 = _EXTRNLINST1;
    }


    /**
     * Gets the _ADDMISSIONRESPTYPE1 value for this STAWFAC1ResponseWEBPASS1.
     * 
     * @return _ADDMISSIONRESPTYPE1
     */
    public java.lang.String get_ADDMISSIONRESPTYPE1() {
        return _ADDMISSIONRESPTYPE1;
    }


    /**
     * Sets the _ADDMISSIONRESPTYPE1 value for this STAWFAC1ResponseWEBPASS1.
     * 
     * @param _ADDMISSIONRESPTYPE1
     */
    public void set_ADDMISSIONRESPTYPE1(java.lang.String _ADDMISSIONRESPTYPE1) {
        this._ADDMISSIONRESPTYPE1 = _ADDMISSIONRESPTYPE1;
    }


    /**
     * Gets the OFFENSEQUES11 value for this STAWFAC1ResponseWEBPASS1.
     * 
     * @return OFFENSEQUES11
     */
    public java.lang.String getOFFENSEQUES11() {
        return OFFENSEQUES11;
    }


    /**
     * Sets the OFFENSEQUES11 value for this STAWFAC1ResponseWEBPASS1.
     * 
     * @param OFFENSEQUES11
     */
    public void setOFFENSEQUES11(java.lang.String OFFENSEQUES11) {
        this.OFFENSEQUES11 = OFFENSEQUES11;
    }


    /**
     * Gets the OFFENSEQUES21 value for this STAWFAC1ResponseWEBPASS1.
     * 
     * @return OFFENSEQUES21
     */
    public java.lang.String getOFFENSEQUES21() {
        return OFFENSEQUES21;
    }


    /**
     * Sets the OFFENSEQUES21 value for this STAWFAC1ResponseWEBPASS1.
     * 
     * @param OFFENSEQUES21
     */
    public void setOFFENSEQUES21(java.lang.String OFFENSEQUES21) {
        this.OFFENSEQUES21 = OFFENSEQUES21;
    }


    /**
     * Gets the _RC1 value for this STAWFAC1ResponseWEBPASS1.
     * 
     * @return _RC1
     */
    public java.lang.String get_RC1() {
        return _RC1;
    }


    /**
     * Sets the _RC1 value for this STAWFAC1ResponseWEBPASS1.
     * 
     * @param _RC1
     */
    public void set_RC1(java.lang.String _RC1) {
        this._RC1 = _RC1;
    }


    /**
     * Gets the _RCMSG1 value for this STAWFAC1ResponseWEBPASS1.
     * 
     * @return _RCMSG1
     */
    public java.lang.String get_RCMSG1() {
        return _RCMSG1;
    }


    /**
     * Sets the _RCMSG1 value for this STAWFAC1ResponseWEBPASS1.
     * 
     * @param _RCMSG1
     */
    public void set_RCMSG1(java.lang.String _RCMSG1) {
        this._RCMSG1 = _RCMSG1;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof STAWFAC1ResponseWEBPASS1)) return false;
        STAWFAC1ResponseWEBPASS1 other = (STAWFAC1ResponseWEBPASS1) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this._STDNTID1==null && other.get_STDNTID1()==null) || 
             (this._STDNTID1!=null &&
              this._STDNTID1.equals(other.get_STDNTID1()))) &&
            ((this._LSTNM1==null && other.get_LSTNM1()==null) || 
             (this._LSTNM1!=null &&
              this._LSTNM1.equals(other.get_LSTNM1()))) &&
            ((this._FRSTNM1==null && other.get_FRSTNM1()==null) || 
             (this._FRSTNM1!=null &&
              this._FRSTNM1.equals(other.get_FRSTNM1()))) &&
            ((this._MDLNM1==null && other.get_MDLNM1()==null) || 
             (this._MDLNM1!=null &&
              this._MDLNM1.equals(other.get_MDLNM1()))) &&
            ((this._APPEND1==null && other.get_APPEND1()==null) || 
             (this._APPEND1!=null &&
              this._APPEND1.equals(other.get_APPEND1()))) &&
            ((this._STREET11==null && other.get_STREET11()==null) || 
             (this._STREET11!=null &&
              this._STREET11.equals(other.get_STREET11()))) &&
            ((this._CITY1==null && other.get_CITY1()==null) || 
             (this._CITY1!=null &&
              this._CITY1.equals(other.get_CITY1()))) &&
            ((this._STATE1==null && other.get_STATE1()==null) || 
             (this._STATE1!=null &&
              this._STATE1.equals(other.get_STATE1()))) &&
            ((this._ZIPCD1==null && other.get_ZIPCD1()==null) || 
             (this._ZIPCD1!=null &&
              this._ZIPCD1.equals(other.get_ZIPCD1()))) &&
            ((this._HMPHN1==null && other.get_HMPHN1()==null) || 
             (this._HMPHN1!=null &&
              this._HMPHN1.equals(other.get_HMPHN1()))) &&
            ((this._EMAILADDR1==null && other.get_EMAILADDR1()==null) || 
             (this._EMAILADDR1!=null &&
              this._EMAILADDR1.equals(other.get_EMAILADDR1()))) &&
            ((this._CITIZENSHIP1==null && other.get_CITIZENSHIP1()==null) || 
             (this._CITIZENSHIP1!=null &&
              this._CITIZENSHIP1.equals(other.get_CITIZENSHIP1()))) &&
            ((this._IMMIGSTAT1==null && other.get_IMMIGSTAT1()==null) || 
             (this._IMMIGSTAT1!=null &&
              this._IMMIGSTAT1.equals(other.get_IMMIGSTAT1()))) &&
            ((this._SEX1==null && other.get_SEX1()==null) || 
             (this._SEX1!=null &&
              this._SEX1.equals(other.get_SEX1()))) &&
            ((this._DOB1==null && other.get_DOB1()==null) || 
             (this._DOB1!=null &&
              this._DOB1.equals(other.get_DOB1()))) &&
            ((this._RACEETHNICITY1==null && other.get_RACEETHNICITY1()==null) || 
             (this._RACEETHNICITY1!=null &&
              this._RACEETHNICITY1.equals(other.get_RACEETHNICITY1()))) &&
            ((this._HSGRADDT1==null && other.get_HSGRADDT1()==null) || 
             (this._HSGRADDT1!=null &&
              this._HSGRADDT1.equals(other.get_HSGRADDT1()))) &&
            ((this._STATEBIRTH1==null && other.get_STATEBIRTH1()==null) || 
             (this._STATEBIRTH1!=null &&
              this._STATEBIRTH1.equals(other.get_STATEBIRTH1()))) &&
            ((this._CNTRYBIRTH1==null && other.get_CNTRYBIRTH1()==null) || 
             (this._CNTRYBIRTH1!=null &&
              this._CNTRYBIRTH1.equals(other.get_CNTRYBIRTH1()))) &&
            ((this._RESCD1==null && other.get_RESCD1()==null) || 
             (this._RESCD1!=null &&
              this._RESCD1.equals(other.get_RESCD1()))) &&
            ((this._EXTRNLINST1==null && other.get_EXTRNLINST1()==null) || 
             (this._EXTRNLINST1!=null &&
              this._EXTRNLINST1.equals(other.get_EXTRNLINST1()))) &&
            ((this._ADDMISSIONRESPTYPE1==null && other.get_ADDMISSIONRESPTYPE1()==null) || 
             (this._ADDMISSIONRESPTYPE1!=null &&
              this._ADDMISSIONRESPTYPE1.equals(other.get_ADDMISSIONRESPTYPE1()))) &&
            ((this.OFFENSEQUES11==null && other.getOFFENSEQUES11()==null) || 
             (this.OFFENSEQUES11!=null &&
              this.OFFENSEQUES11.equals(other.getOFFENSEQUES11()))) &&
            ((this.OFFENSEQUES21==null && other.getOFFENSEQUES21()==null) || 
             (this.OFFENSEQUES21!=null &&
              this.OFFENSEQUES21.equals(other.getOFFENSEQUES21()))) &&
            ((this._RC1==null && other.get_RC1()==null) || 
             (this._RC1!=null &&
              this._RC1.equals(other.get_RC1()))) &&
            ((this._RCMSG1==null && other.get_RCMSG1()==null) || 
             (this._RCMSG1!=null &&
              this._RCMSG1.equals(other.get_RCMSG1())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (get_STDNTID1() != null) {
            _hashCode += get_STDNTID1().hashCode();
        }
        if (get_LSTNM1() != null) {
            _hashCode += get_LSTNM1().hashCode();
        }
        if (get_FRSTNM1() != null) {
            _hashCode += get_FRSTNM1().hashCode();
        }
        if (get_MDLNM1() != null) {
            _hashCode += get_MDLNM1().hashCode();
        }
        if (get_APPEND1() != null) {
            _hashCode += get_APPEND1().hashCode();
        }
        if (get_STREET11() != null) {
            _hashCode += get_STREET11().hashCode();
        }
        if (get_CITY1() != null) {
            _hashCode += get_CITY1().hashCode();
        }
        if (get_STATE1() != null) {
            _hashCode += get_STATE1().hashCode();
        }
        if (get_ZIPCD1() != null) {
            _hashCode += get_ZIPCD1().hashCode();
        }
        if (get_HMPHN1() != null) {
            _hashCode += get_HMPHN1().hashCode();
        }
        if (get_EMAILADDR1() != null) {
            _hashCode += get_EMAILADDR1().hashCode();
        }
        if (get_CITIZENSHIP1() != null) {
            _hashCode += get_CITIZENSHIP1().hashCode();
        }
        if (get_IMMIGSTAT1() != null) {
            _hashCode += get_IMMIGSTAT1().hashCode();
        }
        if (get_SEX1() != null) {
            _hashCode += get_SEX1().hashCode();
        }
        if (get_DOB1() != null) {
            _hashCode += get_DOB1().hashCode();
        }
        if (get_RACEETHNICITY1() != null) {
            _hashCode += get_RACEETHNICITY1().hashCode();
        }
        if (get_HSGRADDT1() != null) {
            _hashCode += get_HSGRADDT1().hashCode();
        }
        if (get_STATEBIRTH1() != null) {
            _hashCode += get_STATEBIRTH1().hashCode();
        }
        if (get_CNTRYBIRTH1() != null) {
            _hashCode += get_CNTRYBIRTH1().hashCode();
        }
        if (get_RESCD1() != null) {
            _hashCode += get_RESCD1().hashCode();
        }
        if (get_EXTRNLINST1() != null) {
            _hashCode += get_EXTRNLINST1().hashCode();
        }
        if (get_ADDMISSIONRESPTYPE1() != null) {
            _hashCode += get_ADDMISSIONRESPTYPE1().hashCode();
        }
        if (getOFFENSEQUES11() != null) {
            _hashCode += getOFFENSEQUES11().hashCode();
        }
        if (getOFFENSEQUES21() != null) {
            _hashCode += getOFFENSEQUES21().hashCode();
        }
        if (get_RC1() != null) {
            _hashCode += get_RC1().hashCode();
        }
        if (get_RCMSG1() != null) {
            _hashCode += get_RCMSG1().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(STAWFAC1ResponseWEBPASS1.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("urn:com-softwareag-entirex-rpc:ORIONWEB", ">>STAWFAC1Response>WEB-PASS1"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("_STDNTID1");
        elemField.setXmlName(new javax.xml.namespace.QName("", "_STDNT-ID1"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("_LSTNM1");
        elemField.setXmlName(new javax.xml.namespace.QName("", "_LST-NM1"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("_FRSTNM1");
        elemField.setXmlName(new javax.xml.namespace.QName("", "_FRST-NM1"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("_MDLNM1");
        elemField.setXmlName(new javax.xml.namespace.QName("", "_MDL-NM1"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("_APPEND1");
        elemField.setXmlName(new javax.xml.namespace.QName("", "_APPEND1"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("_STREET11");
        elemField.setXmlName(new javax.xml.namespace.QName("", "_STREET-11"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("_CITY1");
        elemField.setXmlName(new javax.xml.namespace.QName("", "_CITY1"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("_STATE1");
        elemField.setXmlName(new javax.xml.namespace.QName("", "_STATE1"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("_ZIPCD1");
        elemField.setXmlName(new javax.xml.namespace.QName("", "_ZIP-CD1"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("_HMPHN1");
        elemField.setXmlName(new javax.xml.namespace.QName("", "_HM-PHN1"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("_EMAILADDR1");
        elemField.setXmlName(new javax.xml.namespace.QName("", "_EMAIL-ADDR1"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("_CITIZENSHIP1");
        elemField.setXmlName(new javax.xml.namespace.QName("", "_CITIZENSHIP1"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("_IMMIGSTAT1");
        elemField.setXmlName(new javax.xml.namespace.QName("", "_IMMIG-STAT1"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("_SEX1");
        elemField.setXmlName(new javax.xml.namespace.QName("", "_SEX1"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("_DOB1");
        elemField.setXmlName(new javax.xml.namespace.QName("", "_DOB1"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("_RACEETHNICITY1");
        elemField.setXmlName(new javax.xml.namespace.QName("", "_RACE-ETHNICITY1"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("_HSGRADDT1");
        elemField.setXmlName(new javax.xml.namespace.QName("", "_HS-GRAD-DT1"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("_STATEBIRTH1");
        elemField.setXmlName(new javax.xml.namespace.QName("", "_STATE-BIRTH1"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("_CNTRYBIRTH1");
        elemField.setXmlName(new javax.xml.namespace.QName("", "_CNTRY-BIRTH1"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("_RESCD1");
        elemField.setXmlName(new javax.xml.namespace.QName("", "_RES-CD1"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("_EXTRNLINST1");
        elemField.setXmlName(new javax.xml.namespace.QName("", "_EXTRNL-INST1"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("_ADDMISSIONRESPTYPE1");
        elemField.setXmlName(new javax.xml.namespace.QName("", "_ADDMISSION-RESP-TYPE1"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("OFFENSEQUES11");
        elemField.setXmlName(new javax.xml.namespace.QName("", "OFFENSE-QUES-11"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("OFFENSEQUES21");
        elemField.setXmlName(new javax.xml.namespace.QName("", "OFFENSE-QUES-21"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("_RC1");
        elemField.setXmlName(new javax.xml.namespace.QName("", "_RC1"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("_RCMSG1");
        elemField.setXmlName(new javax.xml.namespace.QName("", "_RC-MSG1"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
