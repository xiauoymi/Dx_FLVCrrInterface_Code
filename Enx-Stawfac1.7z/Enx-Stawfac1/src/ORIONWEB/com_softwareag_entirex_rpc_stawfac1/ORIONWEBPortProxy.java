package ORIONWEB.com_softwareag_entirex_rpc_stawfac1;

public class ORIONWEBPortProxy implements ORIONWEB.com_softwareag_entirex_rpc_stawfac1.ORIONWEBPort {
  private String _endpoint = null;
  private ORIONWEB.com_softwareag_entirex_rpc_stawfac1.ORIONWEBPort oRIONWEBPort = null;
  
  public ORIONWEBPortProxy() {
    _initORIONWEBPortProxy();
  }
  
  public ORIONWEBPortProxy(String endpoint) {
    _endpoint = endpoint;
    _initORIONWEBPortProxy();
  }
  
  private void _initORIONWEBPortProxy() {
    try {
      oRIONWEBPort = (new ORIONWEB.com_softwareag_entirex_rpc_stawfac1.Stawfac1Locator()).getORIONWEBPort();
      if (oRIONWEBPort != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)oRIONWEBPort)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)oRIONWEBPort)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (oRIONWEBPort != null)
      ((javax.xml.rpc.Stub)oRIONWEBPort)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public ORIONWEB.com_softwareag_entirex_rpc_stawfac1.ORIONWEBPort getORIONWEBPort() {
    if (oRIONWEBPort == null)
      _initORIONWEBPortProxy();
    return oRIONWEBPort;
  }
  
  public ORIONWEB.com_softwareag_entirex_rpc_stawfac1.STAWFAC1ResponseWEBPASS1 STAWFAC1(ORIONWEB.com_softwareag_entirex_rpc_stawfac1.STAWFAC1WEBPASS WEBPASS) throws java.rmi.RemoteException{
    if (oRIONWEBPort == null)
      _initORIONWEBPortProxy();
    return oRIONWEBPort.STAWFAC1(WEBPASS);
  }
  
  
}