/**
 * Stawfac1.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package ORIONWEB.com_softwareag_entirex_rpc_stawfac1;

public interface Stawfac1 extends javax.xml.rpc.Service {
    public java.lang.String getORIONWEBPortAddress();

    public ORIONWEB.com_softwareag_entirex_rpc_stawfac1.ORIONWEBPort getORIONWEBPort() throws javax.xml.rpc.ServiceException;

    public ORIONWEB.com_softwareag_entirex_rpc_stawfac1.ORIONWEBPort getORIONWEBPort(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
