package edu.fccj.student.utils;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import edu.fccj.student.stawfac1.config.config;

public class DBWrite {

	public Connection con;
	
	public void getConnection() throws ClassNotFoundException, SQLException{
		Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
		String url = config.FLVC_DB;
	
		con = DriverManager.getConnection(url);
		
	}//public void getConnection() throws ClassNotFoundException, SQLException{
	
	public void closeConn()
	{
		try {
			if (con != null) {
				con.close();
			}
		}catch (SQLException e) {
			
		}
	}
	
	
	public void AddTransactionToDb(String firstName, String lastName, String dataXML) throws SQLException{
		
		if(con == null) {
			try {
				getConnection();
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				con = null;
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				con = null;
			}
			
			if(con != null) {
				CallableStatement cs = con.prepareCall("{call spInsertFLVC(?,?,?)}");
				cs.setString(1, firstName);
				cs.setString(2, lastName);
				cs.setString(3, dataXML);
				cs.executeUpdate();
			}
		}
		
		
	}//public void AddTransactionToDb(String firstName, String LastName, String dataXML){
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//stored procedure spInsertFLVC
	}

}
