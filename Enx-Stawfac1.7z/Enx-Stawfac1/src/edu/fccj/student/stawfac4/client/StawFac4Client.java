package edu.fccj.student.stawfac4.client;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Calendar;


import ORIONWEB.com_softwareag_entirex_rpc_stawfac4.ORIONWEBPort;
import ORIONWEB.com_softwareag_entirex_rpc_stawfac4.STAWFAC4ResponseWEBPASS1;
import ORIONWEB.com_softwareag_entirex_rpc_stawfac4.STAWFAC4ResponseWEBPASS1COURSEINFORMATION1;
import ORIONWEB.com_softwareag_entirex_rpc_stawfac4.STAWFAC4WEBPASS;
import ORIONWEB.com_softwareag_entirex_rpc_stawfac4.STAWFAC4WEBPASSCOURSEINFORMATION;
import ORIONWEB.com_softwareag_entirex_rpc_stawfac4.STAWFAC4WEBPASSSECTION;
import ORIONWEB.com_softwareag_entirex_rpc_stawfac4.Stawfac4Locator;
import edu.fccj.student.stawfac1.bean.Course;
import edu.fccj.student.stawfac1.bean.StawFac1Bean;
import edu.fccj.student.stawfac1.bean.TF_SECTION;
import java.sql.Timestamp;;

public class StawFac4Client {

	
	public String[] convertData(int arLength, Course[] courses,int id) {
		String[] rtn = new String[arLength];
		
		for(int counter = 0; counter < arLength; counter++) {
			
			switch (id) {
			case 1 :
				rtn[counter] = courses[counter].getCrsnbr();
				break;
			case 2:
				rtn[counter] = courses[counter].getTitle();
				break;
			case 3:
				rtn[counter] = courses[counter].getCredhrs();
				break;
			case 4:
				rtn[counter] = courses[counter].getCourse_use();
				break;
			case 5:
				rtn[counter] = courses[counter].getCourse_equivalent();
				break;
			case 6:
				rtn[counter] = courses[counter].getApproved();
				break;
			case 7:
				rtn[counter] = courses[counter].getDistance_learning();
				break;
			case 8:
				rtn[counter] = courses[counter].getFinancial_Aid_Eligible();
				break;
			
			}
			
			
		}
		
		
		return rtn;
	}
	
	public String[] convertTFData(int arLength, TF_SECTION[] section,int id) {
		String[] rtn = new String[arLength];
		
		for(int counter = 0; counter < arLength; counter++) {
			
			switch (id) {
			case 1 :
				rtn[counter] = section[counter].getInstitution();
				break;
			case 2:
				rtn[counter] = section[counter].getTitle();
				break;
			case 3:
				rtn[counter] = section[counter].getRole();
				break;
			case 4:
				rtn[counter] = section[counter].getComment();
				break;
			case 5:
				rtn[counter] = section[counter].getFullname();
				break;
			case 6:
				rtn[counter] = section[counter].getReal();
				break;
			case 7:
				rtn[counter] = section[counter].getSigned_state();
				break;
			case 8:
				rtn[counter] = section[counter].getSigned_timestamp();
				break;
			case 9:
				rtn[counter] = section[counter].getUser_name();
				break;
			
			
			}
			
			
		}
		
		
		return rtn;
	}
	
	
	public void ExecuteStawfac4(StawFac1Bean bean) {
		Stawfac4Locator server = new Stawfac4Locator();
		
		ORIONWEBPort proxy;
		
		STAWFAC4WEBPASS webpass = new STAWFAC4WEBPASS();
		STAWFAC4ResponseWEBPASS1 out = new STAWFAC4ResponseWEBPASS1();
		STAWFAC4WEBPASSCOURSEINFORMATION courseInfo = new STAWFAC4WEBPASSCOURSEINFORMATION();
		STAWFAC4WEBPASSSECTION tfSection = new STAWFAC4WEBPASSSECTION();
		
		StawFac4Client service = new StawFac4Client();
		webpass.setSTDNTID("");
		webpass.setSTDNTSSN(bean.getSTDNT_ID());
		webpass.setINSTID(bean.getEXTRNL_INST());
		webpass.setINSTTYPE(bean.getEXTRNL_INST());
		Calendar currentDate = Calendar.getInstance();
		SimpleDateFormat formatter = new SimpleDateFormat("yyyymmdd");
		String dateNow = formatter.format(currentDate.getTime());
		SimpleDateFormat formatter2 = new SimpleDateFormat("HHmmss");
		String timeNow = formatter2.format(currentDate.getTime());
		webpass.setRECVDDATE(dateNow);
		webpass.setRECVDTIME(timeNow);
		webpass.setSTDNTCOMMENT(bean.getStudComment());
		webpass.set_RC("");
		webpass.set_RCMSG("");
		webpass.setRETURNCODE("");
		String[] tmpmsg = new String[1];
		tmpmsg[0] = "";
		webpass.setRETURNMESSAGE(tmpmsg);
		java.util.Date date = new java.util.Date();
		
		
		webpass.setSUBMITTEDTIMESTAMP(new Timestamp(date.getTime()) + "");
		courseInfo.setCRSID(service.convertData(bean.getCourse().length , bean.getCourse(), 1));
		courseInfo.setCRSTITLE(service.convertData(bean.getCourse().length , bean.getCourse(), 2));
		
		BigDecimal[] tmpHrs = new BigDecimal[bean.getCourse().length];
		String[] origHrs = service.convertData(bean.getCourse().length , bean.getCourse(), 3);
		
		try{
			for(int counter = 0; counter < tmpHrs.length; counter++) {
				tmpHrs[counter] = new BigDecimal("0" + origHrs[counter]);
			}
		}catch(Exception ex) {
			tmpHrs = new BigDecimal[bean.getCourse().length];
			for(int counter = 0; counter < tmpHrs.length; counter++) {
				tmpHrs[counter] = new BigDecimal("0");
			}
		}
		
		
		courseInfo.setCRSCREDITHOURS(tmpHrs);
		courseInfo.setCRSUSES(service.convertData(bean.getCourse().length , bean.getCourse(), 4));
		courseInfo.setEQUIVALENT(service.convertData(bean.getCourse().length , bean.getCourse(), 5));
		courseInfo.setCRSAPPROVAL(service.convertData(bean.getCourse().length , bean.getCourse(), 6));
		courseInfo.setCRSDISTANCELEARNING(service.convertData(bean.getCourse().length , bean.getCourse(), 7));
		courseInfo.setCRSFAELIGIBILITY(service.convertData(bean.getCourse().length , bean.getCourse(), 8));
		
		webpass.setCOURSEINFORMATION(courseInfo);
		
		String[] tmpStr = new String[5];
		for(int counter = 0; counter < tmpStr.length; counter++) {
			tmpStr[counter] = new String("");
		}
		
		webpass.setADMISSIONSNOTES(tmpStr);
		webpass.setAPPLIEDFORFINAID("");
		webpass.setCONTINUENOFINAID("");
		webpass.setFACTSID(bean.getFactsID());
		webpass.setCONFIRMATIONNUMBER(bean.getConfNum());
		webpass.setCONFIRMATIONCODE(bean.getConfCode());
		webpass.setTRACKINGNUMBER(bean.getTrackNum());
		webpass.setREQUIREDVACCINATIONSIND(bean.getHas_required_vaccinations());
		webpass.setELIGIBLETOREENROLLIND(bean.getIs_Eligible_to_Reenroll());
		webpass.setDEGREEPROGRAMENROLLMENTIND(bean.getIs_Enrolled_In_Degree_Program());
		webpass.setHOMEINSTITUTIONFICECODE(bean.getEXTRNL_INST());
		
		
		tfSection.setINSTITUTIONTYPEHOMEHOST(service.convertTFData(bean.getSection().length, bean.getSection(), 1));
		tfSection.setCOMMENT(service.convertTFData(bean.getSection().length, bean.getSection(), 4));
		tfSection.setSECTIONTITLE(service.convertTFData(bean.getSection().length, bean.getSection(), 2));
		tfSection.setAGENTSIGNATUREDATE(service.convertTFData(bean.getSection().length, bean.getSection(), 8));
		tfSection.setSECTIONROLE(service.convertTFData(bean.getSection().length, bean.getSection(), 3));
		tfSection.setSECTIONSTATUS(service.convertTFData(bean.getSection().length, bean.getSection(), 7));
		tfSection.setFULLNAME(service.convertTFData(bean.getSection().length, bean.getSection(), 5));
		tfSection.setAGENTID(service.convertTFData(bean.getSection().length, bean.getSection(), 9));
		tfSection.setINSTITUTIONWORKFLOWLEVEL(service.convertTFData(bean.getSection().length, bean.getSection(), 6));
		webpass.setSECTION(tfSection);
		
		webpass.setANSWER1(bean.getAdmission_Answers()[0]);
		webpass.setANSWER2(bean.getAdmission_Answers()[1]);
		webpass.setANSWER3(bean.getAdmission_Answers()[2]);
		webpass.setANSWER4(bean.getAdmission_Answers()[3]);
		webpass.setANSWER5(bean.getAdmission_Answers()[4]);
		
		webpass.setQUESTION1(bean.getAdmission_Questions()[0]);
		webpass.setQUESTION2(bean.getAdmission_Questions()[1]);
		webpass.setQUESTION3(bean.getAdmission_Questions()[2]);
		webpass.setQUESTION4(bean.getAdmission_Questions()[3]);
		webpass.setQUESTION5(bean.getAdmission_Questions()[4]);
		
		
		try{
			proxy = server.getORIONWEBPort();
			out = proxy.STAWFAC4(webpass);
			bean.setERROR("");
		}catch(Exception e){ 
//			Error errrec = new Error();
			bean.setERROR(e.toString());
//			errrec.setActiveFg("0");
//			errrec.setAppID("StawFac4Client");
//			errrec.setMethodID("ExecuteStawFac4()");
//			errrec.setModuleID("StawFac4Client.java");
//			errrec.setErrCd("8080");
//			errrec.setSevTypeCd("3");
//			errrec.postCreationTime();
//			errrec.setErrCause(e.toString());
//			errrec.setErrDesc("xception" + e.toString());
//			
//			try{
//				Driver dr = new Driver();
//				dr.postErrorRec(errrec);
//  				dr =null;
//  			}catch(Exception ex){
//  				 
//  			}
		}
		
		
		
		
	}
}
