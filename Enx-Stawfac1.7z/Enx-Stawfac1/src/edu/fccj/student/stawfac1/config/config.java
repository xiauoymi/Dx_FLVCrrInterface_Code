package edu.fccj.student.stawfac1.config;

public class config {
	//Prod
//	public static String WebServiceURL = "https://eidolon.fscj.edu/entirex/xmlrt";
	
//	public static String FLVC_DB = "jdbc:sqlserver://JUNO.fscj.org;" +
//			 "User=FLVC_App;Password=rec0n1ng!;" +
//			 "DatabaseName=FLVC";
	
	
	//Test
	 public static String FLVC_DB = "jdbc:sqlserver://SQL05-DEV.fscj.org;" +
	 "User=FLVC_App;Password=rec0n1ng!;" +
	 "DatabaseName=FLVC";

	public static String WebServiceURL = "http://enttst01:8080/entirex/xmlrt";
	
	
}
