package edu.fccj.student.stawfac1.bean;

import java.io.Serializable;

public class StawFac1Bean implements Serializable {

	private static final long serialVersionUID = 1377441770109181803L;
	
	private String ERROR = "";
	
	private String STDNT_ID  = "";
	private String LST_NM  = ""; 
	private String FRST_NM   = "";
	private String MDL_NM   = "";
	private String APPEND   = "";
	private String STREET_1   = "";
	private String CITY   = "";
	private String STATE   = "";
	private String ZIP_CD   = "";
	private String HM_PHN   = "";
	private String EMAIL_ADDR   = "";
	private String CITIZENSHIP   = "";
	private String IMMIG_STAT   = "";
	private String SEX   = "";
	private String DOB   = "";
	private String RACE_ETHNICITY   = "";
	private String HS_GRAD_DT   = "";
	private String STATE_BIRTH   = "";
	private String CNTRY_BIRTH   = "";
	private String RES_CD   = "";
	private String EXTRNL_INST   = ""; 
	private String ADDMISSION_RESP_TYPE   = "";
	private String RC   = "";
	private String RC_MSG   = "";
	private Course[] course = new Course[0];
	private String[] admission_Questions = new String[0];
	private String[] admission_Answers = new String[0];
	private String is_Enrolled_In_Degree_Program = "N";
	private String is_Eligible_to_Reenroll = "N";
	private String has_required_vaccinations = "N";
	private TF_SECTION[] section = new TF_SECTION[0];
	private String factsID = "";
	private String trackNum = "";
	private String studComment = "";
	private String confNum = "";
	private String confCode = "";
	
	public String getSTDNT_ID() {
		return STDNT_ID;
	}
	public void setSTDNT_ID(String stdnt_id) {
		STDNT_ID = stdnt_id;
	}
	public String getLST_NM() {
		return LST_NM;
	}
	public void setLST_NM(String lst_nm) {
		LST_NM = lst_nm;
	}
	public String getFRST_NM() {
		return FRST_NM;
	}
	public void setFRST_NM(String frst_nm) {
		FRST_NM = frst_nm;
	}
	public String getMDL_NM() {
		return MDL_NM;
	}
	public void setMDL_NM(String mdl_nm) {
		MDL_NM = mdl_nm;
	}
	public String getAPPEND() {
		return APPEND;
	}
	public void setAPPEND(String append) {
		APPEND = append;
	}
	public String getSTREET_1() {
		return STREET_1;
	}
	public void setSTREET_1(String street_1) {
		STREET_1 = street_1;
	}
	public String getCITY() {
		return CITY;
	}
	public void setCITY(String city) {
		CITY = city;
	}
	public String getSTATE() {
		return STATE;
	}
	public void setSTATE(String state) {
		STATE = state;
	}
	public String getZIP_CD() {
		return ZIP_CD;
	}
	public void setZIP_CD(String zip_cd) {
		ZIP_CD = zip_cd;
	}
	public String getHM_PHN() {
		return HM_PHN;
	}
	public void setHM_PHN(String hm_phn) {
		HM_PHN = hm_phn;
	}
	public String getEMAIL_ADDR() {
		return EMAIL_ADDR;
	}
	public void setEMAIL_ADDR(String email_addr) {
		EMAIL_ADDR = email_addr;
	}
	public String getCITIZENSHIP() {
		return CITIZENSHIP;
	}
	public void setCITIZENSHIP(String citizenship) {
		CITIZENSHIP = citizenship;
	}
	public String getIMMIG_STAT() {
		return IMMIG_STAT;
	}
	public void setIMMIG_STAT(String immig_stat) {
		IMMIG_STAT = immig_stat;
	}
	public String getSEX() {
		return SEX;
	}
	public void setSEX(String sex) {
		SEX = sex;
	}
	public String getDOB() {
		return DOB;
	}
	public void setDOB(String dob) {
		DOB = dob;
	}
	public String getRACE_ETHNICITY() {
		return RACE_ETHNICITY;
	}
	public void setRACE_ETHNICITY(String race_ethnicity) {
		RACE_ETHNICITY = race_ethnicity;
	}
	public String getHS_GRAD_DT() {
		return HS_GRAD_DT;
	}
	public void setHS_GRAD_DT(String hs_grad_dt) {
		HS_GRAD_DT = hs_grad_dt;
	}
	public String getSTATE_BIRTH() {
		return STATE_BIRTH;
	}
	public void setSTATE_BIRTH(String state_birth) {
		STATE_BIRTH = state_birth;
	}
	public String getCNTRY_BIRTH() {
		return CNTRY_BIRTH;
	}
	public void setCNTRY_BIRTH(String cntry_birth) {
		CNTRY_BIRTH = cntry_birth;
	}
	public String getRES_CD() {
		return RES_CD;
	}
	public void setRES_CD(String res_cd) {
		RES_CD = res_cd;
	}
	public String getEXTRNL_INST() {
		return EXTRNL_INST;
	}
	public void setEXTRNL_INST(String extrnl_inst) {
		EXTRNL_INST = extrnl_inst;
	}
	public String getADDMISSION_RESP_TYPE() {
		return ADDMISSION_RESP_TYPE;
	}
	public void setADDMISSION_RESP_TYPE(String addmission_resp_type) {
		ADDMISSION_RESP_TYPE = addmission_resp_type;
	}
	public String getRC() {
		return RC;
	}
	public void setRC(String rc) {
		RC = rc;
	}
	public String getRC_MSG() {
		return RC_MSG;
	}
	public void setRC_MSG(String rc_msg) {
		RC_MSG = rc_msg;
	}
	public String getERROR() {
		return ERROR;
	}
	public void setERROR(String error) {
		ERROR = error;
	}
	/**
	 * @return the course
	 */
	public Course[] getCourse() {
		return course;
	}
	/**
	 * @param course the course to set
	 */
	public void setCourse(Course[] course) {
		this.course = course;
	}
	/**
	 * @return the admission_Questions
	 */
	public String[] getAdmission_Questions() {
		return admission_Questions;
	}
	/**
	 * @param admission_Questions the admission_Questions to set
	 */
	public void setAdmission_Questions(String[] admission_Questions) {
		this.admission_Questions = admission_Questions;
	}
	/**
	 * @return the admission_Answers
	 */
	public String[] getAdmission_Answers() {
		return admission_Answers;
	}
	/**
	 * @param admission_Answers the admission_Answers to set
	 */
	public void setAdmission_Answers(String[] admission_Answers) {
		this.admission_Answers = admission_Answers;
	}
	/**
	 * @return the is_Enrolled_In_Degree_Program
	 */
	public String getIs_Enrolled_In_Degree_Program() {
		return is_Enrolled_In_Degree_Program;
	}
	/**
	 * @param is_Enrolled_In_Degree_Program the is_Enrolled_In_Degree_Program to set
	 */
	public void setIs_Enrolled_In_Degree_Program(
			String is_Enrolled_In_Degree_Program) {
		this.is_Enrolled_In_Degree_Program = is_Enrolled_In_Degree_Program;
	}
	/**
	 * @return the is_Eligible_to_Reenroll
	 */
	public String getIs_Eligible_to_Reenroll() {
		return is_Eligible_to_Reenroll;
	}
	/**
	 * @param is_Eligible_to_Reenroll the is_Eligible_to_Reenroll to set
	 */
	public void setIs_Eligible_to_Reenroll(String is_Eligible_to_Reenroll) {
		this.is_Eligible_to_Reenroll = is_Eligible_to_Reenroll;
	}
	/**
	 * @return the has_required_vaccinations
	 */
	public String getHas_required_vaccinations() {
		return has_required_vaccinations;
	}
	/**
	 * @param has_required_vaccinations the has_required_vaccinations to set
	 */
	public void setHas_required_vaccinations(String has_required_vaccinations) {
		this.has_required_vaccinations = has_required_vaccinations;
	}
	/**
	 * @return the section
	 */
	public TF_SECTION[] getSection() {
		return section;
	}
	/**
	 * @param section the section to set
	 */
	public void setSection(TF_SECTION[] section) {
		this.section = section;
	}
	/**
	 * @return the factsID
	 */
	public String getFactsID() {
		return factsID;
	}
	/**
	 * @param factsID the factsID to set
	 */
	public void setFactsID(String factsID) {
		this.factsID = factsID;
	}
	/**
	 * @return the trackNum
	 */
	public String getTrackNum() {
		return trackNum;
	}
	/**
	 * @param trackNum the trackNum to set
	 */
	public void setTrackNum(String trackNum) {
		this.trackNum = trackNum;
	}
	/**
	 * @return the studComment
	 */
	public String getStudComment() {
		return studComment;
	}
	/**
	 * @param studComment the studComment to set
	 */
	public void setStudComment(String studComment) {
		this.studComment = studComment;
	}
	/**
	 * @return the confNum
	 */
	public String getConfNum() {
		return confNum;
	}
	/**
	 * @param confNum the confNum to set
	 */
	public void setConfNum(String confNum) {
		this.confNum = confNum;
	}
	/**
	 * @return the confCode
	 */
	public String getConfCode() {
		return confCode;
	}
	/**
	 * @param confCode the confCode to set
	 */
	public void setConfCode(String confCode) {
		this.confCode = confCode;
	}

}
