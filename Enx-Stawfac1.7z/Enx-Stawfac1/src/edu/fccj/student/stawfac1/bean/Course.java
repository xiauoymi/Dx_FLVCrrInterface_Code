package edu.fccj.student.stawfac1.bean;

import java.io.Serializable;

public class Course implements Serializable 
 {
	/**
	 * 
	 */
	private static final long serialVersionUID = -1903539636335903254L;
	private String crsnbr = "";
	private String credhrs = "0";
	private String approved = "N";
	private String title = "";
	private String course_use = "";
	private String course_equivalent = "";
	private String distance_learning = "N";
	private String Financial_Aid_Eligible = "N";
	
	/**
	 * @return the crsnbr
	 */
	public String getCrsnbr() {
		return crsnbr;
	}
	/**
	 * @param crsnbr the crsnbr to set
	 */
	public void setCrsnbr(String crsnbr) {
		this.crsnbr = crsnbr;
	}
	/**
	 * @return the credhrs
	 */
	public String getCredhrs() {
		return credhrs;
	}
	/**
	 * @param credhrs the credhrs to set
	 */
	public void setCredhrs(String credhrs) {
		this.credhrs = credhrs;
	}
	/**
	 * @return the approved
	 */
	public String getApproved() {
		return approved;
	}
	/**
	 * @param approved the approved to set
	 */
	public void setApproved(String approved) {
		this.approved = approved;
	}
	/**
	 * @return the title
	 */
	public String getTitle() {
		return title;
	}
	/**
	 * @param title the title to set
	 */
	public void setTitle(String title) {
		this.title = title;
	}
	/**
	 * @return the course_use
	 */
	public String getCourse_use() {
		return course_use;
	}
	/**
	 * @param course_use the course_use to set
	 */
	public void setCourse_use(String course_use) {
		this.course_use = course_use;
	}
	/**
	 * @return the course_equivalent
	 */
	public String getCourse_equivalent() {
		return course_equivalent;
	}
	/**
	 * @param course_equivalent the course_equivalent to set
	 */
	public void setCourse_equivalent(String course_equivalent) {
		this.course_equivalent = course_equivalent;
	}
	/**
	 * @return the distance_learning
	 */
	public String getDistance_learning() {
		return distance_learning;
	}
	/**
	 * @param distance_learning the distance_learning to set
	 */
	public void setDistance_learning(String distance_learning) {
		this.distance_learning = distance_learning;
	}
	/**
	 * @return the financial_Aid_Eligible
	 */
	public String getFinancial_Aid_Eligible() {
		return Financial_Aid_Eligible;
	}
	/**
	 * @param financial_Aid_Eligible the financial_Aid_Eligible to set
	 */
	public void setFinancial_Aid_Eligible(String financial_Aid_Eligible) {
		Financial_Aid_Eligible = financial_Aid_Eligible;
	}
}
