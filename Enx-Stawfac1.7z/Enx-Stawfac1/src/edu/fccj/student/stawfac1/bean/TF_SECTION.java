package edu.fccj.student.stawfac1.bean;

import java.io.Serializable;

public class TF_SECTION implements Serializable  {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7319378764897017335L;
	private String institution = "";
	private String title = "";
	private String role = "";
	private String real = "";
	private String comment = "";
	private String user_name = "";
	private String fullname = "";
	private String signed_timestamp = "";
	private String signed_state = "";
	
	/**
	 * @return the institution
	 */
	public String getInstitution() {
		return institution;
	}
	/**
	 * @param institution the institution to set
	 */
	public void setInstitution(String institution) {
		this.institution = institution;
	}
	/**
	 * @return the title
	 */
	public String getTitle() {
		return title;
	}
	/**
	 * @param title the title to set
	 */
	public void setTitle(String title) {
		this.title = title;
	}
	/**
	 * @return the role
	 */
	public String getRole() {
		return role;
	}
	/**
	 * @param role the role to set
	 */
	public void setRole(String role) {
		this.role = role;
	}
	/**
	 * @return the real
	 */
	public String getReal() {
		return real;
	}
	/**
	 * @param real the real to set
	 */
	public void setReal(String real) {
		this.real = real;
	}
	/**
	 * @return the comment
	 */
	public String getComment() {
		return comment;
	}
	/**
	 * @param comment the comment to set
	 */
	public void setComment(String comment) {
		this.comment = comment;
	}
	/**
	 * @return the user_name
	 */
	public String getUser_name() {
		return user_name;
	}
	/**
	 * @param user_name the user_name to set
	 */
	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}
	/**
	 * @return the fullname
	 */
	public String getFullname() {
		return fullname;
	}
	/**
	 * @param fullname the fullname to set
	 */
	public void setFullname(String fullname) {
		this.fullname = fullname;
	}
	/**
	 * @return the signed_timestamp
	 */
	public String getSigned_timestamp() {
		return signed_timestamp;
	}
	/**
	 * @param signed_timestamp the signed_timestamp to set
	 */
	public void setSigned_timestamp(String signed_timestamp) {
		this.signed_timestamp = signed_timestamp;
	}
	/**
	 * @return the signed_state
	 */
	public String getSigned_state() {
		return signed_state;
	}
	/**
	 * @param signed_state the signed_state to set
	 */
	public void setSigned_state(String signed_state) {
		this.signed_state = signed_state;
	}
	
	
}
