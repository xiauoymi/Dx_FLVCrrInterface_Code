package edu.fccj.student.stawfac1.client;


import com.util.test.FileRead;

import ORIONWEB.com_softwareag_entirex_rpc_stawfac1.ORIONWEBPort;
import ORIONWEB.com_softwareag_entirex_rpc_stawfac1.Stawfac1Locator;
import ORIONWEB.com_softwareag_entirex_rpc_stawfac1.STAWFAC1ResponseWEBPASS1;
import ORIONWEB.com_softwareag_entirex_rpc_stawfac1.STAWFAC1WEBPASS; 
import edu.fccj.student.stawfac1.bean.Course;
import edu.fccj.student.stawfac1.bean.StawFac1Bean;
import edu.fccj.student.stawfac1.bean.TF_SECTION;
import edu.fccj.student.stawfac4.client.StawFac4Client;
import edu.fccj.student.utils.DBWrite;


import java.io.File;
import java.io.IOException;
import java.io.StringReader;
import java.util.ArrayList;

import org.w3c.dom.Document;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.FactoryConfigurationError;
import javax.xml.parsers.ParserConfigurationException;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;


public class StawFac1Client {
	
	
	
	public StawFac1Bean ExecuteStawFac1(StawFac1Bean bean){
		
		Stawfac1Locator server = new Stawfac1Locator();
		ORIONWEBPort proxy;
		
		STAWFAC1WEBPASS WEBPASS = new STAWFAC1WEBPASS();
		STAWFAC1ResponseWEBPASS1 out = new STAWFAC1ResponseWEBPASS1();
		
		//marvin, you may want to clean up this block, if input, get it from bean, otherwise, put an empty string, like rc and rcdesc - the only
		//two i know for sure is output
		WEBPASS.set_ADDMISSIONRESPTYPE(bean.getADDMISSION_RESP_TYPE());
		WEBPASS.set_APPEND(bean.getAPPEND());
		WEBPASS.set_CITIZENSHIP(bean.getCITIZENSHIP());
		WEBPASS.set_CITY(bean.getCITY());
		WEBPASS.set_CNTRYBIRTH(bean.getCNTRY_BIRTH());
		WEBPASS.set_DOB(bean.getDOB());
		WEBPASS.set_EMAILADDR(bean.getEMAIL_ADDR());
		WEBPASS.set_EXTRNLINST(bean.getEXTRNL_INST());
		WEBPASS.set_FRSTNM(bean.getFRST_NM());
		WEBPASS.set_HMPHN(bean.getHM_PHN());
		WEBPASS.set_HSGRADDT(bean.getHS_GRAD_DT());
		WEBPASS.set_IMMIGSTAT(bean.getIMMIG_STAT());
		WEBPASS.set_LSTNM(bean.getLST_NM());
		WEBPASS.set_MDLNM(bean.getMDL_NM());
		WEBPASS.set_RACEETHNICITY(bean.getRACE_ETHNICITY());
		WEBPASS.set_RC("");
		WEBPASS.set_RCMSG("");
		WEBPASS.set_RESCD(bean.getRES_CD());
		WEBPASS.set_SEX(bean.getSEX());
		WEBPASS.set_STATE(bean.getSTATE());
		WEBPASS.set_STATEBIRTH(bean.getSTATE_BIRTH());
		WEBPASS.set_STDNTID(bean.getSTDNT_ID());
		WEBPASS.set_STREET1(bean.getSTREET_1());
		WEBPASS.set_ZIPCD(bean.getZIP_CD());
		String[] ans = bean.getAdmission_Answers();
		WEBPASS.setOFFENSEQUES1(ans[0]);
		WEBPASS.setOFFENSEQUES2(ans[1]);
		
		try{
			proxy = server.getORIONWEBPort();
			out = proxy.STAWFAC1(WEBPASS);
			bean.setERROR("");
		}catch(Exception e){ 
			bean.setERROR(e.toString());
//			Error errrec = new Error();
//			
//			errrec.setActiveFg("0");
//			errrec.setAppID("StawFac1Client");
//			errrec.setMethodID("ExecuteStawFac1()");
//			errrec.setModuleID("StawFac1Client.java");
//			errrec.setErrCd("8080");
//			errrec.setSevTypeCd("3");
//			errrec.postCreationTime();
//			errrec.setErrCause(e.toString());
//			errrec.setErrDesc("xception" + e.toString());
			System.out.println(e.toString());
//			try{
//				Driver dr = new Driver();
//				dr.postErrorRec(errrec);
//  				dr =null;
//  			}catch(Exception ex){
//  				 
//  			}
		}
		if (bean.getERROR().equals("")){
			
			//i don't know what is needed in the output, that's why i pop everything in the bean
			bean.setRC(out.get_RC1());
			bean.setRC_MSG(out.get_RCMSG1());
			bean.setADDMISSION_RESP_TYPE(out.get_ADDMISSIONRESPTYPE1());
			bean.setAPPEND(out.get_APPEND1());
			bean.setCITIZENSHIP(out.get_CITIZENSHIP1());
			bean.setCITY(out.get_CITY1());
			bean.setCNTRY_BIRTH(out.get_CNTRYBIRTH1());
			bean.setDOB(out.get_DOB1());
			bean.setEMAIL_ADDR(out.get_EMAILADDR1());
			bean.setEXTRNL_INST(out.get_EXTRNLINST1());
			bean.setFRST_NM(out.get_FRSTNM1());
			bean.setHM_PHN(out.get_HMPHN1());
			bean.setHS_GRAD_DT(out.get_HSGRADDT1());
			bean.setIMMIG_STAT(out.get_IMMIGSTAT1());
			bean.setLST_NM(out.get_LSTNM1());
			bean.setMDL_NM(out.get_MDLNM1());
			bean.setRACE_ETHNICITY(out.get_RACEETHNICITY1());
			bean.setRES_CD(out.get_RESCD1());
			bean.setSEX(out.get_SEX1());
			bean.setSTATE(out.get_STATE1());
			bean.setSTATE_BIRTH(out.get_STATEBIRTH1());
			bean.setSTDNT_ID(out.get_STDNTID1());
			bean.setSTREET_1(out.get_STREET11());
			bean.setZIP_CD(out.get_ZIPCD1());			
			
		}
		return bean;
	}

	//start of parsing routines
	
	
	   public String getAttributes(String value, String attName, Element fstElmnt, int numAttributes) {
	        String rtn = "";
	        try{
	            NodeList fstNmElmntLst = fstElmnt.getElementsByTagName(value);
	            Element fstNmElmnt = (Element) fstNmElmntLst.item(0);
	          
	            
	            NodeList fstNm = fstNmElmnt.getChildNodes();
	            
	            NamedNodeMap nnm = fstNmElmnt.getAttributes();
	            
	            for(int counter = 0; counter < numAttributes; counter++) {
	            	String nodename = nnm.item(counter).getNodeName();
	            	if(nodename.equalsIgnoreCase(attName)) {
	            		rtn = nnm.item(counter).getNodeValue();
	            	}
	            }
	                                             
	            	       
	        }catch (NullPointerException ex) {
	            rtn = "";
	        }
	        return rtn;
	    }

	   public String getValues(String value, Element fstElmnt) {
	        String rtn = "";
	        try{
	       NodeList fstNmElmntLst = fstElmnt.getElementsByTagName(value);
	       Element fstNmElmnt = (Element) fstNmElmntLst.item(0);
	       NodeList fstNm = fstNmElmnt.getChildNodes();
	        rtn = fstNm.item(0).getNodeValue().toString();
	        }catch (NullPointerException ex) {
	        	rtn = "";
	        }
	        return rtn;
	    }
	
	   
	   private String getTextValue(Element ele, String tagName) {
			String textVal = "";
			try{
			NodeList nl = ele.getElementsByTagName(tagName);
			if(nl != null && nl.getLength() > 0) {
				Element el = (Element)nl.item(0);
				textVal = el.getFirstChild().getNodeValue();
			}
			}catch(Exception ex){
				textVal = "";
			}
			return textVal;
		}
   
	   
	private Course[] parseCourses(String data) throws ParserConfigurationException, SAXException, IOException {
		Course[] course = new Course[0];
		ArrayList al = new ArrayList();
		
		DocumentBuilder builder = javax.xml.parsers.DocumentBuilderFactory.newInstance().newDocumentBuilder();
		Document doc = builder.parse(new InputSource(new StringReader(data)));
        NodeList n1 = doc.getElementsByTagName("COURSE");
        if(n1 != null && n1.getLength() > 0) {
        	for(int i=0; i < n1.getLength(); i++) {
        		Course newRec = new Course();
        		Element el = (Element)n1.item(i);
        		newRec.setCrsnbr(el.getAttribute("CrsNbr"));
        		newRec.setCredhrs(el.getAttribute("CredHrs"));
        		newRec.setApproved(el.getAttribute("Approved"));
        		newRec.setTitle(getTextValue(el,"COURSE_TITLE"));
        		newRec.setCourse_use(getTextValue(el,"COURSE_USE"));
        		newRec.setCourse_equivalent(getTextValue(el,"COURSE_EQUIVALENT"));
        		newRec.setFinancial_Aid_Eligible(getTextValue(el,"FINANCIAL_AID_ELIGIBLE"));
        		newRec.setDistance_learning(getTextValue(el,"COURSE_DISTANCE_LEARNING"));
        		al.add(newRec);
        	}//for(int i=0; i < n1.getLength(); i++) {
        }//if(n1 != null && n1.getLength() > 0) {
		
        Object[] tmpObj = al.toArray();
        course = new Course[tmpObj.length];
        
        for(int counter = 0; counter < tmpObj.length; counter++){
        	course[counter] = new Course();
        	course[counter] = (Course)tmpObj[counter];
        }//for(int counter = 0; counter < tmpObj.length; counter++){
        
		return course;
	}
	
	private TF_SECTION[] parseTFSeciton(String data) throws ParserConfigurationException, SAXException, IOException {
		TF_SECTION[] section = new TF_SECTION[0];
		ArrayList al = new ArrayList();
		
		DocumentBuilder builder = javax.xml.parsers.DocumentBuilderFactory.newInstance().newDocumentBuilder();
		Document doc = builder.parse(new InputSource(new StringReader(data)));
        NodeList n1 = doc.getElementsByTagName("TF_SECTION");
        if(n1 != null && n1.getLength() > 0) {
        	for(int i=0; i < n1.getLength(); i++) {
        		TF_SECTION newRec = new TF_SECTION();
        		Element el = (Element)n1.item(i);
        		newRec.setInstitution(el.getAttribute("Institution"));        		
        		newRec.setTitle(getTextValue(el,"SECTION_TITLE"));
        		newRec.setRole(getTextValue(el,"SECTION_ROLE"));
        		newRec.setReal(getTextValue(el,"CONTEXT_REAL"));
        		newRec.setComment(getTextValue(el,"COMMENT"));
        		newRec.setUser_name(getTextValue(el,"USER_NAME"));
        		newRec.setFullname(getTextValue(el,"FULLNAME"));
        		newRec.setSigned_timestamp(getTextValue(el,"SIGNED_TIMESTAMP"));
        		newRec.setSigned_state(getTextValue(el,"SIGNED_STATE"));
        		al.add(newRec);
        	}//for(int i=0; i < n1.getLength(); i++) {
        }//if(n1 != null && n1.getLength() > 0) {
		
        Object[] tmpObj = al.toArray();
        section = new TF_SECTION[tmpObj.length];
        
        for(int counter = 0; counter < tmpObj.length; counter++){
        	section[counter] = new TF_SECTION();
        	section[counter] = (TF_SECTION)tmpObj[counter];
        }//for(int counter = 0; counter < tmpObj.length; counter++){
        
		return section;
	}
	   
	   //end of parsing routines
	
	public StawFac1Bean parseFACTSXML(String data) throws ParserConfigurationException, FactoryConfigurationError, SAXException, IOException {
		StawFac1Client service = new StawFac1Client();
		StawFac1Bean studRec = new StawFac1Bean();
		 DocumentBuilder builder = javax.xml.parsers.DocumentBuilderFactory.newInstance().newDocumentBuilder();
	        Document doc = builder.parse(new InputSource(new StringReader(data)));
	        NodeList FACTSNode = doc.getElementsByTagName("FACTS_MESSAGE");
	        Node fstNode = FACTSNode.item(0);
	        Element fstElmnt = (Element) fstNode;
		
	        
	        studRec.setSTDNT_ID(service.getValues("SSN",fstElmnt));
	        //studRec.setSTDNT_ID("111111113");
	        studRec.setLST_NM(service.getValues("LAST_NAME",fstElmnt));
	        
	        studRec.setFRST_NM(service.getValues("FIRST_NAME",fstElmnt));
	        
	        studRec.setMDL_NM(service.getValues("MIDDLE_NAME",fstElmnt));
	        studRec.setAPPEND("");
	        studRec.setSTREET_1(service.getValues("ADDRESS1",fstElmnt));
	        studRec.setCITY(service.getValues("CITY", fstElmnt));
	        studRec.setSTATE(service.getValues("STATE",fstElmnt));
	        studRec.setZIP_CD(service.getValues("ZIP",fstElmnt));
	        studRec.setHM_PHN(service.getValues("DAY_PHONE",fstElmnt));
	        studRec.setEMAIL_ADDR(service.getValues("EMAIL_ADDRESS", fstElmnt));
	        studRec.setCITIZENSHIP(service.getAttributes("CITIZENSHIP", "Code", fstElmnt, 1));
	        studRec.setIMMIG_STAT(service.getAttributes("IMMIGRANT_STATUS", "Code", fstElmnt,1));
	        studRec.setSEX(service.getAttributes("GENDER", "Code", fstElmnt,1));
	        String dob = service.getAttributes("BIRTHDATE", "YR", fstElmnt,3) + service.getAttributes("BIRTHDATE", "MON", fstElmnt,2) + service.getAttributes("BIRTHDATE", "DAY", fstElmnt,3) ;
	        
	        studRec.setDOB(dob);
	        
	        String tmpRace = "X";
	        try{
	        tmpRace = service.getValues("RACE_ETHNICITY",fstElmnt);
	        tmpRace = tmpRace.substring(1, (tmpRace.length()-1));
	        }catch(Exception ex) {
	        	tmpRace = "X";
	        }
	        studRec.setRACE_ETHNICITY(tmpRace);
	        studRec.setHS_GRAD_DT("");
	        studRec.setSTATE_BIRTH("");
	        studRec.setCNTRY_BIRTH("");
	        studRec.setRES_CD(service.getAttributes("LEGAL_CLASSIFICATION", "Code", fstElmnt,1));
	        studRec.setEXTRNL_INST(service.getValues("PARENT_SCHOOL_FICE_CODE",fstElmnt));    
	        
	        studRec.setCourse(service.parseCourses(data));
	        
	        studRec.setIs_Enrolled_In_Degree_Program(service.getAttributes("IS_ENROLLED_IN_DEGREE_PROGRAM", "YN", fstElmnt, 1));
	        studRec.setIs_Eligible_to_Reenroll(service.getAttributes("IS_ELIGIBLE_TO_REENROLL", "YN", fstElmnt, 1));
	        studRec.setHas_required_vaccinations(service.getAttributes("HAS_REQUIRED_VACCINATIONS", "YN", fstElmnt, 1));
	        
	        String[] quest = new String[5];
	        quest[0] = new String();
	        quest[1] = new String();
	        quest[2] = new String();
	        quest[3] = new String();
	        quest[4] = new String();
	        
	        quest[0] = service.getValues("HOST_ADMISSION_QUESTION1", fstElmnt);
	        quest[1] = service.getValues("HOST_ADMISSION_QUESTION2", fstElmnt);
	        quest[2] = service.getValues("HOST_ADMISSION_QUESTION3", fstElmnt);
	        quest[3] = service.getValues("HOST_ADMISSION_QUESTION4", fstElmnt);
	        quest[4] = service.getValues("HOST_ADMISSION_QUESTION5", fstElmnt);
	        
	        if(quest[0] == null) {
	        	quest[0] = "";
	        }
	        
	        if(quest[1] == null) {
	        	quest[1] = "";
	        }
	        
	        if(quest[2] == null) {
	        	quest[2] = "";
	        }
	        
	        if(quest[3] == null) {
	        	quest[3] = "";
	        }
	        
	        if(quest[4] == null) {
	        	quest[4] = "";
	        }
	        
	        
	        
	        studRec.setAdmission_Questions(quest);
	        
	        String[] ans = new String[5];
	        ans[0] = new String();
	        ans[1] = new String();
	        ans[2] = new String();
	        ans[3] = new String();
	        ans[4] = new String();
	        
	        ans[0] = service.getValues("HOST_ADMISSION_ANSWER1", fstElmnt);
	        ans[1] = service.getValues("HOST_ADMISSION_ANSWER2", fstElmnt);
	        ans[2] = service.getValues("HOST_ADMISSION_ANSWER3", fstElmnt);
	        ans[3] = service.getValues("HOST_ADMISSION_ANSWER4", fstElmnt);
	        ans[4] = service.getValues("HOST_ADMISSION_ANSWER5", fstElmnt);
	        
	        if (ans[0] == null) {
	        	ans[0] = "";
	        }
	        
	        if (ans[1] == null) {
	        	ans[1] = "";
	        }
	        if (ans[2] == null) {
	        	ans[2] = "";
	        }
	        if (ans[3] == null) {
	        	ans[3] = "";
	        }
	        if (ans[4] == null) {
	        	ans[4] = "";
	        }
	        
	        studRec.setAdmission_Answers(ans);
	        
	        studRec.setSection(service.parseTFSeciton(data));
	        studRec.setFactsID(service.getAttributes("ADMISSION_REQ", "FACTS_ID", fstElmnt, 1));
	        studRec.setTrackNum(service.getAttributes("ADMISSION_REQ", "Track", fstElmnt, 2));
	        
	      
	        return(studRec);
	}
	
	
	/**
	 * @param args
	 * @throws ParserConfigurationException 
	 * @throws IOException 
	 * @throws SAXException 
	 */
	public static void main(String[] args) throws ParserConfigurationException, SAXException, IOException {
		    String data = "";
		   
		   	FileRead fr = new FileRead();
		   	data = fr.readXMLFile("c://NewError.txt");
			StawFac1Client service = new StawFac1Client();
			StawFac1Bean studRec = new StawFac1Bean();
			 DocumentBuilder builder = javax.xml.parsers.DocumentBuilderFactory.newInstance().newDocumentBuilder();
		        Document doc = builder.parse(new InputSource(new StringReader(data)));
		        NodeList FACTSNode = doc.getElementsByTagName("FACTS_MESSAGE");
		        Node fstNode = FACTSNode.item(0);
		        Element fstElmnt = (Element) fstNode;
			
		        
		        studRec.setSTDNT_ID(service.getValues("SSN",fstElmnt));
		        //studRec.setSTDNT_ID("111111113");
		        studRec.setLST_NM(service.getValues("LAST_NAME",fstElmnt));
		        
		        studRec.setFRST_NM(service.getValues("FIRST_NAME",fstElmnt));
		        
		        studRec.setMDL_NM(service.getValues("MIDDLE_NAME",fstElmnt));
		        studRec.setAPPEND("");
		        studRec.setSTREET_1(service.getValues("ADDRESS1",fstElmnt));
		        studRec.setCITY(service.getValues("CITY", fstElmnt));
		        studRec.setSTATE(service.getValues("STATE",fstElmnt));
		        studRec.setZIP_CD(service.getValues("ZIP",fstElmnt));
		        studRec.setHM_PHN(service.getValues("DAY_PHONE",fstElmnt));
		        studRec.setEMAIL_ADDR(service.getValues("EMAIL_ADDRESS", fstElmnt));
		        studRec.setCITIZENSHIP(service.getAttributes("CITIZENSHIP", "Code", fstElmnt, 1));
		        studRec.setIMMIG_STAT(service.getAttributes("IMMIGRANT_STATUS", "Code", fstElmnt,1));
		        studRec.setSEX(service.getAttributes("GENDER", "Code", fstElmnt,1));
		        String dob = service.getAttributes("BIRTHDATE", "YR", fstElmnt,3) + service.getAttributes("BIRTHDATE", "MON", fstElmnt,2) + service.getAttributes("BIRTHDATE", "DAY", fstElmnt,3) ;
		        studRec.setDOB(dob);
		        
		        
		        String tmpRace = "X";
		        try{
		        tmpRace = service.getValues("RACE_ETHNICITY",fstElmnt);
		        tmpRace = tmpRace.substring(1, (tmpRace.length()-1));
		        }catch(Exception ex) {
		        	tmpRace = "X";
		        }
		        studRec.setRACE_ETHNICITY(tmpRace);
		        studRec.setHS_GRAD_DT("");
		        studRec.setSTATE_BIRTH("");
		        studRec.setCNTRY_BIRTH("");
		        studRec.setRES_CD(service.getAttributes("LEGAL_CLASSIFICATION", "Code", fstElmnt,1));
		        studRec.setEXTRNL_INST(service.getValues("PARENT_SCHOOL_FICE_CODE",fstElmnt));    
		        
		        studRec.setCourse(service.parseCourses(data));
		        
		        studRec.setIs_Enrolled_In_Degree_Program(service.getAttributes("IS_ENROLLED_IN_DEGREE_PROGRAM", "YN", fstElmnt, 1));
		        studRec.setIs_Eligible_to_Reenroll(service.getAttributes("IS_ELIGIBLE_TO_REENROLL", "YN", fstElmnt, 1));
		        studRec.setHas_required_vaccinations(service.getAttributes("HAS_REQUIRED_VACCINATIONS", "YN", fstElmnt, 1));
		        
		        String[] quest = new String[5];
		        quest[0] = new String();
		        quest[1] = new String();
		        quest[2] = new String();
		        quest[3] = new String();
		        quest[4] = new String();
		        
		        quest[0] = service.getValues("HOST_ADMISSION_QUESTION1", fstElmnt);
		        quest[1] = service.getValues("HOST_ADMISSION_QUESTION2", fstElmnt);
		        quest[2] = service.getValues("HOST_ADMISSION_QUESTION3", fstElmnt);
		        quest[3] = service.getValues("HOST_ADMISSION_QUESTION4", fstElmnt);
		        quest[4] = service.getValues("HOST_ADMISSION_QUESTION5", fstElmnt);
		        
		        if(quest[0] == null) {
		        	quest[0] = "";
		        }
		        
		        if(quest[1] == null) {
		        	quest[1] = "";
		        }
		        
		        if(quest[2] == null) {
		        	quest[2] = "";
		        }
		        
		        if(quest[3] == null) {
		        	quest[3] = "";
		        }
		        
		        if(quest[4] == null) {
		        	quest[4] = "";
		        }
		        
		        studRec.setAdmission_Questions(quest);
		        
		        String[] ans = new String[5];
		        ans[0] = new String();
		        ans[1] = new String();
		        ans[2] = new String();
		        ans[3] = new String();
		        ans[4] = new String();
		        
		        ans[0] = service.getValues("HOST_ADMISSION_ANSWER1", fstElmnt);
		        ans[1] = service.getValues("HOST_ADMISSION_ANSWER2", fstElmnt);
		        ans[2] = service.getValues("HOST_ADMISSION_ANSWER3", fstElmnt);
		        ans[3] = service.getValues("HOST_ADMISSION_ANSWER4", fstElmnt);
		        ans[4] = service.getValues("HOST_ADMISSION_ANSWER5", fstElmnt);
		        
		        if (ans[0] == null) {
		        	ans[0] = "";
		        }
		        
		        if (ans[1] == null) {
		        	ans[1] = "";
		        }
		        if (ans[2] == null) {
		        	ans[2] = "";
		        }
		        if (ans[3] == null) {
		        	ans[3] = "";
		        }
		        if (ans[4] == null) {
		        	ans[4] = "";
		        }
		        studRec.setAdmission_Answers(ans);
		        
		        studRec.setSection(service.parseTFSeciton(data));
		        studRec.setFactsID(service.getAttributes("ADMISSION_REQ", "FACTS_ID", fstElmnt, 1));
		        studRec.setTrackNum(service.getAttributes("ADMISSION_REQ", "Track", fstElmnt, 2));
		       
		        try{
		        	StawFac1Client client = new StawFac1Client();
		        	studRec = client.ExecuteStawFac1(studRec);
		        	
//		        	StawFac4Client client2 = new StawFac4Client();
//		        	client2.ExecuteStawfac4(studRec);
		        	
		        }catch (Exception ex) {
		        	System.out.println(ex.toString());
		        }finally{
		        }
		        System.out.println("done");
	}

}
